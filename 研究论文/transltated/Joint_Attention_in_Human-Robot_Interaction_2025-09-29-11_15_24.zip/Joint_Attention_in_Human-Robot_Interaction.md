# Joint Attention in Human-Robot Interaction

# 人机交互中的共同注意

Chien-Ming Huang and Andrea L. Thomaz

黄建明和安德烈亚·L·托马兹

801 Atlantic Dr., Atlanta GA, 30332

801 大西洋大道，亚特兰大，GA，30332

## Abstract

## 摘要

We propose a computational model of joint attention consisting of three parts: responding to joint attention, initiating joint attention, and ensuring joint attention. This model is supported by psychological findings and matches the developmental timeline in humans. We present two experiments that test this model and investigate joint attention in human-robot interaction. The first experiment explored the effects of responding to joint attention on human-robot interaction. We show that robots responding to joint attention are more transparent to humans and are more competent and socially interactive. The second experiment studied the importance of ensuring joint attention in human-robot interaction. Data upheld our hypotheses that a robot's ensuring joint attention behavior yields better performance in human-robot interactive tasks and ensuring joint attention behaviors are perceived as natural behaviors.

我们提出了一种由响应共同注意、主动引发共同注意和确保共同注意三个部分组成的计算模型。该模型得到了心理学研究的支持，并与人类的发展时间线相吻合。我们展示了两个实验，用以验证该模型并研究人机交互中的共同注意。第一个实验探讨了响应共同注意对人机交互的影响。结果显示，响应共同注意的机器人对人类更具透明性，更加胜任且具有社会互动性。第二个实验研究了确保共同注意在HRI中的重要性。数据支持我们的假设，即机器人表现出确保共同注意行为能提升人机交互任务的表现，并且这些行为被认为是自然的行为。

Joint attention, a process to share one's current attention with another by using social cues such as gaze, has been recognized as a crucial component in interactions and an important milestone in infant development. One of the key components of Autism Spectrum Disorder is the failure to develop joint attention capabilities. It is hypothesized that the failure to develop this fundamental social skill leads people on the autism spectrum to often have difficulties in communication and interaction with other people (Baron-Cohen 1997). Therefore, to facilitate natural human-robot interaction (HRI), we believe that robots need social skills to respond to, initiate, and maintain joint attention with humans.

共同注意(joint attention)是一种通过使用社会线索(如凝视)与他人共享当前注意力的过程，被认为是交互中的关键组成部分，也是婴儿发展中的重要里程碑。自闭症谱系障碍(Autism Spectrum Disorder)的一大特征是未能发展出共同注意能力。假设未能发展这一基本社会技能会导致自闭症谱系中的人们在沟通和互动方面常常遇到困难(Baron-Cohen 1997)。因此，为了促进自然的人机交互(HRI)，我们认为机器人需要具备社会技能，以响应、主动引发并维持与人类的共同注意。

Our model of joint attention reflects the complexity of this social skill for cognitive robots, dividing the skill into its three main components: responding to joint attention (RJA), initiating joint attention (IJA), and ensuring joint attention (EJA). RJA is the ability to follow another's direction of gaze and gestures in order to attain common experience. IJA is the ability to manipulate another's attention to a focus of interest in order to share experience. EJA is the ability to monitor another's attention and to ensure that the state of joint attention is reached. These match the developmental milestones of joint attention in infancy. Infants start with the skill of following a care-giver's gaze, and then they exhibit pointing gestures (especially declarative pointing gestures) to get the care-giver's attention. Importantly, the initiating actions often come with an ensuring behavior that is to look back and forth between the care-giver and the referential object (Mundy and Newell 2007)

我们的共同注意模型反映了这一社会技能在认知机器人中的复杂性，将其划分为三个主要组成部分:响应共同注意(RJA)、主动引发共同注意(IJA)和确保共同注意(EJA)。RJA是指跟随他人的凝视和手势以达成共同体验的能力。IJA是指操控他人注意力以共享兴趣焦点的能力。EJA是指监控他人注意力并确保共同注意状态达成的能力。这些与婴儿期共同注意的发展里程碑相符。婴儿最初会跟随照料者的凝视，然后会用指示性手势(尤其是陈述性指点手势)吸引照料者的注意。重要的是，主动引发行为通常伴随着确保行为，即在照料者和指涉对象之间来回观察(Mundy 和 Newell 2007)。

We conducted two experiments to test our model and to investigate joint attention in HRI. The first experiment explored the effects of responding to joint attention. Results showed that a robot responding to joint attention is more transparent to people such that interactive task performance is better and people are more confident in the robot's task success. In addition, people perceive a robot responding to joint attention as more competent and socially interactive. The second experiment studied the importance of ensuring joint attention in HRI. Results suggested that ensuring joint attention yields better task performance and is viewed as a natural behavior in interactions.

我们进行了两项实验，以验证我们的模型并研究人机交互中的共同注意。第一项实验探讨了响应共同注意的效果。结果显示，响应共同注意的机器人对人类更具透明性，从而提升了互动任务的表现，并增强了人们对机器人任务成功的信心。此外，人们认为响应共同注意的机器人更具能力和社会互动性。第二项实验研究了确保共同注意在HRI中的重要性。结果表明，确保共同注意能带来更好的任务表现，并被视为自然的交互行为。

## Related Work

## 相关工作

The benefit of using an embodied platform for evaluation of a computational model of joint attention has been recognized. An embodied platform provides the capability of being physically interactive and is more likely to draw natural responses from participants. Moreover, in contrast to empirical observations, embodiment allows experiments to be repeatable, and different aspects are easily separated for evaluation (Kaplan and Hafner 2006). Additionally, embodiment provides access to internal states as a behavior develops (Deák, Fasel, and Movellan 2001).

使用具身平台(embodied platform)评估共同注意的计算模型的优势已被认可。具身平台具有物理交互能力，更容易引发参与者的自然反应。此外，与纯粹的经验观察相比，具身性允许实验的重复性，并且不同方面可以方便地进行分离评估(Kaplan 和 Hafner 2006)。此外，具身性还能在行为发展过程中访问内部状态(Deák、Fasel 和 Movellan 2001)。

Most works in realizing joint attention focused on aspects of responding to joint attention (RJA) only. They have approached the problem of RJA from two different angles. One is to build a constructive or learning model of developmental joint attention such that an agent learns the RJA skill through interactions (Carlson and Triesch 2003; Nagai et al. 2003). The other is to build a modular model of joint attention where the RJA skill is preprogrammed for an agent (Kozima and Yano 2001; Thomaz, Berlin, and Breazeal 2005).

关于实现共同注意的研究大多集中在响应共同注意(RJA)方面。它们从两个角度处理RJA问题。一是构建发展性共同注意的构造或学习模型，使代理通过交互学习RJA技能(Carlson 和 Triesch 2003；Nagai 等 2003)。二是构建模块化的共同注意模型，其中RJA技能为预设程序(Kozima 和 Yano 2001；Thomaz、Berlin 和 Breazeal 2005)。

Some work in realizing joint attention (Imai, Ono, and Ishiguro 2003; Scassellati 1999) has also addressed aspects of initiating joint attention (IJA). These works implement IJA with preprogrammed mechanisms involving eye gaze and pointing gestures. To the best of our knowledge, our work is the first to explicitly address aspects of ensuring joint attention and the role it plays in facilitating HRI.

一些关于实现共同注意(Imai、Ono 和 Ishiguro 2003；Scassellati 1999)的工作也涉及主动引发共同注意(IJA)的方面。这些工作通过预设机制实现IJA，涉及眼睛凝视和指点手势。据我们所知，我们的工作是首次明确涉及确保共同注意的方面及其在促进人机交互中的作用。

---

Copyright (c) 2010, Association for the Advancement of Artificial Intelligence (www.aaai.org). All rights reserved.

版权所有(c) 2010，人工智能促进协会(www.aaai.org)。保留所有权利。

---

Figure 1: Joint attention in interaction. An arrow represents an agent and direction of an arrow indicates the agent's attentional focus.

图1:交互中的共同注意。箭头代表代理，箭头的方向表示代理的注意焦点。

![bo_d3cumgbef24c73bbqpn0_1_195_283_624_447_0.jpg](images/bo_d3cumgbef24c73bbqpn0_1_195_283_624_447_0.jpg)

A similar work (Breazeal et al. 2005) probed effects of nonverbal communication in human-robot teamwork and suggested that implicit nonverbal communication positively impacts human-robot task performance. RJA involves nonverbal social cues, such as eye gaze, which acts as transparent communication. One main difference between their work and the first experiment presented here is that we use additional measures to test participants' confidence in task performance.

类似的工作(Breazeal等，2005)探讨了非语言交流在人机团队合作中的作用，并提出隐性非语言交流对人机任务表现具有积极影响。RJA(反应性共同注意)涉及非语言社会线索，如眼神接触，起到透明沟通的作用。他们的工作与本文第一实验的主要区别在于，我们使用了额外的测量方法来测试参与者对任务表现的信心。

In a recent study on engagement, Rich et al. proposed and implemented a model for recognizing engagement in HRI (Rich et al. 2010). The concepts of engagement have a significant overlap with joint attention in interaction. In particular, the event of directed gaze involves aspects of IJA and RJA. Mutual facial gaze concerns EJA, and adjacency pairs are acts that establish connections between interacting agents. Their work has focused on recognition instead of generation of these engagement behaviors.

在最近关于参与度的研究中，Rich等提出并实现了一个识别HRI(人机交互)中参与度的模型(Rich等，2010)。参与度的概念与互动中的共同注意(joint attention)密切相关。特别是，定向凝视事件涉及IJA(主动共同注意)和RJA(反应性共同注意)的方面。互相凝视面部的行为涉及EJA(确保共同注意)，而邻接对则是建立交互代理之间联系的行为。他们的工作主要集中在识别这些参与行为，而非生成这些行为。

## Realization of Joint Attention

## 共同注意的实现

Figure 1 shows a simple depiction of joint attention. The interaction can be described as four steps. First, two agents need to connect to each other before an interaction. The purpose of this is to be aware of each other and to anticipate an upcoming interaction. Second, the initiating agent (the upper one in Fig. 1) initiates joint attention by switching her attention (i.e., gaze) to the object of interest. The initiating agent addresses the object using communicative channels such as pointing gestures or vocal comments. In the meantime, the other agent responds to this joint attention request by switching attention to the referential focus. Third, after initiating joint attention, the initiating agent normally looks back and forth between the responding agent and the referential object to ensure the responding agent attends to the joint attention. The initiating agent may do the ensuring and the addressing processes simultaneously (i.e., switching gaze while pointing to the focus). If the responding agent is not attending to the referential object, the initiating agent tries different ways (e.g., emphasizing gesture or making sounds) to get attention from the responding agent. Finally, the two agents reach joint attention while both attending to the referential focus and then continue the interaction. Importantly, the initiating agent does the ensuring joint attention process (step 3 and 4) periodically during the interaction to maintain joint attention.

图1展示了共同注意的简要示意。该交互可以描述为四个步骤。首先，两个代理在交互前需要建立联系。其目的是相互了解并预期即将发生的交互。第二，发起代理(图1中的上方)通过将注意力(即凝视)转向感兴趣的对象来启动共同注意。发起代理通过指向手势或口头评论等交流渠道指向对象。与此同时，另一代理响应这一共同注意请求，将注意力转向指示焦点。第三，发起代理在启动共同注意后，通常会在响应代理和指示对象之间来回观察，以确保响应代理关注共同注意。发起代理可能同时进行确认和指向的动作(即一边转移凝视一边指向焦点)。如果响应代理没有关注指示对象，发起代理会尝试不同的方法(如强调手势或发出声音)以引起响应代理的注意。最后，两个代理在都关注指示焦点时达成共同注意，然后继续交互。重要的是，发起代理会在整个交互过程中定期执行确认共同注意的步骤(步骤3和4)，以维持共同注意。

Figure 2: A high-level structure of joint attention model.

图2:共同注意模型的高层结构。

![bo_d3cumgbef24c73bbqpn0_1_985_227_602_405_0.jpg](images/bo_d3cumgbef24c73bbqpn0_1_985_227_602_405_0.jpg)

## A computational model of joint attention

## 共同注意的计算模型

We propose a joint-attention model consisting of three components: responding to joint attention (RJA), initiating joint attention (IJA), and ensuring joint attention (EJA) to reflect psychological findings and behavioral observations (Mundy and Newell 2007; Williams et al. 2005). Figure 2 shows the high-level structure of our model. In the model, RJA and IJA run exclusively. However, EJA is an always-on process interacting with IJA to ensure that the other agent attends to the right focus.

我们提出了一个由响应共同注意(RJA)、发起共同注意(IJA)和确保共同注意(EJA)三个部分组成的模型，以反映心理学研究发现和行为观察(Mundy和Newell，2007；Williams等，2005)。图2展示了我们模型的高层结构。在模型中，RJA和IJA是独立运行的。然而，EJA是一个始终激活的过程，与IJA交互，确保另一方关注正确的焦点。

Joint attention involves an agent gazing at or turning to the object referred by the other agent. To do so, this agent first needs to know how the other agent conveys attention and to know where the other agent's attention is. An agent conveys attention using different methods including eye gaze, head orientation, body pose, pointing gestures, or referential words. Moreover, it is normal that an agent uses a combination of several methods at a time to draw attention from the other agent. In our current design, we assumed a responding agent knows the ways that an initiating agent conveys attention. In particular, we have implemented the RJA component to be aware of pointing gestures and referential words.

共同注意涉及一个代理凝视或转向由另一代理指示的对象。为了实现这一点，该代理首先需要了解另一代理传达注意力的方法，以及知道对方的注意力位置。代理传达注意力的方法包括眼神接触、头部朝向、身体姿势、指向手势或指示性词语。此外，代理通常会同时使用多种方法以吸引对方注意。在我们当前的设计中，假设响应代理知道发起代理传达注意力的方法，特别是我们实现的RJA组件能够识别指向手势和指示性词语。

An agent who intends to initiate a joint attention should know the blueprint of the interaction she is going to start. In our design, an initiating agent follows a script that specifies actions that she intends to carry out, phrases she wants to say and she expects from the responding agent, and joint-attention events. A joint-attention event is executed by a finite-state-machine model as Figure 3 shown.

意图发起共同注意的代理应了解其将要启动的交互的蓝图。在我们的设计中，发起代理遵循一份脚本，明确其打算执行的动作、想要说的话以及期望响应代理做出的反应，以及共同注意事件。一个共同注意事件由有限状态机模型执行，如图3所示。

To initiate joint attention, an agent starts with establishing a connection to the other agent. The importance and the need of establishing a connection between interacting agents were pointed out in (Imai, Ono, and Ishiguro 2003; Striano, Reid, and Hoehl 2006). A set of connecting strategies are designed to ensure a connection is established before further interaction. Connecting strategies include uttering (e.g., 'Excuse me') and using bigger gestures (e.g., waving).

为了启动共同注意，代理首先建立与另一代理的连接。文献(Imai、Ono和Ishiguro，2003；Striano、Reid和Hoehl，2006)指出，建立交互代理之间连接的重要性和必要性。设计了一套连接策略，以确保在进一步交互前建立连接。这些策略包括说话(如“打扰一下”)和使用更大动作(如挥手)等。

Figure 3: An integrative model of IJA and EJA.

图3:IJA(主动共同注意)与EJA(确保共同注意)的一体化模型。

![bo_d3cumgbef24c73bbqpn0_2_167_221_682_428_0.jpg](images/bo_d3cumgbef24c73bbqpn0_2_167_221_682_428_0.jpg)

Once a connection is established, the agent addresses the focus with communicative channels. The goal is to orient the other agent's attention to the referential focus so that the two agents could reach joint attention. We designed a set of communicative channels (i.e., addressing strategies) for relocating the other agent's attention. Addressing strategies include eye gaze, pointing gestures, and utterance. This design is supported by psychology and cognitive science findings, and peer design (Imai, Ono, and Ishiguro 2003). Langton argued that not just eye gaze is a central cue to the direction of another's attention, head orientation and pointing gestures are equivalently important (Langton, Watt, and Bruce 2000). Moreover, joint attention is supported by perception of multi-modal social cues, and infants respond more to pointing gestures than gaze (Deák, Fasel, and Movellan 2001). After addressing the focus, the agent checks whether or not joint attention is reached. If not, the agent selects the next available addressing strategy until no strategies are available (i.e., ending in failure to reach joint attention). Otherwise, the agent continues the interaction.

一旦建立连接，代理通过交际渠道与焦点进行交流。目标是引导另一代理的注意力到指涉焦点，以便两者能够达到共同注意。我们设计了一套交际渠道(即指向策略)用于重新引导对方的注意力。指向策略包括眼神接触、指示手势和话语。这一设计得到了心理学和认知科学研究的支持，以及同行的设计(今井、尾野和石黑 2003)。Langton认为，不仅仅是眼神是判断他人注意方向的关键线索，头部朝向和指示手势同样重要(Langton、Watt 和 Bruce 2000)。此外，共同注意还依赖于多模态社会线索的感知，婴儿对指示手势的反应比对眼神的反应更强烈(Deák、Fasel 和 Movellan 2001)。在指向焦点后，代理会检查是否达成了共同注意。如果未达成，代理会选择下一个可用的指向策略，直到没有策略可用(即未能达成共同注意)。否则，代理将继续互动。

Conceptually, EJA could be viewed as two parts: monitoring and ensuring. In practice, monitoring is the behavior of looking back and forth between the other agent and the referential object, and ensuring is using addressing strategies to make sure joint attention is reached.

从概念上讲，EJA(共同注意的主动引导)可以看作两个部分:监控和确保。在实践中，监控是指在另一代理和指涉对象之间来回观察的行为，而确保则是使用指向策略以确保达成共同注意。

## Effects of Responding to Joint Attention on Human-Robot Interaction

## 反应共同注意对人机交互的影响

We designed our RJA experiment to test the following three hypotheses (H1-H3):

我们设计了RJA(反应共同注意)实验，以验证以下三个假设(H1-H3):

- H1: People have a better mental model of a robot when it responds to joint attention requests.

- H1:当机器人响应共同注意请求时，人们对其的认知模型更为清晰。

- H2: People perceive a robot responding to joint attention more competent.

- H2:人们认为响应共同注意的机器人更具能力。

- H3: People perceive a robot responding to joint attention more socially interactive.

- H3:人们认为响应共同注意的机器人在社交互动方面更具互动性。

Figure 4: Simon and the RJA experimental setup.

图4:Simon与RJA实验装置。

![bo_d3cumgbef24c73bbqpn0_2_983_216_603_444_0.jpg](images/bo_d3cumgbef24c73bbqpn0_2_983_216_603_444_0.jpg)

The first hypothesis tries to see if a robot responding to joint attention is more transparent to people. Transparency helps people's understanding of a robot's intention and capacity that further facilitate better HRI. The last two try to reveal that people perceive a robot responding to joint attention in a more positive way, which is important for improving the human-robot relationship.

第一个假设试图验证机器人响应共同注意是否更易被人理解。透明度有助于人们理解机器人的意图和能力，从而促进更好的HRI(人机交互)。后两个假设旨在揭示人们对响应共同注意的机器人持更积极的看法，这对于改善人机关系具有重要意义。

## Robotic platform

## 机器人平台

The robotic platform for this research is the Simon robot (Figure 4). Simon is an upper-torso humanoid robot with two 7-DOF arms, two 4-DOF hands, and a socially expressive head. In addition, Simon has two 2-DOF eyes, eyelids and expressively colorful ears as another channel for communication. Simon is capable of turning its head, eyes, and torso as paying attention and showing pointing gestures. We use Microsoft's SAPI for speech recognition, and use a small grammar designed for the experiment interaction to facilitate recognition.

本研究所用的机器人平台是Simon机器人(见图4)。Simon是一个上半身人形机器人，配备两个7自由度(DOF)手臂、两个4自由度手掌，以及一个具有社交表现力的头部。此外，Simon还配备两个2自由度的眼睛、眼睑和富有表现力的彩色耳朵，作为另一种交流渠道。Simon能够转动头部、眼睛和躯干以表现注意力集中和指示手势。我们使用微软的SAPI进行语音识别，并设计了适用于实验交互的小型语法以便识别。

## Experimental design

## 实验设计

Participants were given a labeling task to associate colors and names with objects (i.e., yellow for banana, green for watermelon, and red for apple). The interaction space was organized as shown in Figure 4. Participants sat across a table to interact with Simon and used pointing gestures (a paper pointer) and speech (e.g., "This is a yellow object.", "The yellow object is a banana.", and "Can you point to the banana?") to label and to test objects. Beside Simon was a white board that listed phrases used in the interaction for participants' reference.

参与者被要求完成标记任务，将颜色与物体(如:香蕉为黄色、西瓜为绿色、苹果为红色)对应。交互空间布局如图4所示。参与者坐在桌子对面，与Simon互动，使用指示手势(如纸质指示棒)和语音(例如:“这是一个黄色的物体。”、“这个黄色的物体是香蕉。”、“你能指向香蕉吗？”)对物体进行标记和测试。Simon旁边有一块白板，列出交互中使用的短语供参与者参考。

## Experimental conditions

## 实验条件

We want to compare a robot with RJA to a robot without RJA and to see how RJA affects performance of an interactive task and people's perception of the robot. We use a between-subject design to compare two groups: with-RJA group and without-RJA group.

我们希望比较具有RJA(反应共同注意)能力的机器人与没有RJA能力的机器人，观察RJA如何影响交互任务的表现以及人们对机器人的感知。采用组间设计，将参与者分为两组:有RJA组和无RJA组。

In the with-RJA group, Simon responds to referential foci (i.e., a pointed or a mentioned known object) by gazing at it. If a referential concept has not been learned yet, Simon will stay focused on the participant. When a participant requests a concept that has not been learned, Simon gazes over all the objects. These gaze behaviors are the basic RJA mechanism for Simon to communicate with participants implicitly. In the without-RJA group, Simon, instead of responding to referential foci, stays focused on the participants as they teach the concepts.

在有RJA组中，Simon会通过凝视指向(如指向或提及已知物体)来响应指涉焦点。如果某个指涉概念尚未学习，Simon会持续关注参与者。当参与者请求尚未学习的概念时，Simon会扫视所有物体。这些凝视行为是Simon用以与参与者进行隐性交流的基本RJA机制。在无RJA组中，Simon不会对指涉焦点做出反应，而是专注于参与者，等待他们教授概念。

In both groups, Simon has two basic behaviors. First, Simon always tracks a participant's face when not paying attention to a referential focus. Second, Simon's ears blink when hearing some utterance. The blinking is not only a way to tell a participant that the speech recognition engine is working but also to make Simon more life-like in terms of social awareness. Note that ear blinking does not mean that Simon understands the concept or what a participant says, and this was explicitly explained to experimental participants.

在两个组中，Simon(西蒙)有两种基本行为。首先，Simon在不关注指示焦点时，总是跟踪参与者的面部。其次，Simon在听到某些话语时会眨耳朵。眨耳不仅是告诉参与者语音识别引擎正在工作的一种方式，也是为了让Simon在社会认知方面更具拟人化。请注意，耳朵的眨动并不意味着Simon理解了某个概念或参与者所说的内容，这一点在实验参与者中已被明确说明。

## Measures

## 测量指标

We had four quantitative measures (M1-M4) to evaluate H1.

我们采用了四个定量指标(M1-M4)来评估假设H1。

- M1: Number of errors during the teaching phase

- M1:教学阶段的错误次数

- M2: Number of confirmations during the teaching phase

- M2:教学阶段的确认次数

- M3: Number of redundant labels during the interaction

- M3:交互过程中多余的标签次数

- M4: Number of interactive steps before recovering errors

- M4:在纠正错误前的交互步骤数

An error is defined as when the human participants either requests a confirmation of a concept that has not been learned or teaches a concept different from the ground true (i.e., labeling the yellow object as an apple). A redundant label is when a participant has made the same label attempt before (no matter the concept had been learned correctly or not). Note that a label attempt did not count as a redundant if it was a repetition due to an utterance not being detected by the speech recognizer.

错误定义为人类参与者请求确认尚未学习的概念，或教授与真实情况不符的概念(例如，将黄色物体标记为苹果)。多余标签指参与者曾经尝试过相同的标签(无论该概念是否已正确学习)。注意，如果标签尝试是由于语音识别未检测到而重复的，则不算作多余标签。

## Results

## 结果

Twenty-four participants were recruited for this experiment. Four of them were discarded due to either speech recognition engine, vision software, or control software crashed during the interaction. All the valid 20 participants (19 males and 1 female) were students from the local campus population and were randomly assigned to either the with-RJA or the without-RJA group (10 in each group). A total of seven participants (four from the with-RJA group and three from the without-RJA group) reported that they did not have any experience related to robotics.

本实验共招募了二十四名参与者。其中四名因语音识别引擎、视觉软件或控制软件在交互过程中崩溃而被淘汰。剩余的20名有效参与者(19男1女)均为本地校园的学生，随机分配到带-RJA(眼动反应)组或不带-RJA组(每组10人)。共有七名参与者(带-RJA组4人，不带-RJA组3人)表示他们没有任何与机器人相关的经验。

Table 1 summarizes results of the quantitative measures, all of which were significantly different between the groups. The significant difference on M1 was mainly due to participants in the without-RJA group tending to teach the robot at their own pace, which was usually too fast. Therefore, more errors were generated during the interaction. Moreover, the result on M4 showed that it took longer for participants in the without-RJA group to identify and to correct errors. This evidence suggested that RJA serves as a good transparency for participants to understand the robot. Without RJA on the robot, participants had hard time to build and to maintain a mental model of the robot. The results also confirm our prior work on nonverbal study with Leo, where people went too fast, and eye gaze was good for getting people to notice errors early and correct them (Breazeal et al. 2005).

表1总结了定量指标的结果，所有指标在两组之间均存在显著差异。M1的显著差异主要是因为不带-RJA组的参与者倾向于以自己的节奏教授机器人，通常速度过快，因此在交互过程中产生了更多错误。此外，M4的结果显示，不带-RJA组的参与者识别和纠正错误所需的时间更长。这些证据表明，RJA(眼动反应)有助于提高参与者对机器人的透明度。没有RJA的机器人使参与者难以建立和维持对机器人的心理模型。结果也验证了我们之前关于Leo(莱奥)非言语研究的工作，即人们行动过快，眼神交流有助于让人们早期注意到错误并进行修正(Breazeal等，2005)。

Table 1: Results of quantitative measures.

表1:定量指标的结果。

<table><tr><td rowspan="2"/><td colspan="2">with-RJA n=10</td><td colspan="2">without-RJA n=10</td><td colspan="2">Significant level</td></tr><tr><td>Mean</td><td>S.D.</td><td>Mean</td><td>S.D.</td><td>t</td><td>p<</td></tr><tr><td>M1</td><td>0.2</td><td>0.42</td><td>2.9</td><td>2.51</td><td>4.98</td><td>0.001</td></tr><tr><td>M2</td><td>4.5</td><td>1.18</td><td>9.8</td><td>5.98</td><td>6.27</td><td>0.001</td></tr><tr><td>M3</td><td>2.8</td><td>3.74</td><td>7.8</td><td>10.69</td><td>6.00</td><td>0.001</td></tr><tr><td>M4</td><td>0.8</td><td>1.93</td><td>20.3</td><td>34.2</td><td>10.86</td><td>0.001</td></tr></table>

<table><tbody><tr><td rowspan="2"></td><td colspan="2">带有-RJA n=10</td><td colspan="2">不带-RJA n=10</td><td colspan="2">显著性水平</td></tr><tr><td>平均值</td><td>标准差</td><td>平均值</td><td>标准差</td><td>t</td><td>p<</td></tr><tr><td>M1</td><td>0.2</td><td>0.42</td><td>2.9</td><td>2.51</td><td>4.98</td><td>0.001</td></tr><tr><td>M2</td><td>4.5</td><td>1.18</td><td>9.8</td><td>5.98</td><td>6.27</td><td>0.001</td></tr><tr><td>M3</td><td>2.8</td><td>3.74</td><td>7.8</td><td>10.69</td><td>6.00</td><td>0.001</td></tr><tr><td>M4</td><td>0.8</td><td>1.93</td><td>20.3</td><td>34.2</td><td>10.86</td><td>0.001</td></tr></tbody></table>

Figure 5: Results of post-questionnaire.

图5:问卷后结果。

![bo_d3cumgbef24c73bbqpn0_3_934_571_709_346_0.jpg](images/bo_d3cumgbef24c73bbqpn0_3_934_571_709_346_0.jpg)

Getting joint attention responses from Simon helped participants in the with-RJA group have a better idea of whether Simon had learned the concepts or not. This was supported by findings on M3 that participants in the without-RJA group had significantly more redundant labels than the with-RJA group. Lack of responses from Simon caused participants to label multiple times to ensure that Simon learned the concepts. Also, participants in the without-RJA group requested more confirmations from Simon until they felt confident that Simon learned the concepts (M2). In contrast, in the with-RJA group, participants requested less than six times (i.e., one for each concept), which can be viewed as a baseline. This showed that participants in the with-RJA group had a better understanding of the robot's internal states (i.e., concepts learned or not).

从西蒙(Simon)获得的共同注意反应帮助参与者在有-RJA组中更好地判断西蒙是否学会了概念。这一点得到了M3的发现支持，即无-RJA组的参与者比有-RJA组的参与者标注了更多冗余标签。西蒙没有回应导致参与者多次标注，以确保西蒙学会了概念。此外，无-RJA组的参与者在感到确信西蒙已学会概念之前，向西蒙请求了更多确认(M2)。相比之下，有-RJA组的参与者请求确认的次数少于六次(即每个概念一次)，这可以视为基线。这表明有-RJA组的参与者对机器人内部状态(即学会了还是未学会概念)有更好的理解。

In addition to the quantitative measures, a post-experiment questionnaire shed light on how participants perceived the interaction and the robot. As shown in Figure 5, participants perceived a robot responding to joint attention as more competent and socially interactive. Moreover, results of self-report survey were also consistent with quantitative measures and the questionnaire results. Most participants in the with-RJA group reported that gaze or head orientation were their cues, while participants in the without-RJA group commented that they were frustrated and had tough time telling whether Simon had learned the concepts.

除了定量测量外，实验后问卷还揭示了参与者对互动和机器人的看法。如图5所示，参与者认为响应共同注意的机器人更具能力和社交互动性。此外，自我报告调查的结果也与定量测量和问卷结果一致。大多数有-RJA组的参与者表示，他们的线索是凝视或头部朝向，而无-RJA组的参与者则评论说他们感到沮丧，很难判断西蒙是否学会了概念。

Video analysis of behaviors of participants also confirmed the hypotheses and gave insights to natural HRI. Three interesting observations were found in both groups. First, participants tended to look back and forth between the referred object and Simon's face (i.e., EJA) to see if Simon understood the concepts. This observation footed the hypothesis that EJA is needed in natural HRI. Second, participants showed RJA (i.e., followed Simon's pointing gesture) when Simon initiated a joint attention (i.e., pointed to the object of request). This observation revealed that it is natural for humans to attend to or respond to joint attention initiated by the other partner. Third, participants tended to give positive or negative responses to the robot. For example, when Simon pointed to the right object, participants nodded, smiled, laughed, or even said positive words, such as "good." Also participants frowned or said negative words such as "no" when Simon pointed to a wrong object. These observations may indicate that humans tend to give responses or feedback to their partners either explicitly (i.e., utterance) or implicitly (i.e., facial expressions).

对参与者行为的视频分析也证实了假设，并为自然人机交互(HRI)提供了见解。在两个组中发现了三个有趣的观察。首先，参与者倾向于来回观察被指对象和西蒙的脸(即EJA)，以判断西蒙是否理解了概念。这一观察支持了EJA在自然HRI中的必要性假设。第二，当西蒙发起共同注意(即指向请求对象)时，参与者表现出RJA(即跟随西蒙的指示动作)。这一观察表明，人类自然会关注或回应由对方发起的共同注意。第三，参与者倾向于对机器人给予正面或负面反应。例如，当西蒙指向右侧的对象时，参与者点头、微笑、笑或甚至说“好”。当西蒙指向错误的对象时，参与者皱眉或说“不要”。这些观察可能表明，人类倾向于以明确(即话语)或隐晦(即面部表情)的方式对伙伴做出反应或反馈。

## The Importance of Ensuring Joint Attention in Human-Robot Interaction

## 确保人机交互中共同注意的重要性

We hypothesize that ensuring joint attention (EJA) affects task performance. Moreover, psychological findings (Mundy and Newell 2007; Williams et al. 2005) and our observations in experiment 1 drive us to believe that ensuring joint attention is a natural behavior that humans do. Therefore, we have two hypotheses (H4 and H5) as follows:

我们假设确保共同注意(EJA)影响任务表现。此外，心理学研究(Mundy和Newell 2007；Williams等，2005)以及我们在实验1中的观察使我们相信，确保共同注意是一种人类的自然行为。因此，我们提出两个假设(H4和H5)如下:

- H4: When a robot ensures joint attention it yields better interactive task performance.

- H4:当机器人确保共同注意时，其交互任务表现会更好。

- H5: Ensuring joint attention is perceived as a natural behavior in social interaction with a robot.

- H5:确保共同注意被视为与机器人进行社交互动中的一种自然行为。

## Experimental design

## 实验设计

To test these hypotheses we did a video-based experiment. Participants were given a task to rank a collection of videos where Simon used varying degrees of ensuring joint attention in three different scenarios. The first scenario (presentation) was Simon, as a tour guide robot, giving a presentation to a person. The second scenario (reception) was Simon, as a service robot, received a guest at a reception desk. And the third scenario (directions) was Simon, as a guide robot, directing a person to the restroom in a building.

为了验证这些假设，我们进行了基于视频的实验。参与者被要求对一系列视频进行排序，这些视频中西蒙在三种不同场景下采用不同程度的确保共同注意的方式。第一种场景(演示)是西蒙作为导览机器人，为一人做演示。第二种场景(接待)是西蒙作为服务机器人，在接待台接待客人。第三种场景(指引)是西蒙作为导游，指引一人前往建筑物的洗手间。

The presentation scenario was used to verify H4 and H5. The reception scenario was to verify \( \mathrm{H}4 \) , and the directions scenario was to verify H5. In the presentation and reception scenarios, the person in the videos was distracted by some event (i.e., a cell phone call or dropping off a cup of water) during the interaction. Simon responded to the distracting events with four different degrees of EJA in the videos: 1) monitoring and ensuring \( \left( {\mathrm{{mle}}1}\right) ,2) \) monitoring but not ensuring \( \left( {\mathrm{m}1\mathrm{e}0}\right) ,3) \) no monitoring but ensuring(m0e1), and 4) no monitoring and no ensuring(m0e0).

演示场景用于验证H4和H5。接待场景用于验证\( \mathrm{H}4 \)，而指引场景用于验证H5。在演示和接待场景中，视频中的人被某些事件(如手机电话或掉水杯)分散注意力。在视频中，西蒙对干扰事件的反应表现出四个不同程度的EJA:1)监控并确保\( \left( {\mathrm{{mle}}1}\right) ,2) \)监控但不确保\( \left( {\mathrm{m}1\mathrm{e}0}\right) ,3) \)不监控但确保(m0e1)，以及4)不监控也不确保(m0e0)。

We use a within-subjects design to measure how people perceive the effectiveness of communication and naturalness of behaviors of a robot in HRI. To minimize order effects on results, we randomly sorted the videos into three different groups (i.e., different orders).

我们采用被试内设计，测量人们对机器人在HRI中的沟通效果和行为自然性的感知。为了减少顺序效应的影响，我们将视频随机分成三组(即不同的顺序)。

## Results

## 结果

Fifteen participants were recruited for this experiment. All 15 participants ( 9 males and 6 females) were students from local campus population and were randomly assigned to one of the three groups (five participants in each group). A total of seven participants reported that they had not had experience related to robotics before the experiment.

本实验共招募了十五名参与者。所有15名参与者(9名男性和6名女性)均为本地校园学生，随机分配到三个组中的任意一组(每组五人)。共有七名参与者表示在实验前没有机器人相关的经验。

For both the presentation and the reception scenarios, participants were asked (1) how well the person in the videos can recall or receive the information from the robot and (2) how good the robot was at communicating information. We used the chi-square test for goodness of fit to test participants' first choices to each question. The null hypothesis was that the distribution of people's votes on varying EJA behavior variations is even with respect to those questions. We used the chi-square test to test if the real distribution is significantly different from the even distribution. The significant difference tells us that EJA behaviors would actually affect people's perception of the robot. The results indicated that the full EJA behavior (i.e., m1e1) is the most desirable behavior with respect to the two questions (both significant level at 0.01 ). The result supported H4 that a robot ensuring joint attention yields better performance in an interactive task. In our scenarios, better performance came from better communications, which is also true in interactive tasks in general.

在展示和接收场景中，参与者被问及(1)视频中的人对机器人传递或接收信息的理解程度，以及(2)机器人在信息交流方面的表现。我们采用卡方拟合优度检验，检验参与者对每个问题的首选答案。零假设是关于不同EJA(共同注意行为)变化的投票分布在这些问题上是均匀的。我们使用卡方检验来判断实际分布是否显著偏离均匀分布。显著差异表明，EJA行为实际上会影响人们对机器人的感知。结果显示，完整的EJA行为(即m1e1)在两个问题上都是最理想的行为(均显著水平为0.01)。这一结果支持假设H4，即确保共同注意的机器人在交互任务中表现更佳。在我们的场景中，更好的表现源于更有效的沟通，这在一般的交互任务中也是如此。

For both the presentation and the directions scenarios, participants were asked how well Simon engaged the person in the videos. The result showed that the full EJA behavior is the most desirable behavior with respect to engaging the other agent (the chi-square test for goodness of fit, significant level at 0.01 ). In addition, participants were asked to rank the videos according to how similar the robot's behaviors are to theirs if they were asked to perform the same task. The result revealed that the full EJA behavior is the most similar behavior to theirs (the chi-square test for goodness of fit, significant level at 0.01 , suggesting that full EJA is more natural to humans. The results supported H5 that ensuring joint attention is a natural behavior that people do in interaction.

在展示和指引场景中，参与者被问及Simon在视频中与对方的互动程度。结果显示，完整的EJA行为在吸引对方方面是最理想的(卡方拟合优度检验，显著水平为0.01)。此外，参与者被要求根据机器人行为与他们自己执行相同任务时的相似程度对视频进行排名。结果显示，完整的EJA行为与他们的行为最为相似(卡方拟合优度检验，显著水平为0.01)，表明完整的EJA行为对人类来说更自然。结果支持假设H5，即确保共同注意是一种人们在交互中自然会表现的行为。

Furthermore, for all three scenarios, participants were asked to rank the videos according to their preference if they were asked to design behaviors for a robot in similar scenarios. For both the presentation and reception scenarios, 14 out of 15 participants agreed that the full EJA behavior is the most desirable one, while 13 participants agreed the same for the directions scenario (the chi-square test for goodness of fit, all significant level at 0.01 ). This result did not directly support our hypothesis on naturalness of behavior. However, the result that people would like to have EJA behaviors on a robot may imply people perceive EJA behaviors as more affective and natural behaviors.

此外，在所有三个场景中，参与者被要求根据偏好对视频进行排名，假如他们被要求为类似场景中的机器人设计行为。在展示和接收场景中，15名参与者中有14人认为完整的EJA行为是最理想的，而在指引场景中，有13人持相同观点(卡方拟合优度检验，全部显著水平为0.01)。这一结果并未直接支持我们关于行为自然性的假设。然而，参与者希望机器人具备EJA行为的结果可能暗示他们认为EJA行为更具情感性和自然性。

In the survey of each scenario, participants were asked to comment on the differences they observed and how they liked or disliked the videos. These comments give us insight that it was in fact the ensuring joint attention behaviors that were playing into people's rankings and choices. For the presentation scenario, all participants commented that they noticed a difference where Simon made sure the person was paying attention before the presentation versus not, such as "waited and made sure that the guest is paying attention before moving on". Twelve participants noted another difference where Simon looked at the user occasionally versus not. Participants often used phrases such as "make eye contact", "engage user", and "recapture attention" to describe the looking back and forth behavior. Similar to the presentation scenario, most participants noticed the two main differences in the reception scenario. Also in the directions scenario, most participants (13) noticed the difference was if the robot turned to the person during interaction. Twelve out of 13 participants commented this behavior in a positive way. For example, "good communication" and "is mostly how normal people would behave." However, one participant described the behavior as "unnecessary head turns" showing an alternative perspective. In sum, participants' comments on the videos supported data from the survey. Participants preferred behaviors involving ensuring joint attention and believed those are natural behaviors that humans do.

在每个场景的调查中，参与者被问及他们观察到的差异以及他们对视频的喜欢或不喜欢。这些评论让我们了解到，实际上是确保共同注意的行为影响了人们的排名和选择。在展示场景中，所有参与者都提到他们注意到一个差异，即Simon在演示前确保对方在注意力集中，比如“等待并确认宾客在注意力集中”之类的描述。十二名参与者还注意到另一个差异，即Simon偶尔会看向用户。参与者常用“眼神交流”、“互动”以及“重新吸引注意力”等短语来描述这种来回观察的行为。与展示场景类似，大多数参与者在接收场景中也注意到两个主要差异。此外，在指引场景中，大部分参与者(13人)注意到机器人在互动中转向对方的行为。13人中有12人对此持积极评价，例如“良好的沟通”以及“这基本是正常人会表现出的行为”。然而，一名参与者描述这种行为为“无必要的头部转动”，展现了另一种观点。总的来说，参与者对视频的评论支持了调查中的数据。参与者偏好涉及确保共同注意的行为，并认为这些是人类在交互中自然会表现的行为。

## Future Direction

## 未来方向

There are still several issues that we have not addressed in current model. First, when and how frequently should a robot need to do ensuring joint attention (EJA) (i.e., monitoring and ensuring) in an interaction? Even though results of the second study has suggested that EJA behavior is natural, we believe that it is natural only when it happens at the time and frequency that meet people's expectation. Second, the model needs to consider dynamics of a crowd to handle interactions with a group of people. We believe that interaction with a person is quite different from interaction with a group of people. For example, instead of ensuring everyone in the group is paying attention, a robot may just need to engage most people in the group. In addition, the strategies for getting attention from a group may be different. More studies are needed to explore dynamics of crowd. Third, a robot should be able to learn strategies through interactions with humans and use strategies adaptively according to situations and the person it is interacting with. Humans have different ways to interact with different people in different situations. To be in a human environment, robots need the ability to adapt themselves.

目前模型仍存在一些未解决的问题。首先，机器人在交互中何时以及多频繁地进行确保共同注意(EJA)(即监控和确保)？尽管第二项研究的结果表明EJA行为是自然的，但我们认为只有在符合人们期望的时间和频率发生时，它才是自然的。第二，模型需要考虑人群的动态，以应对与一群人互动的情况。我们相信与个人的互动与与一群人的互动截然不同。例如，机器人可能只需要让大多数人注意到，而不必确保每个人都在关注。此外，吸引群体注意力的策略可能也不同。需要更多研究来探索人群的动态。第三，机器人应能够通过与人类的互动学习策略，并根据情况和交互对象的不同，灵活运用策略。人类在不同情境下与不同人有不同的互动方式。为了适应人类环境，机器人需要具备自我调整的能力。

## Conclusion

## 结论

The contribution of this work is threefold. First, we propose a computational model of joint attention consisting of responding to joint attention, initiating joint attention, and ensuring joint attention. This decomposition is supported by psychological findings and matches the developmental time-line of infancy. Second, in the experiment of exploration of effects of responding to joint attention on human-robot interaction, we found that robots responding to joint attention are more transparent to humans and are more competent and socially interactive. Third, in the experiment of study of the importance of ensuring joint attention in human-robot interaction, we learned that robots ensuring joint attention yield better performance in human-robot interactive tasks and ensuring joint attention behaviors are perceived as natural behaviors by humans. References

本工作的贡献有三方面。首先，我们提出了一个由响应共同注意、发起共同注意和确保共同注意组成的计算模型。这一分解得到了心理学研究的支持，并与婴儿发育的时间线相符。第二，在探索响应共同注意对人机交互影响的实验中，我们发现响应共同注意的机器人对人类更具透明性，更加胜任且具有社会互动能力。第三，在研究确保共同注意在人工智能交互中的重要性的实验中，我们了解到，确保共同注意的机器人在任务中表现更优，且人类认为其表现的共同注意行为更自然。参考文献

Baron-Cohen, S. 1997. Mindblindness: An essay on autism and theory of mind. Cambridge, Massachusetts: The MIT Press.

Baron-Cohen, S. 1997. 心盲:关于自闭症与心智理论的论文。麻省剑桥:麻省理工学院出版社。

Breazeal, C.; Kidd, C. D.; Thomaz, A. L.; Hoffman, G.; and Berlin, M. 2005. Effects of nonverbal communication on efficiency and robustness in human-robot teamwork. In in IEEE/RSJ International Conference on Intelligent Robots and Systems (IROS, 383-388.

Breazeal, C.; Kidd, C. D.; Thomaz, A. L.; Hoffman, G.; 和 Berlin, M. 2005. 非语言交流对人机团队合作效率与鲁棒性的影响。在IEEE/RSJ国际智能机器人与系统会议(IROS)中，页383-388。

Carlson, E., and Triesch, J. 2003. A computational model of the emergence of gaze following. In Bowman, H., and Labiouse, C., eds., In Connectionist models of cognition and perception II, 105-114. World Scientific.

Carlson, E., 和 Triesch, J. 2003. 凝视追随出现的计算模型。在Bowman, H. 和 Labiouse, C. 编，认知与感知的连接主义模型II，页105-114。世界科学出版社。

Deák, G. O.; Fasel, I.; and Movellan, J. 2001. The emergence of shared attention: Using robots to test developmental theories. In In Proceedings 1st International Workshop on Epigenetic Robotics: Lund University Cognitive Studies, 95-104.

Deák, G. O.; Fasel, I.; 和 Movellan, J. 2001. 共享注意的出现:利用机器人测试发展理论。在第一届表观遗传机器人国际研讨会论文集:隆德大学认知研究，页95-104。

Imai, M.; Ono, T.; and Ishiguro, H. 2003. Physical relation and expression: Joint attention for human-robot interaction. IEEE Transaction on Industrial Electronics 50(4):636-643.

Imai, M.; Ono, T.; 和 Ishiguro, H. 2003. 物理关系与表达:人机交互中的共同注意。IEEE工业电子学报，50(4):636-643。

Kaplan, F., and Hafner, V. V. 2006. The challenges of joint attention. Interaction Study 7(2):135-169.

Kaplan, F., 和 Hafner, V. V. 2006. 共同注意的挑战。交互研究，7(2):135-169。

Kozima, H., and Yano, H. 2001. A robot that learns to communicate with human caregivers. In In Proceedings 1st International Workshop on Epigenetic Robotics: Lund University Cognitive Studies.

Kozima, H., 和 Yano, H. 2001. 学习与人类照料者沟通的机器人。在第一届表观遗传机器人国际研讨会论文集:隆德大学认知研究。

Langton, S. R. H.; Watt, R. J.; and Bruce, V. 2000. Do the eyes have it? Cues to the direction of social attention. Trends in Cognitive Sciences 4(2):50-59.

Langton, S. R. H.; Watt, R. J.; 和 Bruce, V. 2000. 眼睛能表达意图吗？社会注意方向的线索。认知科学趋势，4(2):50-59。

Mundy, P., and Newell, L. 2007. Attention, Joint Attention, and Social Cognition. Current Directions Psychological Science 16(5):269-274.

Mundy, P., 和 Newell, L. 2007. 注意、共同注意与社会认知。心理科学的当前方向，16(5):269-274。

Nagai, Y.; Y, K. H.; Morita, A.; and Y, M. A. 2003. A constructive model for the development of joint attention. Connection Science 15:211-229.

Nagai, Y.; Y, K. H.; Morita, A.; 和 Y, M. A. 2003. 共同注意发展的构建模型。连接科学，15:211-229。

Rich, C.; Ponsleur, B.; Holroyd, A.; and Sidner, C. L. 2010. Recognizing engagement in human-robot interaction. In HRI '10: Proceeding of the 5th ACM/IEEE international conference on Human-robot interaction, 375-382. New York, NY, USA: ACM.

Rich, C.; Ponsleur, B.; Holroyd, A.; 和 Sidner, C. L. 2010. 识别人机交互中的参与度。在HRI '10:第5届ACM/IEEE人机交互国际会议论文集，页375-382。纽约，美国:ACM。

Scassellati, B. 1999. Imitation and mechanisms of joint attention: A developmental structure for building social skills on a humanoid robot. In Computation for Metaphors, Analogy, and Agents. Springer Berlin. 176-195.

Scassellati, B. 1999. 模仿与共同注意机制:构建人形机器人社会技能的发育结构。在“隐喻、类比与代理”计算研究中。施普林格柏林。第176-195页。

Striano, T.; Reid, V. M.; and Hoehl, S. 2006. Neural mechanisms of joint attention in infancy. The European journal of neuroscience 23(10):2819-23.

Striano, T.; Reid, V. M.; and Hoehl, S. 2006. 婴儿期共同注意的神经机制。欧洲神经科学杂志 23(10):2819-23。

Thomaz, A. L.; Berlin, M.; and Breazeal, C. 2005. An embodied computational model of social referencing. In \( {In} \) IEEE International Workshop on Human Robot Interaction.

Thomaz, A. L.; Berlin, M.; and Breazeal, C. 2005. 一种具象化的社会参照(social referencing)计算模型。在\( {In} \) IEEE国际人机交互研讨会(IEEE International Workshop on Human Robot Interaction)。

Williams, J. H.; Waiter, G. D.; Perra, O.; Perrett, D. I.; and Whiten, A. 2005. An fMRI study of joint attention experience. NeuroImage 25(1):133-140.

Williams, J. H.; Waiter, G. D.; Perra, O.; Perrett, D. I.; and Whiten, A. 2005. 一项关于共同注意(joint attention)体验的功能性磁共振成像(fMRI)研究。神经影像(NeuroImage) 25(1):133-140。