Article

記事

# Detecting Groups and Estimating F-Formations for Social Human-Robot Interactions

# 社会的ヒューマンロボットインタラクションにおけるグループ検出とF形成の推定

Sai Krishna Pathi * D, Andrey Kiselev # and Amy Loutfi

Sai Krishna Pathi * D、Andrey Kiselev #、Amy Loutfi

Center for Applied Autonomous Sensor Systems (AASS), School of Science and Technology, Örebro University, 701 82 Örebro, Sweden; andrey.kiselev@oru.se (A.K.); amy.loutfi@oru.se (A.L.)

応用自律センサーシステムセンター(AASS)、科学技術学部、オレブロ大学、701 82 オレブロ、スウェーデン；andrey.kiselev@oru.se(A.K.)；amy.loutfi@oru.se(A.L.)

* Correspondence: sai.krishna@oru.se

* 連絡先:sai.krishna@oru.se

Abstract: The ability of a robot to detect and join groups of people is of increasing importance in social contexts, and for the collaboration between teams of humans and robots. In this paper, we propose a framework, autonomous group interactions for robots (AGIR), that endows a robot with the ability to detect such groups while following the principles of F-formations. Using on-board sensors, this method accounts for a wide spectrum of different robot systems, ranging from autonomous service robots to telepresence robots. The presented framework detects individuals, estimates their position and orientation, detects groups, determines their F-formations, and is able to suggest a position for the robot to enter the social group. For evaluation, two simulation scenes were developed based on the standard real-world datasets. The 1st scene is built with 20 virtual agents (VAs) interacting in 7 different groups of varying sizes and 3 different formations. The 2nd scene is built with 36 VAs, positioned in 13 different groups of varying sizes and 6 different formations. A model of a Pepper robot is used in both simulated scenes in randomly generated different positions. The ability for the robot to estimate orientation, detect groups, and estimate F-formations at various locations is used to determine the validation of the approaches. The obtained results show a high accuracy within each of the simulated scenarios and demonstrates that the framework is able to work from an egocentric view with a robot in real time.

概要:ロボットが人々のグループを検出し参加する能力は、社会的文脈や人間とロボットのチーム間の協力においてますます重要になっている。本論文では、F形成の原則に従いながら、ロボットにそのようなグループを検出する能力を付与する自律的グループインタラクションのフレームワーク(AGIR)を提案する。この方法は、搭載センサーを用いて、サービスロボットから遠隔操作ロボットまで、さまざまなロボットシステムに対応できる。提示されたフレームワークは、個人を検出し、その位置と向きを推定し、グループを検出し、F形成を決定し、ロボットが社会的グループに参加するための位置を提案できる。評価のために、標準的な実世界データセットに基づいて2つのシミュレーションシーンを作成した。第1のシーンは、7つの異なるサイズと3つの異なる形成のグループで相互作用する20の仮想エージェント(VA)で構成されている。第2のシーンは、36のVAが13の異なるサイズと6つの異なる形成のグループに配置されている。両シーンともに、ランダムに生成された異なる位置にPepperロボットのモデルを使用した。ロボットが向きを推定し、グループを検出し、さまざまな場所でF形成を推定する能力を用いて、アプローチの妥当性を評価した。得られた結果は、各シナリオで高い精度を示し、リアルタイムでロボットの自己中心的視点から動作できることを示している。

Keywords: human-robot interaction; social robotics; F-formations; group interactions; Kendon formations

キーワード:ヒューマンロボットインタラクション；社会的ロボティクス；F形成；グループインタラクション；Kendon形成

## 1. Introduction

## 1. はじめに

Group interactions are common and occur naturally in human interactions. A mobile robot with social interaction capabilities must be able to engage in dyadic interactions (a robot and a human) or group interactions (a robot and multiple humans). To promote a conducive interaction, robots should adhere to the norms and behaviours in group interactions. To this end, mobile robots need to develop methods to follow socially appropriate behaviour, such as joining the group interaction in a manner that is acceptable to humans.

グループインタラクションは一般的であり、人間の交流において自然に発生するものである。社会的な交流能力を持つ移動ロボットは、二者間のインタラクション(ロボットと人間)やグループインタラクション(ロボットと複数の人間)に参加できる必要がある。円滑な交流を促進するために、ロボットはグループインタラクションにおいて人間に受け入れられる方法で参加し、社会的に適切な行動や規範を遵守すべきである。そのため、移動ロボットは、社会的に適切な行動を追従する方法を開発する必要がある。例えば、グループに適切に近づく方法や、交流中に適切な距離を保つ方法などである。

In the literature, a lot of focus has been dedicated to dyadic interaction [1] and less so on group interaction per se [2]. For example, there are works which aim to design models for robots to appropriately approach a human to initiate a conversation [3,4] and to maintain appropriate distance with a human during interaction [5]. With a recent shift of focus towards group interaction, however, new application areas have emerged, such as surveillance \( \left\lbrack  {6 - 8}\right\rbrack \) , playing games with groups of people \( \left\lbrack  {9,{10}}\right\rbrack \) , studying human behaviour in a group interaction [2,11], and tracking groups [12-15]; while relevant for understanding group dynamics, there still remains a gap in the research on how to ensure that robots are able to join an ongoing group interaction. Most of the works mentioned here do not use a robot in their experiments and some works which do use a robot consider the robot to be a part of the group.

文献では、二者間のインタラクションに多くの焦点が当てられており[1]、グループインタラクションそのものにはあまり焦点が当てられていない[2]。例えば、ロボットが人間に適切に接近して会話を始めるモデルを設計する研究[3,4]や、交流中に人間との適切な距離を維持する研究[5]がある。しかし、最近の焦点の移行により、監視<バ0></バ0>、グループでのゲームプレイ<バ1></バ1>、グループインタラクションにおける人間の行動研究[2,11]、グループの追跡[12-15]など、新たな応用分野が出現している。これらはグループダイナミクスの理解に役立つが、ロボットが進行中のグループインタラクションに参加できるようにする方法についての研究には依然としてギャップが存在している。ここで述べた研究の多くはロボットを実験に使用しておらず、ロボットをグループの一部とみなす研究もある。

---

check for updates

更新情報を確認

Citation: Pathi, S.K.; Kiselev, A.; Loutfi, A. Detecting Groups and Estimating F-Formations for Social Human-Robot Interactions. Multimodal Technol. Interact. 2022, 6, 18. https://doi.org/10.3390/ mti6030018

引用:Pathi, S.K.; Kiselev, A.; Loutfi, A. Detecting Groups and Estimating F-Formations for Social Human-Robot Interactions. Multimodal Technol. Interact. 2022, 6, 18. https://doi.org/10.3390/mti6030018

Academic Editor: Mu-Chun Su

学術編集者:Mu-Chun Su

Received: 16 December 2021

受理日:2021年12月16日

Accepted: 18 February 2022

採択日:2022年2月18日

Published: 23 February 2022

公開日:2022年2月23日

Publisher's Note: MDPI stays neutral with regard to jurisdictional claims in published maps and institutional affiliations.

出版社の注記:MDPIは、公開された地図や機関の所属に関する管轄権の主張について中立的な立場を取ります。

Copyright: (c) 2022 by the authors. Licensee MDPI, Basel, Switzerland. This article is an open access article distributed under the terms and conditions of the Creative Commons Attribution (CC BY) license (https:// creativecommons.org/licenses/by/ 4.0/).

著作権:2022年、著者により。ライセンシー:MDPI、バーゼル、スイス。本稿は、クリエイティブ・コモンズ 表示(CC BY)ライセンス(https://creativecommons.org/licenses/by/4.0/)の条件の下で配布されるオープンアクセス記事です。

---

For a robot to join an ongoing group interaction, both group detection and group pattern identification are important aspects to be considered. Two theories dominate in the literature, namely proxemics and F-formations. Proxemics was proposed by Hall and considers the interpersonal distances between people in a face-to-face interaction [16]. Kendon proposed the theory of F-formations [17,18], which are said to arise "... whenever two or more people sustain a spatial and orientational relationship in which the space between them is one to which they have equal, direct and exclusive access." (p. 209, [17]). These are spatial (group) patterns in which people configure themselves during social interactions. These theories are discussed in-detail in Section 2.1.

ロボットが進行中のグループインタラクションに参加するためには、グループ検出とグループパターンの識別の両方が重要な側面です。文献では、主にプロクセミクスとFフォーメーションの二つの理論が支配的です。プロクセミクスはハルによって提案され、対面での相互作用における人々間の距離を考慮します[16]。ケンドンはFフォーメーションの理論を提案し[17,18]、「二人以上の人々が空間的および方位的関係を維持し、その間の空間に対して平等で直接的かつ排他的なアクセス権を持つ場合に生じる」と述べています(p. 209、[17])。これらは社会的相互作用中に人々が自己配置を行う空間(グループ)パターンです。これらの理論については、セクション2.1で詳述します。

In this context, most of the functional models which consider group detection rely on cameras placed externally in the scene, that makes these systems impractical or unfeasible to implement on a mobile robot [1].

この文脈では、グループ検出を考慮した多くの機能モデルは、シーン内に外部に設置されたカメラに依存しており、これによりこれらのシステムは実用的または実現不可能となる場合があります[1]。

Additionally, other methods rely on learning algorithms, which requires training models on large datasets of diverse group interactions [13-15,19]. The number of people in the groups and the number of groups in the scene are not constant and vary accordingly, i.e., people could leave/join a group or a group could leave/join the scene. The exocentric approaches also raise significant privacy concerns [20-25].

さらに、他の方法は学習アルゴリズムに依存しており、多様なグループインタラクションの大規模データセットでモデルを訓練する必要があります[13-15,19]。グループ内の人数やシーン内のグループ数は一定ではなく、状況に応じて変動します。つまり、人々がグループを離脱・参加したり、グループがシーンから離脱・参加したりする可能性があります。外中心的アプローチは、プライバシーの懸念も引き起こします[20-25]。

Regarding group patterns estimation, not many functional models are proposed. Some of our works \( \left\lbrack  {{26},{27}}\right\rbrack \) are proposed to estimate \( \mathrm{F} \) -formations, but study small groups sizes, i.e., two or three people per group. Recently, few works are proposed in regards to mobile robot using on-board sensors to interact with group. However, the number of groups in the scene is limited, i.e., one group [28] and two groups [29] with only two or three people per group, and limited patterns, i.e., four patterns, were studied. These research gaps suggest a need for robot-centric approaches, which detect groups and estimate F-formations to join the ongoing social group interactions in the scene.

グループパターンの推定に関しては、多くの機能モデルは提案されていません。私たちの研究の一部は\( \left\lbrack  {{26},{27}}\right\rbrack \)、\( \mathrm{F} \)のフォーメーションを推定するために提案されていますが、小規模なグループ(2人または3人)を対象としています。最近では、搭載センサーを用いてグループと対話するモバイルロボットに関する研究は少なく、シーン内のグループは1つ[28]、2つ[29]のみで、各グループは2〜3人、パターンも4つに限定されています。これらの研究のギャップは、シーン内の進行中の社会的グループインタラクションに参加するために、グループを検出しFフォーメーションを推定するロボット中心のアプローチの必要性を示唆しています。

To address these gaps, we propose a new framework called autonomous group interactions for robots (AGIR), for a robot to join ongoing social group interactions from an egocentric perspective. The framework comprises four main steps-processing egocentric data, detecting groups, estimating F-formations, and estimating optimal position for the robot in the group to join the interactions. While processing egocentric data, the robot perceives the scene using on-board sensors and extracts hand-engineered features. These features are used to detect groups in the scene in the second step. In the third step, the robot recognizes the patterns of the groups by estimating F-formations. Finally, in the fourth step, the robot finds the optimal spot and joins the ongoing social group interactions, as shown in Figure 1. The steps in the red rectangle in the figure are addressed in this paper.

これらのギャップに対応するために、私たちはロボットのための自律的グループインタラクション(AGIR)と呼ばれる新しいフレームワークを提案します。このフレームワークは、ロボットが自己中心的な視点から進行中の社会的グループインタラクションに参加することを目的としています。フレームワークは、自己中心データの処理、グループの検出、Fフォーメーションの推定、ロボットがインタラクションに参加するための最適な位置の推定の4つの主要なステップで構成されています。自己中心データの処理では、ロボットは搭載センサーを用いてシーンを認識し、手作業で設計された特徴を抽出します。これらの特徴は、次のステップでシーン内のグループを検出するために使用されます。第3のステップでは、ロボットはFフォーメーションを推定してグループのパターンを認識します。最後に、第4のステップで、ロボットは最適な位置を見つけて進行中の社会的グループインタラクションに参加します(図1参照)。図の赤枠内のステップは本論文で扱います。

![bo_d3ecpr4601uc738ioje0_1_461_1520_1093_270_0.jpg](images/bo_d3ecpr4601uc738ioje0_1_461_1520_1093_270_0.jpg)

Figure 1. In our framework, the robot joining an ongoing social group interaction involves four steps. First, robot perceives the scene using on-board sensors and extracts hand-engineered features. Second, the features are used to detect groups in the scene. Furthermore, the robot recognizes the patterns of groups by estimating the F-formations, and, finally, the robot finds the optimal spot and joins the ongoing social group interactions. The steps in the red rectangle-detecting groups and estimating F-formations-are addressed in this paper.

図1.私たちのフレームワークでは、ロボットが進行中の社会的グループインタラクションに参加する過程は4つのステップからなります。まず、ロボットは搭載センサーを用いてシーンを認識し、手作業で設計された特徴を抽出します。次に、その特徴を用いてシーン内のグループを検出します。さらに、ロボットはFフォーメーションを推定してグループのパターンを認識し、最後に最適な位置を見つけて進行中の社会的グループインタラクションに参加します。図の赤枠内のステップ(グループ検出とFフォーメーションの推定)は本論文で扱います。

In this paper, we propose approaches to estimate the orientational information of people, detect groups, and estimate F-formations from an egocentric view in regard to mobile robots. The spatial and orientational information of people are estimated by processing the egocentric data, which are used to detect the groups in the scene and estimate the F-formations. Usually, robots use sensors such as lasers, depth cameras, sonar, and more to extract the spatial information of people in a scene. However, the orientational information is difficult to process as people are far away from the robot, in different poses, and at times not facing the camera. An approach which deals with these from an egocentric view is proposed. These features are used to develop an approach to detect groups and the responses are used to develop approaches to estimate the F-formations in the scene. These said approaches are integrated in the AGIR framework for the robot to join the ongoing social group interactions in the scene.

本論文では、モバイルロボットに関して、自己中心的な視点から人々の方位情報を推定し、グループを検出し、Fフォーメーションを推定する手法を提案します。人々の空間的および方位的情報は、自己中心データを処理することで推定され、これによりシーン内のグループ検出とFフォーメーションの推定に利用されます。通常、ロボットはレーザー、深度カメラ、ソナーなどのセンサーを用いて人々の空間情報を抽出しますが、方位情報の処理は難しく、遠くにいる人々や異なる姿勢、カメラを向いていない場合もあります。これらの課題に対処する自己中心的なアプローチを提案します。これらの特徴を用いてグループ検出の手法を開発し、その応答をもとにシーン内のFフォーメーションを推定する手法を構築します。これらの手法は、シーン内の進行中の社会的グループインタラクションにロボットが参加するためのAGIRフレームワークに統合されています。

The major contributions of our work in this paper are: (a) a novel approach for human orientation estimation based on the visibility of facial keypoints; (b) a new approach to detect and identify interaction groups using the concept of O-spaces from F-formation and transactional segments; (c) a new approach for estimating F-formations using a polynomial support vector machine (SVM) classifier; (d) a novel algorithm for estimating F-formations by analysing the patterns of group interactions; (e) an AGIR framework to allow the theoretical approach to be incorporated into mobile robots with egocentric camera placement; (f) evaluation of the approaches from an egocentric view, using two simulation scenes, one based on the real-world dataset and second based on our previous work which consists of multiple groups (13) positioned in different (6) formations.

本論文における我々の研究の主な貢献は次の通りである:(a) 顔のキーポイントの可視性に基づく新しい人間の方位推定手法；(b) F-formationのO-spaceの概念と取引セグメントを用いたインタラクショングループの検出と識別の新しいアプローチ；(c) 多項式サポートベクターマシン(SVM)分類器を用いたF-formation推定の新しい方法；(d) グループの相互作用パターンを分析してF-formationを推定する新しいアルゴリズム；(e) 自己中心カメラ配置を持つ移動ロボットに理論的アプローチを組み込むためのAGIRフレームワーク；(f) 実世界のデータセットに基づくシミュレーションシーンと、異なる(6)配置に配置された複数のグループ(13)を含む我々の以前の研究に基づく2つのシミュレーションシーンを用いたアプローチの評価。

The paper is organized as follows: Section 2 presents information on F-formations theory and an overview of previous works. Section 3 presents our approaches in detail, with individual components involved in every approach. Section 4 presents details of the coffee dataset, and the simulation scenes built to evaluate our approaches. Section 5 describes about the evaluation process, ground truth annotation process, and the metrics used to evaluate our approaches. The evaluation of our approaches and the concerned results are presented in Section 6. Section 7 presents the limitations of our framework and future research directions while addressing them. Finally, we conclude the paper in Section 8.

本論文は以下の構成である:第2節ではF-formation理論と先行研究の概要を示す。第3節では各アプローチの詳細と、それに関わる個々のコンポーネントを説明する。第4節ではコーヒーデータセットの詳細と、我々のアプローチを評価するために構築したシミュレーションシーンを紹介する。第5節では評価プロセス、グラウンドトゥルースのアノテーション方法、および評価に用いた指標について述べる。第6節では我々のアプローチの評価とその結果を示す。第7節ではフレームワークの制限と今後の研究方向について議論し、それに対処する。最後に、第8節で論文を締めくくる。

## 2. Background and Related Works

## 2. 背景と関連研究

In this section, proxemics and F-formations theories are detailed, along with related works in the context of our work.

本節では、プロクセミクスとF-formation理論について詳述し、我々の研究に関連する先行研究も紹介する。

### 2.1. Background

### 2.1. 背景

In interactions, people tend to position themselves based on different factors, such as culture, gender, status, age, familiarity, relationship, pose, etc., see [30]. Proxemics addresses the interpersonal distances between people as shown in Table 1. Many works [31-33] have used proxemics and performed experiments. Their investigations suggest that human and robot interaction occurs in personal and social spaces. Particularly, social spaces are used for social interactions, and also substantially reflect and influence the social relationships of people to each other \( \left\lbrack  {{34},{35}}\right\rbrack \) .

インタラクションにおいて、人々は文化、性別、地位、年齢、親しみ、関係性、ポーズなどさまざまな要因に基づいて位置を決定する傾向がある。詳細は[30]を参照。プロクセミクスは、表1に示すように、人と人との間の対人距離を扱うものである。多くの研究[31-33]がプロクセミクスを用いて実験を行っており、その調査結果は、人とロボットの相互作用が個人的空間や社会的空間で行われることを示している。特に、社会的空間は社会的交流に用いられ、また人々の社会的関係性を反映し、影響を与える重要な役割を果たしている\( \left\lbrack  {{34},{35}}\right\rbrack \)。

Table 1. Interpersonal distances of people.

表1. 人々の対人距離。

<table><tr><td>Spaces</td><td>Distances between People</td><td>Interactions between</td></tr><tr><td>Intimate</td><td>0-0.5 m</td><td>Couples or partners</td></tr><tr><td>Personal</td><td>0.5-1.2 m</td><td>Friends or family</td></tr><tr><td>Social</td><td>1.2-3.7 m</td><td>Colleagues or unknown</td></tr><tr><td>Public</td><td>above 3.7 m</td><td>Speaker and people (public speeches)</td></tr></table>

<table><tbody><tr><td>空間</td><td>人間の間の距離</td><td>交流</td></tr><tr><td>親密</td><td>0-0.5 m</td><td>カップルやパートナー</td></tr><tr><td>個人的</td><td>0.5-1.2 m</td><td>友人や家族</td></tr><tr><td>社会的</td><td>1.2-3.7 m</td><td>同僚や未知の人</td></tr><tr><td>公共</td><td>3.7メートル以上</td><td>話し手と聴衆(公開スピーチ)</td></tr></tbody></table>

These works discuss the spaces between people mostly in dyadic interactions, where people in group interactions tend to possess spatial and orientational relationship with each other. The group members configure themselves into different patterns, regarding which, four standard F-formations, independent of the physical constraints \( \left\lbrack  {{17},{18}}\right\rbrack \) , were proposed. They are: vis-a-vis, side-by-side, L-shape, and circular formations. The vis-a-vis formation is when two people are facing each other while interacting. The side-by-side formation is when two people stand close to each other and face in the same direction while conversing. The L-shape formation is when two people face each other perpendicularly and where it appears as if they are standing on the two edges of the letter "L". The circular formation is when three or more people are conversing in a circle. F-formations define three spaces. O-space is the empty space between people involved in the interaction. P-space is the narrow strip on which people stand while conversing. R-space is the space beyond the P-space, as seen in Figure 2e. The standard F-formations are shown in Figure 2.

これらの研究は、主に二者間の相互作用における人々の間の空間について論じており、グループ間の相互作用においては、参加者がお互いに空間的および方位的な関係を持つ傾向がある。グループのメンバーはさまざまなパターンに配置され、物理的制約に依存しない四つの標準的なFフォーメーションが提案された。これらは:対面、並列、L字型、円形の配置である。対面配置は、二人が互いに向き合っている状態を指す。並列配置は、二人が近くに立ち、同じ方向を向いて会話している状態を指す。L字型配置は、二人が直角に向き合い、「L」の文字の二辺に立っているように見える配置である。円形配置は、三人以上が円になって会話している状態を指す。Fフォーメーションは三つの空間を定義する。Oスペースは、相互作用に関与する人々の間の空きスペース。Pスペースは、会話中に人々が立つ狭い帯状の空間。Rスペースは、Pスペースの先にある空間であり、図2eに示されている。標準的なFフォーメーションは図2に示されている。

![bo_d3ecpr4601uc738ioje0_3_448_744_1109_620_0.jpg](images/bo_d3ecpr4601uc738ioje0_3_448_744_1109_620_0.jpg)

Figure 2. (a-d) present the four F-formations. (d, e) represent the same circular formation, (d) presents the ego-centric view, and (e) presents the top view. F-formations define three spaces. O-space is the empty space between people involved in the interaction. P-space is the narrow strip on which people stand while conversing. R-space is the space beyond the P-space, as seen in (e).

図2。(a-d)は四つのFフォーメーションを示す。(d, e)は同じ円形配置を表し、(d)は自己中心視点、(e)は俯瞰視点を示す。Fフォーメーションは三つの空間を定義する。Oスペースは、相互作用に関与する人々の間の空きスペース。Pスペースは、会話中に人々が立つ狭い帯状の空間。Rスペースは、Pスペースの先にある空間であり、(e)に示されている。

In addition, the authors from \( \left\lbrack  {{36},{37}}\right\rbrack \) proposed three formations that are formed in a spatially constrained environment. The triangular formation occurs when two people standing close to each other are facing one person standing at a farther distance from them. The rectangular formation is formed in board meeting rooms or at dinner tables. The semi-circular formation occurs when three or more people are focusing on the same task while interacting, such as in an art gallery in front of an art piece, shown in Figure 3.

さらに、\( \left\lbrack  {{36},{37}}\right\rbrack \)の著者らは、空間的に制約された環境で形成される三つの配置を提案している。三角形配置は、近くに立つ二人が、遠くに立つ一人と向き合う場合に発生する。長方形配置は、会議室やダイニングテーブルの周りで形成される。半円形配置は、三人以上が同じ課題に集中しながら交流している場合に見られ、例えば美術館の前のアート作品の前での例が図3に示されている。

Most of the works consider only the four standard F-formations, whereas in our case we consider six formations, which are: vis-a-vis, L-shape, side-by-side, circular, triangular, and semi-circular formations. The rectangular formation is a peculiar design and mostly found in a meeting room or around the dinner table, and we could not come up with an approach for this formation because of its peculiar design.

ほとんどの研究は四つの標準的なFフォーメーションのみを考慮しているが、私たちの研究では六つの配置を考慮している。これらは:対面、L字型、並列、円形、三角形、半円形である。長方形配置は特殊なデザインであり、主に会議室やダイニングテーブルの周りで見られるが、その特殊なデザインのためにこの配置に対するアプローチは考案できなかった。

![bo_d3ecpr4601uc738ioje0_4_448_250_1110_627_0.jpg](images/bo_d3ecpr4601uc738ioje0_4_448_250_1110_627_0.jpg)

Figure 3. (a, c, e) present the constraint-based formations. (a, b) represent the triangular formation. (a) presents the top view whereas(b)presents the ego-centric view.(c, d)present the semi-circular formation, (c) the ego-centric view, and (d) the top view.

図3。(a, c, e)は制約に基づく配置を示す。(a, b)は三角形配置を表し、(a)は俯瞰視点、(b)は自己中心視点を示す。(c, d)は半円形配置を示し、(c)は自己中心視点、(d)は俯瞰視点を示す。

### 2.2. Related Works

### 2.2. 関連研究

Related works associated with the main contributions of this paper are presented sequentially in the order of the stages in the framework, i.e., head orientation, group detection, and estimating F-formations, as presented in Figure 1.

本論文の主要な貢献に関連する研究は、フレームワークの各段階(頭の向き、グループ検出、Fフォーメーションの推定)に沿って順次示されている。図1に示す通りである。

#### 2.2.1. Head Orientation

#### 2.2.1. 頭の向き

Developing methods to automatically detect groups from an egocentric view requires addressing sub-challenge-head pose detection, face orientation, or body orientation detection. There are many approaches for estimating head pose [38]. These approaches are used in different applications or scenarios, based on whether the approaches can be roughly categorized into two classes: interaction-based methods [39-42] and non-interaction-based methods [43-45]. In interaction-based methods, head orientation is primarily used to determine head pose, in particular, yaw with intervals. For example, the head orientation of a person from left to right is divided into \( - {90}^{ \circ  }, - {45}^{ \circ  },{0}^{ \circ  },{45}^{ \circ  },{90}^{ \circ  } \) . In non-interaction-based methods, the approaches deal with head pose (yaw, roll, and pitch) of people from close range, i.e., the exact degrees of orientation. For example, \( {35}^{ \circ  } \) yaw, \( {45}^{ \circ  } \) roll, \( {20}^{ \circ  } \) pitch. When it comes to the detection of head pose in group interactions, in [39], it is argued that many social interactions do not necessarily require a finer subdivision of the orientations. Instead, few yaw angles or facing directions would suffice in the context of detecting social interactions in groups. In this regard, in [40], orientation of head was estimated based on the skin detection and discretized into eight different orientations. A weight image is computed for five consecutive frames, but this work is in videos. A novel descriptor was presented and named as a weighted array of covariances considering a multiclass classification scenario using the head and body orientation [41]. Another method [39] estimates head pose from an egocentric view in social interactions. The method uses a Hough-based tracker [46] to track the non-rigid target and, finally, the target is segmented using the GrabCut algorithm [47]. The work is in egocentric videos and the target image is initialized when its frontal face is observed, which indicates the method would have trouble when the person is not facing the camera. Head poses were used to detect groups through a supervised clustering approach [48].

自己中心視点からグループを自動的に検出する方法を開発するには、頭部姿勢検出、顔の向き、または身体の向きの検出といったサブチャレンジに対処する必要がある。頭部姿勢推定には多くのアプローチが存在する[38]。これらのアプローチは、相互作用に基づく方法[39-42]と非相互作用に基づく方法[43-45]の二つのクラスに大まかに分類できるかどうかに基づいて、さまざまな応用やシナリオで使用されている。相互作用に基づく方法では、頭の向きは主に頭の姿勢を決定するために用いられ、特にヨー角の範囲を示す。例えば、左から右への頭の向きは\( - {90}^{ \circ  }, - {45}^{ \circ  },{0}^{ \circ  },{45}^{ \circ  },{90}^{ \circ  } \)に分割される。非相互作用に基づく方法では、近距離からの人々の頭の姿勢(ヨー、ロール、ピッチ)を扱い、正確な角度を測定する。例えば、\( {35}^{ \circ  } \)ヨー角、\( {45}^{ \circ  } \)ロール角、\( {20}^{ \circ  } \)ピッチ角である。グループ内の頭部姿勢の検出に関しては、[39]では、多くの社会的相互作用はより細かい姿勢の細分化を必ずしも必要としないと主張している。むしろ、少数のヨー角や向きだけで、グループ内の社会的相互作用の検出に十分であると述べている。この点に関して、[40]では、頭の向きは肌の検出に基づいて推定され、8つの異なる向きに離散化された。重み付け画像は5連続フレームに対して計算されるが、この研究は動画を対象としている。新しい記述子が提案され、頭と身体の向きを用いた多クラス分類シナリオを考慮した重み付け共分散配列と命名された[41]。もう一つの方法[39]では、社会的相互作用において自己中心視点から頭部姿勢を推定する。Houghベースのトラッカー[46]を用いて非剛体ターゲットを追跡し、最終的にGrabCutアルゴリズム[47]を用いてターゲットをセグメント化する。この研究は自己中心動画を対象としており、正面顔が観察されたときにターゲット画像が初期化されるため、人物がカメラに向いていない場合には困難が生じる可能性がある。頭部の姿勢は、教師ありクラスタリングアプローチ[48]を用いてグループを検出するために利用された。

In sum, detecting groups from an egocentric view in regard to a mobile robot also requires estimating the head/face pose and/or body orientation with little computation cost, in real time, at times from farther distances(4 - 5m). In addition, it is necessary to simultaneously detect poses for multiple people and-most importantly-estimate the \( {360}^{ \circ  } \) orientation, i.e., in all the directions, even when the person is not facing the camera.

要するに、移動ロボットに関して自己中心視点からグループを検出するには、頭部や顔の姿勢や身体の向きをほとんど計算コストをかけずに推定し、リアルタイムで、場合によっては遠距離(4〜5m)からも行う必要がある。さらに、複数の人の姿勢を同時に検出し、最も重要なことに、\( {360}^{ \circ  } \)の向き、すなわち全方向の向きを推定する必要がある。たとえ人物がカメラに向いていなくても、これを行うことが求められる。

#### 2.2.2. Detecting Groups

#### 2.2.2. グループの検出

In the literature, group detection was accomplished through different processes, such as body-worn sensors [49,50], audio-based frameworks [51], clustering approaches [48,52], deep learning [53], and more.

文献では、グループ検出は、身体に装着したセンサー[49,50]、音声を用いたフレームワーク[51]、クラスタリングアプローチ[48,52]、深層学習[53]など、さまざまな方法によって実現されてきた。

Our focus in regards to group detection is on robots joining a group interaction. Regarding this, much of the previous works related to social positioning of robots in groups use the sociology theory of F-formation, which discusses the social positioning of people in groups. This theory models groups in the scene, based on sustained spatial and orientational relationship among group members, which resulted in a good amount of studies. Cristani et al. [6] proposed a Hough voting strategy, used to locate the O-space, which in return provides the groups of conversing people. The O-space is an empty space between a group of people involved in an interaction. Hung et al. [54] built a graph model in which nodes represent the people and edges the pair-wise relation between people, using which, an affinity is built to find the dominant set. Setti, in their work surrounding group detection, proposed two different approaches. Another Hough voting strategy approach was developed for detecting groups, which employs the weighted Boltzmann entropy for scoring group hypothesis [55]. A new approach was developed to detect groups in still images, presented based on a graph-cuts framework for clustering individuals. They are able to systemise the F-formation theory through only the position and orientation of people, and named the approach graph-cuts for F-formation (GCFF) [7]. Vascon et al. [8] developed a game theoretic framework, embedding the socio-psychological concept of F-formations and the biological constraints of social attention to detect groups by generating a frustum of people to compute their affinity. Ricci et al. [56] proposes a joint learning framework for the individuals' heads, body orientations, and F-formations in videos. Zhang et al. [57] proposed extracting features from individuals and classifying them as associates, singletons, and members of F-formations using the frustum of attention of individuals in the scene. A given person's lower body is used for detecting the F-formations, which are obtained by tracking the position and orientation of people in a scene [58]. Recently, deep learning algorithms have also been proposed to detect groups. Long short-term memory, an artificial recurrent neural network (RNN), is proposed and trained with the distance between the camera and the person [59]. The person's head orientation is used as an input feature to detect the social interactions. Vazquez et al. [60] proposed deep affinity network for clustering conversational interactants (DANTE), a novel deep affinity network to predict the likelihood that two individuals in a scene belong to the same group, considering their social context. A graph clustering framework is used with the predicted pair-wise affinities to identify groups.

グループ検出に関する私たちの焦点は、ロボットがグループの交流に参加することにあります。これに関して、ロボットの社会的配置に関する以前の研究の多くは、F-formationの社会学理論を用いています。この理論は、グループ内の人々の社会的配置について論じており、シーン内のグループを、グループメンバー間の持続的な空間的および方位的関係に基づいてモデル化しています。これにより、多くの研究が行われました。Cristaniら[6]は、Oスペースを特定するために使用されるハフ投票戦略を提案し、会話中の人々のグループを特定しました。Oスペースは、交流に関与している人々の間の空間です。Hungら[54]は、ノードが人々を表し、エッジが人々間のペア関係を示すグラフモデルを構築し、それを用いて親和性を構築し、支配的な集合を見つけました。Settiは、グループ検出に関する研究で、2つの異なるアプローチを提案しました。もう一つのハフ投票戦略を用いたグループ検出手法は、グループ仮説のスコアリングに重み付きボルツマンエントロピーを採用しています[55]。静止画像内のグループを検出する新しいアプローチも開発され、個人のクラスタリングのためのグラフカットフレームワークに基づいています。これらは、人物の位置と方位のみを用いてF-formation理論を体系化でき、"graph-cuts for F-formation"(GCFF)と名付けられました[7]。Vasconら[8]は、社会心理学的概念のF-formationと社会的注意の生物学的制約を組み込んだゲーム理論的フレームワークを開発し、人々のフラスタムを生成して親和性を計算します。Ricciら[56]は、動画内の個人の頭部、身体の向き、F-formationを共同学習するフレームワークを提案しました。Zhangら[57]は、個人から特徴を抽出し、シーン内の個人の注視フラスタムを用いて、これらを仲間、シングルトン、F-formationのメンバーとして分類する方法を提案しました。特定の人物の下半身を用いてF-formationを検出し、シーン内の人々の位置と方位を追跡することで得られます[58]。最近では、深層学習アルゴリズムもグループ検出に用いられています。長短期記憶(LSTM)という人工リカレントニューラルネットワーク(RNN)が提案され、カメラと人物との距離を用いて訓練されています[59]。人物の頭の向きは、社会的交流を検出するための入力特徴として使用されます。Vazquezら[60]は、会話参加者のクラスタリングのための深い親和性ネットワーク(DANTE)を提案し、シーン内の2人の個人が同じグループに属する可能性を予測する新しい深層親和性ネットワークです。予測されたペア間の親和性を用いたグラフクラスタリングフレームワークにより、グループを識別します。

The presented works using the F-formation theory are designed for surveillance applications and work with exocentric vision [6-8,54,55]. Most of these approaches assume prior data, such as the spatial and orientational information of people in the scene. These methods are unfeasible and could not be easily deployed on a physical mobile robot because robots use on-board sensors and an egocentric camera view to perceive the scene [20].

F-formation理論を用いたこれらの研究は、監視用途向けに設計されており、外中心視野(エクソセントリックビジョン)で動作します[6-8,54,55]。これらのアプローチのほとんどは、シーン内の人々の空間的および方位的情報などの事前データを前提としています。これらの方法は、ロボットの搭載センサーと自己中心的カメラビューを用いてシーンを認識するロボットには適しておらず、容易に展開できません[20]。

#### 2.2.3. Estimating F-Formations

#### 2.2.3. F-formationの推定

In the literature, many works have studied F-formation patterns either to investigate the different F-formation arrangements that emerged during an interaction between a robot and human [61-63] or to investigate the quality of interaction between the robot and humans [64-66]. However, only a handful of works have proposed approaches to recognise the spatial patterns \( \left\lbrack  {{28},{29}}\right\rbrack \) , which are further used to interact with groups of people.

文献では、多くの研究がF-formationパターンを調査しており、ロボットと人間の交流中に出現するさまざまなF-formationの配置を調査したり[61-63]、ロボットと人間の交流の質を調査したりしています[64-66]。しかし、空間パターンを認識し、それを用いて人々のグループと交流するアプローチを提案した研究はごくわずかです\( \left\lbrack  {{28},{29}}\right\rbrack \)。

Tseng et al. [29] proposed a complete system to interact with groups of people. This system estimates F-formation patterns using the relative angle of group members for groups of two and three people. The presented work performs better under two groups in the scene and only four patterns are studied. Recently, one more work has emerged, [28], there a machine-learning-based method is proposed to interact with the group of people. The approach considers poses of people in the group and uses the SVM classifier for predicting the F-formation. The presented work performs only for a single group in the scene and only four patterns are studied.

Tsengら[29]は、人々のグループと交流するための完全なシステムを提案しました。このシステムは、2人または3人のグループに対して、グループメンバーの相対角度を用いてF-formationパターンを推定します。提示された研究は、シーン内の2つのグループでより良い性能を示し、4つのパターンのみを対象としています。最近、もう一つの研究[28]が登場し、機械学習を用いた方法でグループと交流します。このアプローチは、グループ内の人々のポーズを考慮し、SVM分類器を用いてF-formationを予測します。提示された研究は、シーン内の単一のグループのみを対象とし、4つのパターンのみを調査しています。

While these works have proposed approaches to estimate F-formations, they have two limitations. The approaches study limited patterns and limited groups, i.e., four patterns \( \left\lbrack  {{28},{29}}\right\rbrack \) and one group \( \left\lbrack  {28}\right\rbrack \) or two groups \( \left\lbrack  {29}\right\rbrack \) in the scene.

これらの研究はF-formationを推定するアプローチを提案していますが、2つの制限があります。これらのアプローチは、限られたパターンと限られたグループのみを対象としており、つまりシーン内の4つのパターン\( \left\lbrack  {{28},{29}}\right\rbrack \)と1つのグループ\( \left\lbrack  {28}\right\rbrack \)または2つのグループ\( \left\lbrack  {29}\right\rbrack \)に限定されています。

Recently, there are some deep learning based methods to join the ongoing social group interactions \( \left\lbrack  {{67},{68}}\right\rbrack \) . These studies investigate how robots can learn to join the groups in simulation and mainly deal with only one group in the scene. A wide variety of social interaction datasets are required for deep learning approaches to be proposed.

最近、深層学習に基づく方法がいくつか登場し、進行中の社会的グループの交流に参加しています\( \left\lbrack  {{67},{68}}\right\rbrack \)。これらの研究は、ロボットがシミュレーション内でグループに参加する方法を調査しており、主にシーン内の1つのグループのみを扱っています。深層学習アプローチを提案するには、多様な社会的交流データセットが必要です。

## 3. Methodology

## 3. 方法論

The proposed framework, AGIR, employs a human detection approach to process egocentric RGB data captured by an on-board camera of the robot. The response from the detection algorithm are the \( 2\mathrm{D} \) poses of people in the scene, which imply the number of people in the scene. These 2D poses encode the anatomical keypoints of humans. Using these 2D poses, the orientation of people is calculated based on the visibility of 6 facial keypoints. The spatial information of people is calculated using the on-board laser sensor. The spatial and orientational information of people is used to localize people in the scene. For this, dimensions of the scene are used, where image width represents the width of the scene and laser is used for the depth of the scene.

提案されたフレームワークであるAGIRは、人間検出アプローチを採用し、ロボットの搭載カメラによってキャプチャされたエゴセントリックRGBデータを処理します。検出アルゴリズムから得られる応答は、シーン内の人々の\( 2\mathrm{D} \)姿勢であり、これがシーン内の人数を示します。これらの2D姿勢は、人間の解剖学的なキーポイントをエンコードしています。これらの2D姿勢を用いて、6つの顔のキーポイントの可視性に基づいて人々の向きを計算します。人々の空間情報は、搭載されたレーザーセンサーを使用して計算されます。人々の空間情報と向きの情報は、シーン内の位置を特定するために使用されます。これには、シーンの寸法が利用され、画像の幅はシーンの幅を表し、レーザーはシーンの奥行きを測定します。

After localizing people in the scene, the O-spaces are distributed equally in the scene. With an assumption that each group has at least two members, the number of people in the scene enumerates the maximum number of groups possible in the scene. This also defines the number of O-spaces possible, which are then initialized (distributed) equally in the scene. People are assigned to their nearest O-space based on the distance factor. Then transactional segments are modelled for every individual in the scene and mapped onto the concerned O-spaces within the groups. If the overlap region is above the threshold, members are considered to belong to the same group. Otherwise, they are considered as singletons and a new O-space is created for each of them. The O-spaces are updated with new group members and mapped with the segments until unaltered groups are obtained. This iterative process results in the number of O-spaces and the people assigned to them, i.e., the number of groups and their members. Further proceeded with estimating F-formations, a classification approach-a polynomial SVM classifier is trained for smaller groups. For larger groups, the variance of the group, i.e., the variance of spatial and orientational information of group members are used to estimate the F-formations. The presented overview of our approach is shown in Figure 4.

シーン内の人々をローカライズした後、Oスペースはシーン内に均等に分配される。各グループに少なくとも二人のメンバーがいると仮定すると、シーン内の人数は可能な最大のグループ数を表す。これにより、可能なOスペースの数も定義され、それらはシーン内で均等に初期化(分配)される。人々は距離の要素に基づいて最も近いOスペースに割り当てられる。その後、シーン内の各個人に対してトランザクションセグメントがモデル化され、グループ内の該当するOスペースにマッピングされる。重複領域が閾値を超える場合、メンバーは同じグループに属するとみなされる。そうでなければ、個別の単体として扱われ、それぞれに新しいOスペースが作成される。Oスペースは新しいグループメンバーで更新され、セグメントとマッピングされ続け、変更されないグループが得られるまで繰り返される。この反復プロセスにより、Oスペースの数とそれに割り当てられた人々、すなわちグループの数とそのメンバーが決定される。さらに、Fフォーメーションの推定に進み、小規模なグループには多項式SVM分類器を訓練し、大規模なグループには、グループの分散、すなわち空間的および方位情報の分散を用いてFフォーメーションを推定する。本アプローチの概要は図4に示されている。

![bo_d3ecpr4601uc738ioje0_6_455_1664_1046_292_0.jpg](images/bo_d3ecpr4601uc738ioje0_6_455_1664_1046_292_0.jpg)

Figure 4. Overview of our framework. The robot uses on-board sensors to process the scene and extract the number of people, and the spatial and orientational information of people. These hand-engineered features are used to detect the groups-using the O-spaces and the transactional segments of people. Then, the patterns of the groups are recognized by estimating the F-formations using a classifier and the variance of group members.

図4. 私たちのフレームワークの概要。ロボットは搭載センサーを使用してシーンを処理し、人数や人々の空間的・方向的情報を抽出します。これらの手作業で設計された特徴は、Oスペースと人々の取引セグメントを利用してグループを検出するために使用されます。その後、分類器を用いてFフォーメーションを推定し、グループメンバーの分散を計算することで、グループのパターンを認識します。

### 3.1. Processing the Scene

### 3.1. シーンの処理

The robot captures the scene from a built-in RGB camera and the image is processed through a human detection algorithm [69]. The algorithm extracts the 2D poses of people in the image and the poses encode the 18 anatomical keypoints of the humans, which represent the skeleton structure of the humans. The number of poses imply the number of people in the scene; furthermore, these poses are used to estimate the orientation of the people in the scene. The spatial information of people is acquired through an on-board laser sensor of the robot.

ロボットは内蔵されたRGBカメラからシーンをキャプチャし、その画像は人検出アルゴリズム[69]を通じて処理される。このアルゴリズムは画像内の人の2Dポーズを抽出し、これらのポーズは人間の18の解剖学的キーポイントをエンコードしており、これは人間の骨格構造を表している。ポーズの数はシーン内の人数を示し、さらにこれらのポーズは人の向きを推定するために使用される。人の空間情報は、ロボットに搭載されたレーザーセンサーを通じて取得される。

### 3.2. Estimating Orientation of the Individuals

### 3.2. 個人の向きの推定

Head pose is an important cue in understanding social interactions. At the same time, estimating head pose is a complex task with multiple people in the scene, with few people standing far away from the robot and not everyone is facing the robot. For these reasons, social interaction analysis does not require a high accuracy of the orientations [48], but rather uses facing directions, which is sufficient in the context of detecting social group interactions.

頭の向きは社会的相互作用を理解する上で重要な手がかりです。同時に、複数の人がいる場面での頭の向きの推定は複雑な作業であり、遠くに立つ人や全員がロボットに向いているわけではないため、正確な向きの推定は必ずしも必要ありません。これらの理由から、社会的相互作用の分析には高精度の向きの推定は求められず、向きの方向を用いるだけで十分であり、社会的グループの相互作用を検出する文脈ではこれで十分です。

In our framework, head orientation is modelled into four distinct classes, representing the four facing directions, which are left, right, straight, and backward.

私たちのフレームワークでは、頭の向きは左、右、正面、後方の4つの向きに分類される4つのクラスにモデル化されています。

To estimate head pose, our approach considers visibility of six facial keypoints: torso, nose, two ears, and two eyes. Our approach is named visibility of 6 facial keypoints (V6KP). Based on the keypoint visibility in the source image, the head pose is classified into four classes-i.e., facing centre, facing right, facing left, and facing about-as shown in Figure 5. When a person is facing away from the camera, only the torso and ears keypoints are visible in the image. That means the person is facing about, which is considered as \( {0}^{ \circ  } \) . Then, proceeding in a clockwise direction, when the person is facing right, the person's right ear and eye, nose, and torso points are visible in the image, and the orientation is \( \pi /2 \) . Approximately all six facial keypoints are visible in the image when the person is facing centre, which is considered as \( \pi \) . Finally, when the person is facing left, the person’s left ear and eye, nose, and torso points are visible in the image, and the orientation is \( {3\pi }/2 \) , as shown in Figure 5.

頭の向きを推定するために、私たちのアプローチは6つの顔のキーポイント:胴体、鼻、左右の耳、左右の目の可視性を考慮します。私たちのアプローチは「6顔のキーポイントの可視性(V6KP)」と名付けられています。ソース画像におけるキーポイントの可視性に基づき、頭の向きは4つのクラスに分類されます。すなわち、中央を向いている、右を向いている、左を向いている、ほぼ正面を向いているです(図5参照)。人物がカメラから背を向けている場合、画像には胴体と耳のキーポイントのみが見えます。これは、その人物がほぼ正面を向いていることを意味し、\( {0}^{ \circ  } \)と見なされます。次に、時計回りに進めると、人物が右を向いている場合、右耳、右目、鼻、胴体のポイントが画像に見え、向きは\( \pi /2 \)となります。ほぼ中央を向いている場合、画像には6つの顔のキーポイントのほぼすべてが見え、これは\( \pi \)と見なされます。最後に、左を向いている場合、左耳、左目、鼻、胴体のポイントが画像に見え、向きは\( {3\pi }/2 \)となり、図5に示されています。

![bo_d3ecpr4601uc738ioje0_7_461_1349_1099_554_0.jpg](images/bo_d3ecpr4601uc738ioje0_7_461_1349_1099_554_0.jpg)

Figure 5. V6KP estimates the head orientation of people in the scene. The left part presents one image of two groups interacting in the scene. One group comprises four members and the second group comprises two members. The right part presents four images of the individual people being detected and their head orientation is calculated for the first group. The cropped images of their head and their facing direction along with orientation are presented in the right part.

図5. V6KPはシーン内の人々の頭の向きを推定します。左側はシーン内で交流している2つのグループの1つの画像を示しています。1つのグループは4人、もう1つのグループは2人で構成されています。右側は、検出された個々の人物の4つの画像と、それらの頭の向きが最初のグループのために計算されたものを示しています。頭部のクロップ画像と向き、向きの方向も右側に示されています。

This form of estimation is very useful when the facial keypoints are translucent, lacking clear visibility due to body occlusions, and the distance between people and camera is larger. In practice, we found that this approximation is simpler and also produces good results, which can be seen in Figure 5.

この推定方法は、顔のキーポイントが半透明であったり、身体の遮蔽により明確な可視性が欠如している場合や、人物とカメラの距離が大きい場合に非常に有用です。実際に、この近似はより簡単でありながら良好な結果をもたらすことがわかっており、図5にその例が示されています。

The dimensions of the scene-the width and depth of the scene-are acquired through image and laser. The number of people in the scene, and the spatial and orientational information of people are used to localize people in the scene. The next task for the robot would be to detect groups in the scene.

シーンの寸法—幅と奥行き—は、画像とレーザーを用いて取得されます。シーン内の人数や、人物の空間的および向きの情報を用いて、人物の位置を特定します。次の課題は、ロボットがシーン内のグループを検出することです。

### 3.3. Detecting Groups

### 3.3. グループの検出

#### 3.3.1. Initializing O-Spaces

#### 3.3.1. Oスペースの初期化

Social interaction occurs when two or more people form a group. The number of people, \( n \) , in the scene is acquired through the human detection algorithm [69], and the maximum number of groups, \( {M}_{g} \) , possible in the scene are equal to the number of people by 2 (i.e., \( {M}_{g} = n/2 \) ). Each group has an O-space which indicates the number of groups is equal to the number of O-spaces \( \left( {O}_{n}\right) \) in the scene. Then \( {O}_{n} = {M}_{g} \) , which are then equally positioned (initialized) \( \left( {O}_{p}\right) \) in the scene, as given in Equation (1).

社会的交流は、2人以上の人々がグループを形成するときに発生します。シーン内の人数、\( n \)は人間検出アルゴリズム[69]を用いて取得され、シーン内で可能な最大のグループ数、\( {M}_{g} \)は人数を2で割った値(すなわち\( {M}_{g} = n/2 \))に等しいです。各グループにはOスペースがあり、これはシーン内のグループ数とOスペースの数が等しいことを示します。次に、\( {O}_{n} = {M}_{g} \)、これらは等間隔に配置(初期化)され、\( \left( {O}_{p}\right) \)、式(1)に示すようにシーン内に配置されます。

\[
{O}_{p} = \frac{d}{2}\mathop{\lim }\limits_{{{M}_{g} \rightarrow  m}}\left\lbrack  {\frac{w}{m + 1} * 1,\frac{w}{m + 1} * 2,\ldots \frac{w}{m + 1} * m}\right\rbrack   \tag{1}
\]

where \( d \) and \( w \) are depth and width of the scene, \( {O}_{p} \) is the position of O-spaces, and \( m \) is the number of O-spaces in the scene.

ここで、\( d \)と\( w \)はシーンの奥行きと幅、\( {O}_{p} \)はOスペースの位置、\( m \)はシーン内のOスペースの数です。

The O-space is the empty space surrounded by the people involved in the social group interaction [6]. We refer to an O-space in Kendon's definition, e.g., as the space between a group of people. This space could be represented as a circle [45], which is considered in our case. The idea behind our approach is to assume the O-space as a circle with radius, \( r \) , and initialize these spaces in the scene and optimize (rearrange) them in different steps, while modelling the transactional segments and map them onto the spaces, which would finally result in matching our initialized O-spaces to the original O-spaces of the groups in the scene. This way, we control our initialized O-spaces and know the exact whereabouts of our O-spaces and people assigned to them. Finally, we acquire the groups and their members in the scene.

Oスペースは、社会的グループの交流に関わる人々に囲まれた空間です[6]。ケンドンの定義では、Oスペースは人々のグループ間の空間とされます。この空間は円として表現でき[45]、私たちのケースでもこれを考慮しています。私たちのアプローチの背後にあるアイデアは、Oスペースを半径\( r \)の円と仮定し、これらの空間をシーン内に初期化し、異なるステップで最適化(再配置)しながら、取引セグメントをモデル化し、それらを空間にマッピングすることです。最終的に、これにより初期化したOスペースをシーン内の実際のOスペースに一致させることができます。この方法で、初期化したOスペースを制御し、それらの正確な位置と割り当てられた人々を把握します。最終的に、シーン内のグループとそのメンバーを取得します。

#### 3.3.2. Optimizing O-Spaces

#### 3.3.2. Oスペースの最適化

Once the O-spaces are initialized, we calculate the Euclidean distances between the O-spaces and the people, as follows:

Oスペースの初期化が完了したら、次にOスペースと人々の間のユークリッド距離を計算します。次のように行います:

\[
{d}_{ij} = \sqrt{{\left( {O}_{{C}_{{i}_{x}}} - {H}_{{j}_{x}}\right) }^{2} + {\left( {O}_{{C}_{{i}_{y}}} - {H}_{{j}_{y}}\right) }^{2}} \tag{2}
\]

where \( {d}_{ij} \) is the distance of \( {i}^{\text{th }}\mathrm{O} \) -space to the \( {j}^{\text{th }} \) person, \( \left( {{O}_{{C}_{{i}_{x}}},{O}_{{C}_{{i}_{y}}}}\right) \) is centre of the \( {i}^{\text{th }} \) O-space, and \( \left( {{H}_{{j}_{x}},{H}_{{j}_{y}}}\right) \) is the spatial location of the \( {j}^{\text{th }} \) person.

\( {d}_{ij} \)は\( {i}^{\text{th }}\mathrm{O} \)空間から\( {j}^{\text{th }} \)人への距離であり、\( \left( {{O}_{{C}_{{i}_{x}}},{O}_{{C}_{{i}_{y}}}}\right) \)はO-空間の中心、\( {i}^{\text{th }} \)は\( {j}^{\text{th }} \)人の空間的位置を示す。

Based on the distance \( \left( {d}_{ij}\right) \) , people are assigned to their nearest O-space. People assigned to an O-space are considered as a group. Then, using group member's spatial locations, we calculate the mean of that particular group \( \left( \bar{G}\right) \) , as follows:

距離\( \left( {d}_{ij}\right) \)に基づいて、人々は最も近いO-空間に割り当てられる。O-空間に割り当てられた人々はグループとみなされる。その後、グループのメンバーの空間位置を用いて、その特定のグループ\( \left( \bar{G}\right) \)の平均を計算し、次のように求める:

\[
\bar{G} = \frac{1}{n}\mathop{\sum }\limits_{{i = 1}}^{n}{H}_{{i}_{\left( x, y\right) }} \tag{3}
\]

where \( n \) represents the number of people in the group and \( {H}_{{1}_{\left( x, y\right) }},{H}_{{2}_{\left( x, y\right) }},\ldots ,{H}_{{i}_{\left( x, y\right) }} \) are the spatial locations of group members.

ここで\( n \)はグループ内の人数を表し、\( {H}_{{1}_{\left( x, y\right) }},{H}_{{2}_{\left( x, y\right) }},\ldots ,{H}_{{i}_{\left( x, y\right) }} \)はグループメンバーの空間位置を示す。

The O-spaces are then updated to the centre of the group using Equation (3). That is, the O-spaces are moved in such a way that the centre of the O-space and the mean of the group are equal. This positions the O-space in between the group members.

次に、式(3)を用いてO-空間をグループの中心に更新する。つまり、O-空間の中心とグループの平均が一致するようにO-空間を移動させる。この操作により、O-空間はグループメンバーの間に位置する。

#### 3.3.3. Modelling Transactional Segment

#### 3.3.3. 取引セグメントのモデル化

Kendon [17,18] describes an individual having a space in front of them, which is directly accessible, as a transactional segment. Transactional segments denote the space used to direct attention and carry out activities, such as watching television and manipulating objects \( \left\lbrack  {{18},{36}}\right\rbrack \) . The size of this space varies based on the activity. During face-to-face conversation, this is a hypothetical circular sector (CS), extending outwards from the midriff of a person’s body, covering \( \approx  {30}^{ \circ  } \) to the left and right [17,18,36,70]-mainly in the direction of their head pose, as shown in Figure 6a. The transactional segment of each person is described by a quintuple \( \left( {{x}_{i},{y}_{i},{\theta }_{i},{r}_{i},{\phi }_{i}}\right) \) -the person’s pose \( \left( {{x}_{i},{y}_{i},{\theta }_{i}}\right) \) , the field of view \( \left( {{r}_{i},{\phi }_{i}}\right) \) , with the radius \( \left( {r}_{i}\right) \) , and the opening angle \( \left( {\phi }_{i}\right) \) .

Kendon [17,18]は、前方に空間を持ち、直接アクセス可能な個人の空間を取引セグメントと表現している。取引セグメントは、注意を向けたり、テレビを見たり、物体を操作したりする活動に使用される空間を示す\( \left\lbrack  {{18},{36}}\right\rbrack \)。この空間の大きさは活動によって異なる。対面会話中は、これは仮想的な円形扇形(CS)であり、身体の胴体中央から外側に広がり、\( \approx  {30}^{ \circ  } \)から左と右に広がる[17,18,36,70]。これは主に頭の向きの方向に沿っている。各人の取引セグメントは、五重項\( \left( {{x}_{i},{y}_{i},{\theta }_{i},{r}_{i},{\phi }_{i}}\right) \)(その人の姿勢\( \left( {{x}_{i},{y}_{i},{\theta }_{i}}\right) \)、視野角\( \left( {{r}_{i},{\phi }_{i}}\right) \)、半径\( \left( {r}_{i}\right) \)、開口角\( \left( {\phi }_{i}\right) \))によって記述される。

![bo_d3ecpr4601uc738ioje0_9_455_655_1077_440_0.jpg](images/bo_d3ecpr4601uc738ioje0_9_455_655_1077_440_0.jpg)

Figure 6. (a) The person and their transactional segment. (b) The circle is the O-space and the black shaded region indicates the overlap (mapping) of person's transactional segment with the O-space.

図6. (a) 個人とその取引セグメント。(b) 円はO-空間を示し、黒塗りの領域は個人の取引セグメントとO-空間の重なり(マッピング)を示す。

#### 3.3.4. Modelling Groups

#### 3.3.4. グループのモデル化

Once the O-spaces are updated, the transactional segments of people in the scene are projected onto the O-spaces, (as seen in Figure 6b), which results in an overlapping of transactional segments with the O-spaces. In our scenario, a person belongs to the group if their overlapping area, i.e., their transactional segment overlapping with the concerned O-space, is greater than the given threshold. If the overlapping area of a person is less than the threshold, then that person is treated as a singleton and provided with an individual O-space with a centre, as given in Equation (4).

O-空間が更新されると、シーン内の人々の取引セグメントがO-空間に投影される(図6b参照)、これにより取引セグメントとO-空間の重なりが生じる。私たちのシナリオでは、ある人が属するグループは、その人の取引セグメントと関係するO-空間の重なり面積が閾値を超える場合にグループとみなす。重なり面積が閾値未満の場合、その人は単独者と扱われ、式(4)に示す中心を持つ個別のO-空間が与えられる。

\[
O - {\text{space}}_{\text{center }}\left( {O}_{c}\right)  = {r}_{p} * \left( {\sin \theta  + x,\cos \theta  + y}\right)  \tag{4}
\]

where \( {r}_{p} \) is the radius of a person,(x, y)are co-ordinates of person, and \( \theta \) is the orientation of the person.

ここで\( {r}_{p} \)は人の半径、(x, y)はその人の座標、\( \theta \)はその人の向きを示す。

Once all the persons in the scene belong to at least one O-space. The Euclidean distance between the O-spaces are calculated to merge the intersecting ones, i.e., if two O-spaces intersect, then they are merged into one O-space to form one group. This optimization (iteration) process continues until the groups are stable (unaltered). This process results in the detection of groups (O-spaces) and their members. We name our approach detect groups using O-space (DGO), which is presented in Algorithm 1.

シーン内のすべての人が少なくとも一つのO-空間に属すると、O-空間間のユークリッド距離を計算し、交差するO-空間を統合する。すなわち、二つのO-空間が交差すれば、それらを一つのO-空間に統合し、一つのグループを形成する。この最適化(反復)プロセスは、グループが安定(変化しない)するまで続く。この過程で、グループ(O-空間)とそのメンバーが検出される。我々の手法は、O-空間を用いたグループ検出(DGO)と呼び、アルゴリズム1に示す。

Algorithm 1: Detecting Groups

アルゴリズム1:グループ検出

---

Data: Spatial locations(x, y)and orientations \( \left( \theta \right) \) of people in the scene

データ:シーン内の人々の空間位置(x, y)と向き\( \left( \theta \right) \)

Initialization of O-spaces in the scene

シーン内のOスペースの初期化

Assign people to their nearest O-space

人々を最も近いOスペースに割り当てる

while groups are unaltered do

グループが変更されていない間は

	Compute the mean of the group members;

	グループメンバーの平均を計算する;

	Apply update: O-space \( \leftarrow \) (O-space_centre = mean of group);

	アップデートを適用:O-space \( \leftarrow \)(O-space_centre = グループの平均);

	Modelling the transactional segments of people in the scene;

	シーン内の人々の取引セグメントのモデリング；

	if group members transactional segment overlaps with O-space above threshold then

	グループメンバーの取引セグメントが閾値を超えるOスペースと重なる場合

		Same Group;

		同じグループ；

	else

	その他

		Different group;

		異なるグループ；

		Ignore people (singletons) whose transactional segment does not overlap

		取引セグメントが重複しない単独の人々を無視する

		above threshold with concerned O-space;

		閾値を超えた関心のあるOスペース;

		Create new O-spaces for each of these singletons;

		これらのシングルトンごとに新しいOスペースを作成します;

	Merge two O-spaces if they intersect;

	2つのO空間が交差している場合は、それらを結合してください;

Result: Groups and their members

結果:グループとそのメンバー

---

If the algorithm does not converge and cannot provide unaltered groups twice consecutively, then the current image frame is dropped and the process interrupts until the next frame is captured.

アルゴリズムが収束せず、連続して2回も変更されないグループを提供できない場合、現在の画像フレームは破棄され、次のフレームがキャプチャされるまで処理は中断される。

### 3.4. Estimating F-Formations

### 3.4. F形成の推定

Estimating F-formations is an important step for a robot to become part of an ongoing social group interaction. F-formations denote different patterns in which people stand in group conversations. Based on the pattern, the robot could analyse the empty spots in the group and join the social group interaction, as presented in [27]; while F-formations denote typical patterns, the exact formation can deviate from the pattern significantly, thus causing uncertainty. To deal with uncertainties, we need one of the most robust prediction model based on statistical learning that analyses the data and then classifies the groups into different F-formations. The corresponding approach is denoted as estimating F-formation classifier for the robot (EFCR). In this aspect, a classification approach that is suitable with a relatively small amount of training data, which deals with multiple classes, works efficiently with categorical input variables, and performs faster, i.e., in real time, is of interest. An SVM classifier fulfils the requirements, which is considered as a classification approach. The core idea of SVM is to find a maximum marginal hyperplane (MMH) that best divides the dataset into classes. In case of linear data, SVM generates hyperplanes which segregates the classes in the best possible way. In cases of non-linear data, SVM uses a technique called the kernel trick to transform the low-dimensional input space into a high-dimensional space. Then, it segregates the data easily using linear separation. This technique helps in building a more accurate classifier in non-linear separation problem. Kernel has various types of functions, one of them is polynomial, which is useful for a non-linear hyperplane [71-73].

F形成の推定は、ロボットが進行中の社会的グループの交流に参加するための重要なステップです。F形成は、グループ会話において人々がどのようなパターンで立っているかを示すものであり、パターンに基づいてロボットはグループ内の空きスペースを分析し、[27]に示されるように社会的グループの交流に参加できます。F形成は典型的なパターンを示しますが、実際の形成はパターンから大きく逸脱することもあり、そのため不確実性が生じます。不確実性に対処するためには、データを分析し、グループを異なるF形成に分類する、統計学習に基づく最も堅牢な予測モデルの一つが必要です。このアプローチはロボットのためのF形成分類器推定(EFCR)と呼ばれます。この点において、比較的小さな学習データ量で、多クラスを扱い、カテゴリカル入力変数に効率的に対応し、リアルタイムで高速に動作する分類アプローチが求められます。SVM分類器はこれらの要件を満たし、分類手法として考えられます。SVMの基本的なアイデアは、データセットを最もよく分割する最大マージンハイパープレーン(MMH)を見つけることです。線形データの場合、SVMはクラスを最適に分離するハイパープレーンを生成します。非線形データの場合、カーネルトリックと呼ばれる手法を用いて低次元の入力空間を高次元空間に変換し、その後線形分離を容易にします。この技術は、非線形分離問題においてより正確な分類器の構築に役立ちます。カーネルにはさまざまな種類があり、その一つが多項式カーネルであり、非線形ハイパープレーンに有用です[71-73]。

A polynomial kernel is defined as the product between two vectors of features, and the sum of the multiplication of each pair of input values with a degree.

多項式カーネルは、特徴ベクトルの積の積と、その積に次数を掛けた和として定義されます。

\[
K\left( {x,{x}_{i}}\right)  = c + \sum {\left( x * {x}_{i}\right) }^{d} \tag{5}
\]

where \( x \) and \( {x}_{i} \) are vectors of features in the input space, \( d \) is the degree of the polynomial, and \( c \geq  0 \) is a free parameter trading off the influence of higher-order versus lower-order terms in the polynomial. The degree needs to be specified manually in the learning algorithm.

ここで\( x \)と\( {x}_{i} \)は入力空間の特徴ベクトル、\( d \)は多項式の次数、\( c \geq  0 \)は高次項と低次項の影響を調整する自由パラメータです。次数は学習アルゴリズム内で手動で指定する必要があります。

An SVM classifier is a statistical model, which learns the function \( f \) , when provided with input feature vector \( X \) , and maps to the output label \( y \) , i.e., \( f : X \rightarrow  y \) . This learnt function, \( f \) , is used with the test data (new input), \( X \) , to predict the result, \( y \) .

SVM分類器は統計モデルであり、入力特徴ベクトル\( f \)を与えられると関数\( f \)を学習し、出力ラベル\( y \)にマッピングします。すなわち、\( f : X \rightarrow  y \)です。この学習済み関数\( f \)は、テストデータ(新しい入力)\( X \)に対して適用され、結果としてグループのF形成の推定(予測)を行います。

In our scenario, the input feature vector \( X = \left\lbrack  {{x}_{1},{y}_{1},{\theta }_{1},{x}_{2},{y}_{2},{\theta }_{2},\ldots ,{x}_{n},{y}_{n},{\theta }_{n}}\right\rbrack \) , the spatial information \( \left( {{x}_{1},{y}_{1},{x}_{2},{y}_{2},\ldots ,{x}_{n},{y}_{n}}\right) \) , and orientational information \( \left( {{\theta }_{1},{\theta }_{2},\ldots ,{\theta }_{n}}\right) \) of people in the group. A unique label is assigned to different formations, which are considered as output, \( y \) . These input feature vectors are mapped to output labels, which are used to learn a function in the training phase. Then, in the testing phase, the new input feature vector is given to the learnt function, which results in the estimation (prediction) of the F-formation of the group.

私たちのシナリオでは、入力特徴ベクトル\( X = \left\lbrack  {{x}_{1},{y}_{1},{\theta }_{1},{x}_{2},{y}_{2},{\theta }_{2},\ldots ,{x}_{n},{y}_{n},{\theta }_{n}}\right\rbrack \)は、グループ内の人々の空間情報\( \left( {{x}_{1},{y}_{1},{x}_{2},{y}_{2},\ldots ,{x}_{n},{y}_{n}}\right) \)と方位情報\( \left( {{\theta }_{1},{\theta }_{2},\ldots ,{\theta }_{n}}\right) \)です。異なる形成には一意のラベルが割り当てられ、これが出力として扱われます\( y \)。これらの入力特徴ベクトルは出力ラベルにマッピングされ、学習段階で関数を学習します。その後、テスト段階では、新しい入力特徴ベクトルを学習済みの関数に入力し、グループのF形成の推定(予測)を行います。

EFCR is proposed to train with the group datasets, but most of the existing group datasets include only the standard F-formations and do not include the constrained formations. In this aspect, for constrained and larger groups, another novel approach is proposed in Algorithm 2 for estimating F-formations for larger groups (EFLG).

EFCRはグループデータセットでの訓練を提案しますが、既存の多くのグループデータセットは標準的なF形成のみを含み、制約された形成は含まれていません。この点において、制約された大規模グループに対しては、アルゴリズム2に基づく新たなアプローチ(EFLG)が提案されています。

The approach is based on the notion that variance of group could be used to estimate F-formations for larger groups, i.e., for groups more than three persons. In the semi-circular formation, group members are facing the same direction and the variance of angle of the group would be zero. Triangular and circular formations are in close relation in appearance. In the triangular formation, one person is standing far from others and group members are standing at opposite ends. In the circular formation, group members would be standing approximately at equal distance from each other, the variance of spatial location could be used as presented in Algorithm 2.

このアプローチは、グループの分散を利用して、3人以上の大きなグループのF形成を推定できるという考えに基づいています。半円形の形成では、グループメンバーは同じ方向を向き、角度の分散はゼロになります。三角形と円形の形成は外観上密接に関連しています。三角形の形成では、一人が他のメンバーから遠くに立ち、対称的に配置されます。円形の形成では、メンバーはおおよそ等間隔で立ち、空間位置の分散をアルゴリズム2に示すように利用できます。

Algorithm 2: Estimating F-formations

アルゴリズム2:F形成の推定

---

Data: Spatial locations(x, y), orientations \( \left( \theta \right) \) and groups in the scene

データ:空間位置(x, y)、方位\( \left( \theta \right) \)、およびシーン内のグループ

\( G = \) Number of people in the group, \( {V}_{d} = \) Variance of distance, \( {V}_{\theta } = \) Variance of

\( G = \) グループの人数、\( {V}_{d} = \) 距離の分散、\( {V}_{\theta } = \) 分散

orientation

方位

while \( G \geq  3 \) do

while \( G \geq  3 \) do

	Compute \( {V}_{d} \) ;

	<compute> \( {V}_{d} \) ;</compute>

	Compute \( {V}_{\theta } \) ;

	<compute> \( {V}_{\theta } \) ;</compute>

	if \( \left( {{V}_{\theta } =  = 0}\right) \) then

	if \( \left( {{V}_{\theta } =  = 0}\right) \) then

			Semi-Circular Formation;

			半円形配置;

		else if \( \left( \left( {V\_ d\left( x\right)  > {3}^{ * }V\_ d\left( y\right) }\right) \right) \) or \( \left( {{3}^{ * }V\_ d\left( x\right)  < V\_ d\left( y\right) }\right) \) and \( \left( {V\_ \theta  \neq  0}\right) \) then

		else if \( \left( \left( {V\_ d\left( x\right)  > {3}^{ * }V\_ d\left( y\right) }\right) \right) \) or \( \left( {{3}^{ * }V\_ d\left( x\right)  < V\_ d\left( y\right) }\right) \) and \( \left( {V\_ \theta  \neq  0}\right) \) then

			if (one person is facing two or more people) then

			if (一人が二人以上の人に向いている場合) then

				Triangular formation;

				三角形配置;

			else

			else

				Circular formation;

				円形配置;

			end

			end

	else if \( \left| {\left( {{V}_{ - }d\left( x\right)  - {V}_{ - }d\left( y\right) }\right)  < {0.1})}\right| \) then

	else if \( \left| {\left( {{V}_{ - }d\left( x\right)  - {V}_{ - }d\left( y\right) }\right)  < {0.1})}\right| \) then

			Circular formation;

			円形配置;

		else

		else

			Unrecognized formation;

			未認識の形成;

		end

		終了

end

終了

Result: F-formations

結果:Fフォーメーション

---

Studying these patterns further and finding an optimal empty spot in the group, as in work [27], would result in the robot joining the ongoing social interactions.

これらのパターンをさらに研究し、グループ内の最適な空き場所を見つけることは、作業[27]のように、ロボットが進行中の社会的相互作用に参加することにつながるだろう。

## 4. Experimental Setup

## 4. 実験設定

For the evaluation process, an experimental paradigm was developed in order to create a coffee break scenario, where people in the scene would be interacting in multiple group formations with varying sizes, and the robot would be integrated with our framework to evaluate the presented approaches. However, due to the COVID-19 pandemic, we could not conduct such an experiment and had to perform the experiment in a simulation environment instead of a real-world human environment. In terms of datasets, there are few existing group detection datasets, but these atr from an exocentric view, with either one large group of single formation [55,74] or multiple groups of different formations [6,75]. The coffee break dataset [6] has a similar plot to our idea of experiment, but from an exocentric view. So, to access this scene from an egocentric view, we replicated the dataset in the simulation.

評価プロセスのために、シーン内の人々が複数の異なる規模のグループ形成で交流し、ロボットが我々のフレームワークに統合されて提示されたアプローチを評価するためのコーヒーブレイクシナリオを作成する実験パラダイムを開発した。しかし、COVID-19パンデミックのため、そのような実験を実施できず、実世界の人間環境の代わりにシミュレーション環境で実験を行わざるを得なかった。データセットに関しては、既存のグループ検出データセットは少ないが、これらはエクソセントリックビューからのものであり、単一の大きなグループ[55,74]または異なる形成の複数のグループ[6,75]が含まれる。コーヒーブレイクデータセット[6]は、我々の実験のアイデアに類似したプロットを持つが、エクソセントリックビューからのものである。したがって、エゴセントリックビューからこのシーンにアクセスするために、我々はシミュレーション内でデータセットを再現した。

### 4.1. Coffee Break Dataset

### 4.1. コーヒーブレイクデータセット

The coffee break dataset provides a social scenario of coffee break. This was captured in a summer school program during coffee breaks. The dataset consists of two sequences, Sequence 1 (S1), with 13 people interacting, and Sequence 2 (S2), with 20 people interacting in the scene. This dataset provides a scenario of social interaction among people outdoors during a coffee break [6].

コーヒーブレイクデータセットは、コーヒーブレイク中の社会的シナリオを提供する。これは、サマースクールプログラム中のコーヒーブレイク時に撮影されたものである。データセットは、交流する13人のシーケンス(シーケンス1、S1)と、20人が交流するシーンのシーケンス2(S2)から構成されている。このデータセットは、屋外でのコーヒーブレイク中の人々の社会的交流のシナリオを提供する[6]。

In our work, we chose S2 and replicated S2 scene in the simulation, as this scene (S2) consists of more people and groups compared with S1. The S2 scene contains 20 people interacting in 7 different groups in 3 different formations. Among the 7 groups, 2 groups are interacting in vis-a-vis formations, 1 group in L-shape formation, and 4 groups are interacting in circular formations. This scene consists of a smaller number of groups and also does not cover the wide variety of formations mentioned by Kendon and Marshall. To cover this wide variety of formations, we developed one more scene similar to the experiment scene of our previous work [76]. This environment represents a conference lobby scenario where multiple (13) groups of virtual agents (VAs) with varying group sizes (2-5 VAs per group) are placed in different (6) spatial formations.

我々の研究では、S2を選択し、シミュレーション内でS2シーンを再現した。これは、S2の方がS1よりも多くの人とグループを含むためである。S2シーンには、7つの異なるグループが3つの異なる形成で交流している20人が含まれる。7つのグループのうち、2つは対面式の形成、1つはL字型の形成、残りの4つは円形の形成で交流している。このシーンは、より少ないグループ数で構成されており、KendonとMarshallが述べたさまざまな形成の範囲もカバーしていない。これらの多様な形成をカバーするために、我々は以前の研究[76]の実験シーンに似たもう一つのシーンを開発した。この環境は、複数(13)の仮想エージェント(VA)のグループ(各グループ2〜5 VAs)を異なる(6)空間形成に配置した会議ロビーのシナリオを表している。

### 4.2. Simulation Environment

### 4.2. シミュレーション環境

In the simulation environment, we created two scenes. The first scene is the replica of an actual human coffee break dataset [6], which is hereafter referred to as Scene 1. The second scene is a similar scene from our previous work [76], which consists of multiple formations with varying group sizes placed in different spatial formations, which is hereafter referred to as Scene 2.

シミュレーション環境では、2つのシーンを作成した。最初のシーンは、実際の人間のコーヒーブレイクデータセット[6]のレプリカであり、以降シーン1と呼ぶ。2番目のシーンは、我々の以前の研究[76]からの類似シーンで、複数の形成と異なるグループサイズを持つ配置された空間形成を含むものであり、以降シーン2と呼ぶ。

Regarding Scene 1, an actual human coffee break dataset is replicated to make the simulation scene as equivalent to the real-world human environment as possible. The scene is created in 3D using the Unity game engine [77].

シーン1については、実際の人間のコーヒーブレイクデータセットを再現し、シミュレーションシーンをできるだけ実世界の人間環境に近づけている。シーンはUnityゲームエンジン[77]を用いて3Dで作成した。

While creating the scene, to replicate S2, we used similar colours and patterns, such as for the floor, the walls, the doors, the windows, and the side lamps. A side landscape is also placed with shrubs, plants, and flowers. A table is placed with drinks, snacks, water bottles, glasses, tea, and a coffee machine. A flyer and two chairs are placed on the side of the wall. All these assets (materials) are available in the Unity asset store. The scene is populated with VAs, made using the make human software [78]. The VAs are made with similar features to the people in S2, such as hair, facial features, skin colour, ethnicity, height, size, clothes, and footwear (seen in Figure 7).

シーン作成にあたり、S2を再現するために、床、壁、ドア、窓、側面のランプなどに類似した色やパターンを使用した。側面には低木や植物、花が配置されている。テーブルには飲み物、スナック、水のボトル、グラス、紅茶、コーヒーマシンが置かれている。壁側にはフライヤーと椅子2脚が配置されている。これらのアセット(素材)はUnityアセットストアで入手可能である。シーンには、make humanソフトウェア[78]を用いて作成されたVAsが配置されている。VAsは、S2の人々と類似した特徴(髪型、顔の特徴、肌の色、民族性、身長、体格、服装、靴)を持つように作られている(図7参照)。

To make the scene more equivalent to the human environment, the VAs in the scene are integrated with some inbuilt human behaviours similar to the people in S2, such as head nodding, body movements, gestures, and more, using Mixamo software [79]. Similar to S2, the scene contains 20 VAs interacting in 7 different groups in 3 different formations: 2 groups in vis-a-vis formations, 1 group in L-shape formation and 4 groups in circular formations. The VAs are placed in a similar position as people in S2. The people in S2 did not have much movement in the human environment, and are standing in the same position and group throughout the dataset. The people only had a few head or body movements, which were also simulated for the VAs in the scene.

シーンをより人間環境に近づけるために、シーン内のVAsには、S2の人々と類似した頭のうなずき、身体の動き、ジェスチャーなどの人間の行動をいくつか組み込んだ。これらはMixamoソフトウェア[79]を用いて実現した。S2と同様に、シーンには7つの異なるグループで交流する20のVAsが配置されており、2つのグループは対面式、1つはL字型、4つは円形の形成である。VAsはS2の人々と同じ位置に配置されている。S2の人々は、実環境ではあまり動かず、データセット全体を通じて同じ位置とグループにとどまっていた。彼らはわずかな頭や身体の動きしかしなかったが、それもシーン内のVAsに対してもシミュレートされている。

![bo_d3ecpr4601uc738ioje0_13_448_251_1109_463_0.jpg](images/bo_d3ecpr4601uc738ioje0_13_448_251_1109_463_0.jpg)

Figure 7. Image (b) is the virtual scene of image (a), which is an original image from the coffee dataset. The similarities in image (b), with respect to image (a), could be seen as the floor, plants, walls with windows, doors, lamps, same amount of VAs as people, and their appearance. The table with machines for coffee and tea, glasses, snacks, and water bottles could also be seen image (b). The VAs in the simulation scene are created in such a way that their appearance resembles-i.e., make them appear as close as possible to-the people in the scene.

図7. 画像(b)は画像(a)の仮想シーンであり、コーヒーデータセットの元の画像です。画像(b)と画像(a)との類似点として、床、植物、窓のある壁、ドア、ランプ、人物と同じ数のVAs、そしてそれらの外観が挙げられます。コーヒーと紅茶のための機械、グラス、おやつ、水のボトルが置かれたテーブルも画像(b)に見られます。シミュレーションシーン内のVAsは、外観がシーン内の人々にできるだけ似せて作られており、近づけて見えるように設計されています。

Regarding Scene 2, a simulated environment with a number of groups with various formations is created similar to the experimental scene in our previous work [76] (seen in Figure 8). The scene is created in a similar fashion to Scene 1, i.e., using the same software. Scene 2 consists of 36 VAs positioned in 13 different groups in 6 different formations: 2 groups in vis-a-vis formations, 2 groups in side-by-side formations, 3 groups in L-shape formations, 1 group in triangular formation, 1 group in semi-circular formation, and 4 groups in circular formations as shown in Figure 8. This scene is built to capture the diverse formations mentioned by Kendon and Marshall.

シーン2については、我々の前回の研究[76]の実験シーンに類似した、さまざまな編成のグループを持つ仮想環境が作成されました(図8参照)。このシーンは、シーン1と同様の方法、すなわち同じソフトウェアを用いて作成されています。シーン2は、13の異なるグループに配置された36のVAsで構成されており、6つの異なる編成で配置されています:対面式の2グループ、並列式の2グループ、L字型の3グループ、三角形の1グループ、半円形の1グループ、円形の4グループです(図8参照)。このシーンは、KendonとMarshallが述べた多様な編成を捉えるために構築されました。

![bo_d3ecpr4601uc738ioje0_13_455_1258_1102_551_0.jpg](images/bo_d3ecpr4601uc738ioje0_13_455_1258_1102_551_0.jpg)

Figure 8. The global view of the virtual Scene 2, which resembles a conference break social interaction scenario similar to the experiment scene of our previous work [76]. The scene consists a large hall with a red carpet, walls, paintings on the wall, round pub-style tables, and the VAs positioned in a number of groups with varying sizes in different formations.

図8. 仮想シーン2の全体像であり、我々の前回の研究[76]の実験シーンに類似した会議休憩中の交流シナリオを模しています。このシーンは、赤いカーペットの大ホール、壁、壁に掛けられた絵画、円形のパブスタイルのテーブル、さまざまなサイズのグループに配置されたVAsで構成されています。

A virtual Pepper robot endowed with our framework is deployed in both the scenes. The robot is using a built-in RGB camera, present on its forehead for RGB data, and a laser is placed in the left eye of the robot for the depth information. The robot present in Scene 1 and the egocentric view of Scene 1 from the robot's head camera could be seen in Figure 9.

我々のフレームワークを搭載した仮想のPepperロボットが、両方のシーンに展開されています。ロボットは、額に搭載されたRGBカメラを用いてRGBデータを取得し、左目にレーザーを設置して深度情報を得ています。シーン1に登場するロボットと、ロボットのヘッドカメラからのシーン1の自己中心的ビューは、図9に示されています。

![bo_d3ecpr4601uc738ioje0_14_451_254_1106_459_0.jpg](images/bo_d3ecpr4601uc738ioje0_14_451_254_1106_459_0.jpg)

Figure 9. Images from Scene 1, (a) virtual Pepper robot is facing the scene where VAs are interacting with each other. (b) The egocentric view of the scene from the robot's camera.

図9. シーン1の画像(a)は、VAsが互いに交流しているシーンに向き合う仮想のPepperロボットです。画像(b)は、ロボットのカメラから見たシーンの自己中心的ビューです。

## 5. Evaluation Process

## 5. 評価プロセス

To evaluate our approaches in both the scenes using the robot, we randomly generated positions for the robot throughout the scenes (1st and 2nd). From these positions, the robot could perceive the VAs and groups from different points of view. These different positions result in variation of the position and orientation of VAs in the scene. For example, one virtual agent (VA) could be facing centre from one position of the robot, but the same VA could be facing a different direction, i.e., facing left, facing right, or facing about, from another position of the robot. These positions further result in F-formation variations, i.e., a circular formation could be perceived as a L-shape or vis-a-vis formation when one of the group member is not seen by the robot. These variations, along with an egocentric view, present a challenge with which to evaluate our approaches.

ロボットを用いて両方のシーンで我々のアプローチを評価するために、シーン(1および2)全体にわたってロボットの位置をランダムに生成しました。これらの位置から、ロボットは異なる視点からVAsやグループを認識できます。これらの異なる位置は、シーン内のVAsの位置と向きの変化をもたらします。例えば、ある仮想エージェント(VA)がロボットのある位置から中央を向いている場合でも、別の位置からは異なる方向(左向き、右向き、または約向き)を向いていることがあります。これらの位置の違いは、F-formationの変化にもつながります。例えば、円形の編成が、ロボットに見えないグループメンバーがいる場合にはL字型や対面式に見えることもあります。これらの変動と自己中心的ビューは、我々のアプローチを評価する上での課題となります。

The random positions generated for the robot to evaluate our approaches in the both the scenes is presented in Table 2.

我々のアプローチを両方のシーンで評価するためにロボットにランダムに生成された位置は、表2に示されています。

Table 2. Random positions for the robot in both the scenes.

表2. 両方のシーンにおけるロボットのランダム位置。

<table><tr><td>Scenes</td><td>Random</td><td>Retained</td><td>One VA</td><td>Positions</td></tr><tr><td>Scene 1</td><td>100</td><td>31</td><td>3</td><td>28</td></tr><tr><td>Scene 2</td><td>500</td><td>276</td><td>29</td><td>247</td></tr></table>

<table><tbody><tr><td>シーン</td><td>ランダム</td><td>保持</td><td>1つのVA</td><td>位置</td></tr><tr><td>シーン1</td><td>100</td><td>31</td><td>3</td><td>28</td></tr><tr><td>シーン2</td><td>500</td><td>276</td><td>29</td><td>247</td></tr></tbody></table>

Random: randomly generated positions. Retained: positions from where the robot could see the VAs. One VA: positions from where only one VA could be seen. Position: positions left to evaluate our approaches.

ランダム:ランダムに生成された位置。保持:ロボットがVAを見ることができた位置。1つのVA:1つのVAだけを見ることができた位置。位置:アプローチの評価に残された位置。

For Scene 1, we generated 100 random positions (see Figure 10 and Table 2) which covered the scene. Within these 100 positions, the positions from where the robot could not see the VAs are removed and the remaining positions are retained. In this fashion, we ended with 31 positions which could be seen in Figure 11. From these 31 positions, only one VA could be seen in 3 positions, which are removed, as it takes at least 2 people for an interaction to be called a group interaction. Finally, we are left with 28 positions (view from two such positions are seen in Figure 12), which are used to evaluate our approaches, i.e., V6KP, DGO, and EFCR, using the robot.

シーン1では、シーンをカバーするために100のランダムな位置(図10および表2参照)を生成しました。これらの100の位置のうち、ロボットがVAを見ることができなかった位置を除外し、残りの位置を保持しました。この方法で、図11に示す31の位置に絞り込みました。これらの31の位置のうち、1つのVAだけを見ることができたのは3つの位置であり、これは除外されました。なぜなら、グループインタラクションと呼ばれるには少なくとも2人が必要だからです。最終的に、28の位置(図12に示す2つの位置からの視点)に絞り込み、これらを用いてロボットを使ったアプローチ(V6KP、DGO、EFCR)の評価を行いました。

![bo_d3ecpr4601uc738ioje0_15_452_253_1088_562_0.jpg](images/bo_d3ecpr4601uc738ioje0_15_452_253_1088_562_0.jpg)

Figure 10. The global view of Scene 1 along with 100 randomly generated positions for the robot, which are represented by purple-coloured cylindrical spaces. The arrows represent the facing direction of the robot for respective position (best viewed in colour).

図10. シーン1の全体像と、ロボットのためにランダムに生成された100の位置(紫色の円筒空間で表現)。矢印は各位置におけるロボットの向き方向を示す(カラーでの閲覧推奨)。

![bo_d3ecpr4601uc738ioje0_15_454_950_1089_542_0.jpg](images/bo_d3ecpr4601uc738ioje0_15_454_950_1089_542_0.jpg)

Figure 11. The global view of Scene 1, along with 31 positions for the robot and the robot could be seen in one of the purple cylindrical spaces (best viewed in colour).

図11. シーン1の全体像と、ロボットの31の位置(紫色の円筒空間のいずれかでロボットが見える)。

![bo_d3ecpr4601uc738ioje0_15_452_1591_1099_351_0.jpg](images/bo_d3ecpr4601uc738ioje0_15_452_1591_1099_351_0.jpg)

Figure 12. Images (a) and (b) are sample images of Scene 1 through robot's camera from two positions (best viewed in colour).

図12. (a)と(b)は、ロボットのカメラから見たシーン1のサンプル画像(カラーでの閲覧推奨)。

In Scene 2, we generated 500 random positions (seen in Figure 13 and Table 2) to cover the whole scene. More positions are generated as the area of this scene is bigger than Scene 1. Similar to the process in Scene 1, the positions from where the robot could not see the VAs (224) and the positions from where only \( 1\mathrm{{VA}} \) could be seen (29), are removed. Finally, we are left with 247 positions (seen in Figure 14) to evaluate our approaches using the robot.

シーン2では、シーン全体をカバーするために500のランダムな位置(図13および表2参照)を生成しました。シーンの面積がシーン1より大きいため、より多くの位置を生成しています。シーン1と同様に、ロボットがVAを見ることができなかった位置(224)と、\( 1\mathrm{{VA}} \)だけが見える位置(29)を除外しました。最終的に、ロボットを用いたアプローチの評価のために247の位置(図14参照)に絞り込みました。

![bo_d3ecpr4601uc738ioje0_16_454_361_1085_626_0.jpg](images/bo_d3ecpr4601uc738ioje0_16_454_361_1085_626_0.jpg)

Figure 13. The global view of Scene 2, along with 500 randomly generated positions for the robot, which are represented by purple-coloured cylindrical spaces. The arrows represent the facing direction of the robot for respective position (best viewed in colour).

図13. シーン2の全体像と、ロボットのためにランダムに生成された500の位置(紫色の円筒空間で表現)。矢印は各位置におけるロボットの向き方向を示す(カラーでの閲覧推奨)。

![bo_d3ecpr4601uc738ioje0_16_454_1123_1086_593_0.jpg](images/bo_d3ecpr4601uc738ioje0_16_454_1123_1086_593_0.jpg)

Figure 14. The global view of Scene 1, along with 247 positions for the robot (best viewed in colour).

図14. シーン2の全体像と、ロボットの247の位置(カラーでの閲覧推奨)。

### 5.1. Ground Truth Annotation

### 5.1. グラウンドトゥルースのアノテーション

For the ground truth, the robot is placed in all the robot positions for both the scenes, i.e., 28 positions in Scene 1 and 247 positions in Scene 2. Then, we hand annotated the scene, as perceived using the robot's camera, for the ground truth data of the head orientations of VAs, groups interacting, and their F-formations. This process was achieved for each position of the robot for both the scenes.

グラウンドトゥルースのために、両方のシーンのすべてのロボット位置(シーン1では28、シーン2では247)にロボットを配置しました。その後、ロボットのカメラを用いて認識されたシーンを手作業でアノテーションし、VAの頭の向き、グループのインタラクション、Fフォーメーションのグラウンドトゥルースデータを作成しました。この作業は、両方のシーンの各ロボット位置ごとに行われました。

In Scene 1, VAs were placed with similar poses (body orientation) and positions (same groups) as the people in the coffee dataset. The same was carried out for Scene 2, with respect to [76].

シーン1では、VAはコーヒーデータセットの人々と同様のポーズ(身体の向き)と位置(同じグループ)で配置されました。シーン2についても、[76]に基づいて同様に行われました。

For head orientation, the VAs who were detected using [69], or whose face could be seen and not occluded by other VAs, were considered. Based on their facing direction, the VAs were classified into 4 classes: facing about, facing right, facing centre, and facing left, as presented in Table 3. For group detection, the coffee dataset provides the ground truth for the groups in the scene which was considered for Scene 1 and [76] provides ground truth, which was considered for Scene 2. The ground truth of the coffee dataset was taken into account during the hand-annotation process for Scene 1, i.e., two VAs perceived from an egocentric view, said to be in a group if the respective people in the coffee dataset, were in the same group. A similar process was applied for Scene 2 with respect to [76]. For F-formations, the groups perceived using the robot's camera were classified into one of the 7 F-formations presented in Section 2.1, for all the robot positions for both the scenes, as presented in Table 4.

頭の向きについては、[69]を用いて検出されたVA、または顔が見え、他のVAによって遮られていないVAを対象としました。向きに基づき、VAは4つのクラスに分類されました:正面、右向き、中央向き、左向き(表3参照)。グループ検出については、コーヒーデータセットがシーン内のグループのグラウンドトゥルースを提供し、シーン1ではこれを考慮し、[76]がシーン2のグラウンドトゥルースを提供しました。コーヒーデータセットのグラウンドトゥルースは、シーン1の手作業アノテーション時に考慮され、エゴセントリックビューから認識された2つのVAが同じグループに属すると判断されました。シーン2についても、[76]に基づき同様の手順を適用しました。Fフォーメーションについては、ロボットのカメラを用いて認識されたグループを、セクション2.1で示した7つのFフォーメーションのいずれかに分類し、両シーンのすべてのロボット位置について表4に示します。

Table 3. Head orientation: ground truth information for both the scenes.

表3. 頭の向き:両シーンのグラウンドトゥルース情報。

<table><tr><td>Scenes</td><td>Facing about</td><td>Facing Right</td><td>Facing Center</td><td>Facing Left</td><td>Total</td></tr><tr><td>Scene 1</td><td>49</td><td>44</td><td>30</td><td>45</td><td>168</td></tr><tr><td>Scene 2</td><td>542</td><td>303</td><td>274</td><td>250</td><td>1369</td></tr></table>

<table><tbody><tr><td>シーン</td><td>向き合う</td><td>右向き</td><td>中央向き</td><td>左向き</td><td>合計</td></tr><tr><td>シーン1</td><td>49</td><td>44</td><td>30</td><td>45</td><td>168</td></tr><tr><td>シーン2</td><td>542</td><td>303</td><td>274</td><td>250</td><td>1369</td></tr></tbody></table>

Table 4. F-formations: ground truth information for both the scenes.

表4.Fフォーメーション:両方のシーンの真の情報。

<table><tr><td>Scenes</td><td>Vis-a-Vis</td><td>Side-by-Side</td><td>L-Shape</td><td>Circular</td><td>Semi-Circular</td><td>Triangular</td><td>Total Groups</td></tr><tr><td>Scene 1</td><td>11</td><td>0</td><td>17</td><td>20</td><td>0</td><td>0</td><td>48</td></tr><tr><td>Scene 2</td><td>56</td><td>87</td><td>136</td><td>63</td><td>28</td><td>20</td><td>390</td></tr></table>

<table><tbody><tr><td>シーン</td><td>ビザ・ビザ</td><td>並列</td><td>L字型</td><td>円形</td><td>半円形</td><td>三角形</td><td>合計グループ数</td></tr><tr><td>シーン1</td><td>11</td><td>0</td><td>17</td><td>20</td><td>0</td><td>0</td><td>48</td></tr><tr><td>シーン2</td><td>56</td><td>87</td><td>136</td><td>63</td><td>28</td><td>20</td><td>390</td></tr></tbody></table>

### 5.2. Metrics

### 5.2. メトリクス

Different metrics were used to evaluate the different approaches. For head orientation and F-formations, the confusion matrix and accuracy were calculated. For group detection, the measure of accuracy from [6-8] was used. A group was correctly detected if at least \( \lceil \left( {T.\left| G\right| }\right) \rceil \) of their members were found by the approach, where \( \left| G\right| \) is the cardinality of group \( \mathrm{G} \) and \( \mathrm{T} \in  \left\lbrack  {0,1}\right\rbrack \) is an arbitrary threshold, called the tolerance threshold. We focused on values T: \( 2/3 \) and 1 similar to [7]. Using these metrics, precision, recall, and F-measure were calculated for the group detection process.

異なるアプローチを評価するためにさまざまなメトリクスが使用された。頭の向きとF-formationについては、混同行列と正確度が計算された。グループ検出には、[6-8]の正確度測定が用いられた。グループが正しく検出されたのは、そのメンバーの少なくとも\( \lceil \left( {T.\left| G\right| }\right) \rceil \)がアプローチによって見つかった場合であり、\( \left| G\right| \)はグループ\( \mathrm{G} \)の基数、\( \mathrm{T} \in  \left\lbrack  {0,1}\right\rbrack \)は任意の閾値であり、許容閾値と呼ばれる。私たちは値T:\( 2/3 \)および1に焦点を当て、[7]と類似した設定とした。これらのメトリクスを用いて、グループ検出プロセスの精度(precision)、再現率(recall)、F値(F-measure)が計算された。

## 6. Results

## 6. 結果

In this section, we evaluate our approaches and present the results sequentially in the order of the head orientation, group detection, and estimating F-formations. An overview of the process involved in the evaluation of our approaches is presented (as seen in Figure 15) as follows: a simulated robot was endowed with our approaches and placed in all the robot positions in both the scenes to estimate the head orientation, detect the groups, and estimate the F-formations. The estimated orientations were compared against the ground truth of head orientation, which presents the head orientation results in both the scenes. Next, the resulting orientation along with the spatial information was used to detect groups using our DGO. These detected groups were compared against the ground truth of groups, which presents the group detection results in both the scenes. Finally, the information of VAs along with the ground truth of groups and ground truth of F-formations were used to train the classifier with \( {80}\% \) of the data of Scene 2. Then, the trained model was tested with 20% of the data of Scene 2 and the outcome was compared against the ground truth of the F-formation, which presents the F-formation results for Scene 2. Then, for robust evaluation, the trained model was tested with the 100% data of Scene 1 and the outcome was compared against the ground truth of F-formation, which presents the F-formation results for Scene 1.

本節では、我々のアプローチを評価し、頭の向き、グループ検出、F-formationの推定の順に結果を示す。評価に関わるプロセスの概要(図15参照)を以下に示す:シミュレートされたロボットに我々のアプローチを搭載し、シーン内のすべてのロボット位置に配置して、頭の向きの推定、グループの検出、F-formationの推定を行った。推定された向きは、実際の頭の向きの真値と比較された。次に、その向きと空間情報を用いて、我々のDGOを使ってグループを検出した。これらの検出されたグループは、実際のグループの真値と比較された。最後に、VAsの情報とグループおよびF-formationの真値を用いて、シーン2のデータの\( {80}\% \)を使って分類器を訓練した。その後、訓練済みモデルをシーン2の20%のデータでテストし、その結果をF-formationの真値と比較した。次に、より堅牢な評価のために、訓練済みモデルをシーン1の100%のデータでテストし、その結果をF-formationの真値と比較した。

![bo_d3ecpr4601uc738ioje0_18_454_260_1089_236_0.jpg](images/bo_d3ecpr4601uc738ioje0_18_454_260_1089_236_0.jpg)

Figure 15. We organise the presentation of the results according to three main headings: head orientation, group detection, and estimating F-formation. In head orientation and group detection, we present the results first from Scene 1 and then from Scene 2. In estimating F-formation, however, we first present the results from Scene 2, as the classifier was trained on Scene 2. For robust evaluation, the trained classifier was then used on Scene 1 data. A summary that illustrates the presentation of the experimental results is shown.

図15. 結果の提示は、頭の向き、グループ検出、F-formationの推定の3つの主要な見出しに従って整理している。頭の向きとグループ検出では、まずシーン1の結果を示し、その後シーン2の結果を示す。ただし、F-formationの推定では、分類器がシーン2で訓練されたため、最初にシーン2の結果を示す。堅牢な評価のために、訓練済みの分類器をシーン1のデータに適用した結果も示す。実験結果の提示方法を示す概要も併せて示す。

### 6.1. Estimating Head Orientation

### 6.1. 頭の向きの推定

For Scene 1, VAs are placed with similar body orientation as people in the coffee dataset. The robot is endowed with our V6KP and placed in the robot positions to estimate the head orientation of VAs in the scene, similar to Figure 16, which is an egocentric view of the scene from the robot. The skeleton structure in the figure is acquired from [69], and \( \mathrm{V}6\mathrm{{KP}} \) is built on this to estimate the head orientation, i.e., facing the direction of VAs, which is shown in the figure.

シーン1では、VAsはコーヒーデータセットの人々と同様の身体の向きで配置されている。ロボットには我々のV6KPを搭載し、図16のようにロボットからの自己視点でシーン内のVAsの頭の向きを推定するために配置された。図のスケルトン構造は[69]から取得されており、\( \mathrm{V}6\mathrm{{KP}} \)はこれに基づいて頭の向き、すなわちVAsの向いている方向を推定するために構築された。図に示されている。

![bo_d3ecpr4601uc738ioje0_18_454_1028_1085_813_0.jpg](images/bo_d3ecpr4601uc738ioje0_18_454_1028_1085_813_0.jpg)

Figure 16. Our approach-V6KP, estimating head orientation of people in Scene 1 from an egocentric view. The letter A stands for facing about, R stands for facing right, C stands for facing centre, and L stands for facing left.

図16. 我々のアプローチ-V6KP、シーン1の人々の頭の向きを自己視点から推定。Aは正面、Rは右向き、Cは中央向き、Lは左向き。

The robot starts estimating the head orientation of the VAs in the scene for each position and compares against the concerned ground truth. This process was carried out for all the 28 positions of the robot. The results are detailed in Table 5, which presents the confusion matrix and accuracy for head orientation of VAs for all the 28 positions. In the table, total represents the number of occurrences of the facing direction in all the positions combined, unrecognized represents the VAs in the scene being detected using [69], but their orientation was not estimated by our approach; the accuracy is the number of correct detections by total occurrences.

ロボットは各位置でシーン内のVAsの頭の向きを推定し、対応する真値と比較する。このプロセスはロボットの28のすべての位置で行われた。結果は表5に詳細に示されており、28のすべての位置におけるVAsの頭の向きの混同行列と正確度を示している。表中のtotalは、すべての位置での向きの出現回数の合計を表し、unrecognizedは[69]を用いて検出されたが、我々のアプローチでは向きが推定されなかったVAsを示す。正確度は、正しく検出された数を総出現回数で割ったものである。

Table 5. Scene 1 estimating the head orientation: confusion matrix and accuracy.

表5. シーン1における頭の向き推定:混同行列と正確度。

<table><tr><td>Facing Direction</td><td>About</td><td>Right</td><td>Center</td><td>Left</td><td>Unrecognized</td><td>Total</td><td>Accuracy (%)</td><td/></tr><tr><td>About</td><td>25</td><td>5</td><td>6</td><td>4</td><td>9</td><td>49</td><td>51</td><td/></tr><tr><td>Right</td><td>4</td><td>31</td><td>4</td><td>0</td><td>5</td><td>44</td><td>70</td><td/></tr><tr><td>Center</td><td>1</td><td>2</td><td>24</td><td>1</td><td>2</td><td>30</td><td>80</td><td/></tr><tr><td>Left</td><td>2</td><td>0</td><td>3</td><td>38</td><td>2</td><td>45</td><td>84</td><td/></tr></table>

<table><tbody><tr><td>向き</td><td>について</td><td>右</td><td>中央</td><td>左</td><td>未認識</td><td>合計</td><td>正確さ(％)</td><td></td></tr><tr><td>について</td><td>25</td><td>5</td><td>6</td><td>4</td><td>9</td><td>49</td><td>51</td><td></td></tr><tr><td>右</td><td>4</td><td>31</td><td>4</td><td>0</td><td>5</td><td>44</td><td>70</td><td></td></tr><tr><td>中央</td><td>1</td><td>2</td><td>24</td><td>1</td><td>2</td><td>30</td><td>80</td><td></td></tr><tr><td>左</td><td>2</td><td>0</td><td>3</td><td>38</td><td>2</td><td>45</td><td>84</td><td></td></tr></tbody></table>

From Table 5, the first row represents the facing about direction. In total, of 49 occurrences of facing about, our V6KP was able to correctly detect 25 occurrences as facing about, and wrongly detected as other facing directions in 15 occurrences. In 9 instances, VAs could not be categorized into one of the facing direction, which is represented as unrecognized. Similar to facing about, facing right, facing centre, and facing left are also presented. The facing about direction has low accuracy, with approximately 51%, and the facing left direction has high accuracy, with approximately 85%. The average accuracy of the approach is 71%. The reasons for low accuracy are unclear. It could be occlusion of VAs with each other, the long distance between the robot and the VAs, or insufficient contrast between the VAs attire or skin colour and the background texture.

表5の最初の行は向きについての方向を表しています。合計49回の向きについての検出のうち、私たちのV6KPは25回を正しく向きについて検出し、15回を他の向きとして誤検出しました。9回はVAsを向きのいずれかに分類できず、未認識として表されています。向きについてと同様に、向き右、中央、左も示されています。向きについての方向の精度は低く、約51％であり、左向きの精度は高く、約85％です。全体の平均精度は71％です。低精度の原因は不明です。VAs同士の遮蔽、ロボットとVAsの距離の長さ、またはVAsの衣装や肌の色と背景の質感のコントラスト不足が考えられます。

The confusion matrix presents the true positives, true negatives, false positives and false negatives information. In here, the correctly detected occurrences are true positives, and diagonally the other correctly detected occurrences are true negatives. The row presents the false negatives, and the column presents the false positives for the selected predicted class. For example, in Table 5, if we consider the facing right, the correctly detected 31 occurrences are the true positives. The other correctly detected occurrences, i.e., 25 facing about, 24 facing center and 28 facing left are true negatives. The row presents the false negatives, i.e., 4 occurrences of facing about, 4 occurrences of facing centre, 0 occurrences of facing left, and 5 occurrences of unrecognised are false negatives. The column presents the false positives, i.e., 5 occurrences of facing about, 2 occurrences of facing centre, and 0 occurrences of facing left are false positives.

混同行列は真陽性、真陰性、偽陽性、偽陰性の情報を示します。ここで、正しく検出された回数は真陽性であり、対角線上の他の正しく検出された回数は真陰性です。行は偽陰性を示し、列は選択された予測クラスに対する偽陽性を示します。例えば、表5では、向き右を考えると、正しく検出された31回は真陽性です。その他の正しく検出された回数、すなわち向きについて25回、中央向きについて24回、左向きについて28回は真陰性です。行は偽陰性を示し、向きについて4回、中央向きについて4回、左向きについて0回、未認識について5回は偽陰性です。列は偽陽性を示し、向きについて5回、中央向きについて2回、左向きについて0回は偽陽性です。

To analyse the runtime performance of V6KP, the average time taken for the robot to compute the head orientation of VAs in the scene for 28 positions was computed, which was \( {2.9762}\mathrm{\;s} \) . In this, the time taken to compute the \( 2\mathrm{D} \) pose of VAs was \( {2.9722}\mathrm{\;s} \) and to estimate orientation was \( {0.0037}\mathrm{\;s} \) . The approach was run on a laptop with an NVIDIA GeForceGTX-1080 GPU. The 2D pose algorithm was a part of Openpose and achieved the speed of 8.8 fps for a video with 19 people in the original implementation [69] which is in \( C +  + \) language. We are using an implementation of pose algorithm [69] with chainer [80], which is a framework for neural networks written purely in python language using python libraries. This is the main reason for greater time consumption. However, with recent development in deep learning, many approaches are presented to detect people in the scene in real time. These could be used with our V6KP to increase the frame rate per second with the robot. In total, the approach results in good overall accuracy and also demonstrates efficiently our head orientation (V6KP) approach with a mobile robot using a built-in RGB camera from an egocentric view.

V6KPの実行時間性能を分析するために、シーン内のVAsの頭の向きを計算するのにかかる平均時間を28の位置で測定しました。その結果は\( {2.9762}\mathrm{\;s} \)です。この中で、VAsの\( 2\mathrm{D} \)ポーズを計算するのにかかった時間は\( {2.9722}\mathrm{\;s} \)、向きを推定するのにかかった時間は\( {0.0037}\mathrm{\;s} \)です。このアプローチは、NVIDIA GeForceGTX-1080 GPUを搭載したノートパソコン上で実行されました。2DポーズアルゴリズムはOpenposeの一部であり、元の実装[69]では19人の動画に対して8.8 fpsの速度を達成しています[69]。これは\( C +  + \)言語で記述されています。私たちは、Pythonだけで書かれたニューラルネットワークのフレームワークであるChainer[80]を用いたポーズアルゴリズム[69]の実装を使用しています。これが時間消費が多い主な理由です。しかし、近年の深層学習の進展により、リアルタイムでシーン内の人を検出する多くの手法が提案されています。これらは私たちのV6KPと組み合わせて、ロボットのフレームレートを向上させることが可能です。全体として、このアプローチは良好な精度を示し、内蔵RGBカメラを用いたエゴセントリックビューのモバイルロボットにおいて、頭の向き(V6KP)を効率的に推定できることを示しています。

For the 2nd simulation scene, VAs were placed with a similar body orientation, as the VAs in [76]. Similar to Scene 1, the robot was endowed with V6KP and the estimating process was performed for all the 247 positions of the robot-the results are detailed in Table 6.

第2のシミュレーションシーンでは、VAsは[76]のVAsと同様の体の向きで配置されました。シーン1と同様に、ロボットにはV6KPが搭載され、推定プロセスはロボットの247の位置すべてに対して行われ、その結果は表6に詳述されています。

Table 6. Scene 2 estimating the head orientation: confusion matrix and accuracy.

表6. シーン2の頭の向き推定:混同行列と精度。

<table><tr><td>Facing Direction</td><td>About</td><td>Right</td><td>Centre</td><td>Left</td><td>Unrecognized</td><td>Total</td><td>Accuracy (%)</td><td/></tr><tr><td>About</td><td>319</td><td>41</td><td>99</td><td>40</td><td>44</td><td>542</td><td>58</td><td/></tr><tr><td>Right</td><td>23</td><td>229</td><td>32</td><td>1</td><td>18</td><td>303</td><td>75</td><td/></tr><tr><td>Center</td><td>5</td><td>15</td><td>230</td><td>18</td><td>6</td><td>274</td><td>83</td><td/></tr><tr><td>Left</td><td>10</td><td>4</td><td>23</td><td>204</td><td>9</td><td>250</td><td>81</td><td/></tr></table>

<table><tbody><tr><td>向き</td><td>について</td><td>右</td><td>中央</td><td>左</td><td>未認識</td><td>合計</td><td>正確さ(％)</td><td></td></tr><tr><td>について</td><td>319</td><td>41</td><td>99</td><td>40</td><td>44</td><td>542</td><td>58</td><td></td></tr><tr><td>右</td><td>23</td><td>229</td><td>32</td><td>1</td><td>18</td><td>303</td><td>75</td><td></td></tr><tr><td>中央</td><td>5</td><td>15</td><td>230</td><td>18</td><td>6</td><td>274</td><td>83</td><td></td></tr><tr><td>左</td><td>10</td><td>4</td><td>23</td><td>204</td><td>9</td><td>250</td><td>81</td><td></td></tr></tbody></table>

Similar to Scene 1, here too, the confusion matrix presented the true positives, true negatives, false positives, and false negatives information for Scene 2 in Table 6. From Table 6, VAs were facing about in 542 instances, in which 319 were recognized correctly by our algorithm. This had low accuracy, similar to Scene 1. The average accuracy of the approach was 74%, while comparing the individual accuracies and average accuracy of Scene 1 to Scene 2. All the individual percentages and the average accuracy increased, except facing left in Scene 2. In this scene, the VAs were detected by [69], but in a few instances, the VAs could not be categorized into one of the four facing directions. Of the total 1369 instances, in 75 instances, VAs' facing directions could not be categorized into one of the four facing directions, which is 5% of the total instances. The unrecognized instances and percentage are negligible when the total instances are taken into account. The average runtime performance of V6KP was similar to Scene 1.

シーン1と同様に、ここでも混同行列は表6に示されたシーン2の真陽性、真陰性、偽陽性、偽陰性の情報を示している。表6から、VAsは約542回のインスタンスで面しており、そのうち319回は我々のアルゴリズムによって正しく認識された。これはシーン1と同様に低い精度であった。アプローチの平均精度は74％であり、シーン1とシーン2の個別の精度と平均精度を比較したところ、すべての個別パーセンテージと平均精度が向上した。ただし、シーン2の左向きに面している場合を除く。このシーンでは、VAsは[69]によって検出されたが、いくつかのインスタンスではVAsの向きが4つの方向のいずれかに分類できなかった。総インスタンス数1369のうち、75インスタンス(全体の5％)ではVAsの向きが4つの方向のいずれにも分類できなかった。未認識のインスタンスとその割合は、総インスタンス数を考慮すると無視できるほど小さい。V6KPの平均実行時間性能はシーン1とほぼ同じだった。

To summarize, the average accuracy of the approach was around 70%. Except for facing about, the other three facing directions performed better with an average accuracy of around 80%. With an average accuracy of 54%, facing about performed the worst. In total, the approach results in good overall accuracy and also efficiently demonstrates our head orientation (V6KP) approach, with a mobile robot using a built-in RGB camera from an egocentric view.

要約すると、このアプローチの平均精度は約70％だった。面している方向を除き、他の3つの向きは平均精度約80％でより良い結果を示した。面している方向の平均精度は54％で最も低かった。全体として、このアプローチは良好な全体精度を示し、自己中心視点のRGBカメラを搭載した移動ロボットを用いた頭の向き(V6KP)推定手法を効率的に実証している。

### 6.2. Detecting Groups

### 6.2. グループの検出

In Scene 1, VAs were placed in the same groups as the people in the coffee dataset (as seen in Figure 17a). The robot was endowed with our DGO and placed in the robot positions to detect groups in the scene. The robot started detecting the groups in the scene for each position and compared them against the concerned ground truth. This process was performed for all the 28 positions of the robot. DGO detects the groups and their members in the scene, as shown in Figure 17.

シーン1では、VAsはコーヒーデータセットの人々と同じグループに配置されていた(図17a参照)。ロボットには我々のDGOを搭載し、ロボットの位置に配置してシーン内のグループを検出した。ロボットは各位置でシーン内のグループを検出し、それらを対応するグラウンドトゥルースと比較した。このプロセスはロボットの28のすべての位置で行われた。DGOはシーン内のグループとそのメンバーを検出し、図17に示す通りである。

![bo_d3ecpr4601uc738ioje0_20_452_1449_1102_387_0.jpg](images/bo_d3ecpr4601uc738ioje0_20_452_1449_1102_387_0.jpg)

Figure 17. Image (a) presents the output image from the robot. The numbers on the VAs in the image represent their tracking ID. Image (b) presents the terminal with results, which present the different groups' information, i.e., the number of groups, the VAs in the group, their spatial and orientational information, and their tracking ID.

図17. 画像(a)はロボットからの出力画像を示す。画像内のVAsの数字は追跡IDを表す。画像(b)は結果を示す端末画面で、異なるグループの情報(グループ数、グループ内のVAs、その空間的および向きの情報、追跡ID)を示している。

In the detection process, DGO considers some parameters: the radius of a person, the radius of the O-space, and the threshold for the overlapping region (Figure 6). Here, the radius of the O-space and the person were considered to be \( {0.6}\mathrm{\;m} \) . The reason being, according to Hall [16] and the information provided in Table 1, the interpersonal distance in social interaction is from 1.2 to \( {3.7}\mathrm{\;m} \) ; if \( {1.2}\mathrm{\;m} \) is taken into consideration, then each person is standing at \( {0.6}\mathrm{\;m} \) from the centre of the O-space. Using this analysis, the radius of a person is fixed and the same goes for O-space; however, while experimenting, the person's radius and O-space radius were slightly varied to observe how this affects the results. The threshold for the overlapping region varied from 0 to 100% of a given transactional segment of a VA to observe the affect on the results. The detected groups were evaluated using the annotated ground truth information gained through perceiving the scene from an egocentric view using the robot's camera for all the 28 positions of the robot.

検出プロセスでは、DGOは以下のパラメータを考慮する:人の半径、O空間の半径、および重複領域の閾値(図6参照)。ここでは、O空間の半径と人の半径は\( {0.6}\mathrm{\;m} \)と考えられた。理由は、Hall [16]および表1の情報によると、社会的交流における人間間距離は1.2から\( {3.7}\mathrm{\;m} \)の範囲であり、\( {1.2}\mathrm{\;m} \)を考慮すると、各人はO空間の中心から\( {0.6}\mathrm{\;m} \)の位置に立っていることになる。この分析を用いて、人の半径とO空間の半径は固定されたが、実験中に人の半径とO空間の半径をわずかに変化させて結果への影響を観察した。重複領域の閾値は0％から100％まで変化させ、結果への影響を観察した。検出されたグループは、ロボットのカメラを用いて自己中心視点からシーンを認識し得たグラウンドトゥルース情報を用いて評価された。

The results, i.e., precision, recall, and F-measure per position, were calculated and averaged for all the positions, whose results are presented in Table 7.

結果は、位置ごとの精度、リコール、F値を計算し、すべての位置の平均値を表7に示す。

The radii of the O-space and person were varied, i.e., increased \( \left( { > {0.6}\mathrm{\;m}}\right) \) and decreased \( \left( { < {0.6}\mathrm{\;m}}\right) \) , to observe the fluctuations of the scores, and we found better precision and recall values with \( {0.7}\mathrm{\;m} \) radius in both the scenes; while detecting the groups, the unrecognized VAs from V6KP were considered. These VAs, when forming groups with other VAs, were not detected by DGO, which affected the results. The precision decreased by approximately 2-3%, and the recall and F-measure decreased by approximately 5-10%. These affected results are presented in Table 7.

O空間と人の半径を変化させ、例えば\( \left( { > {0.6}\mathrm{\;m}}\right) \)を増加させ、\( \left( { < {0.6}\mathrm{\;m}}\right) \)を減少させてスコアの変動を観察したところ、両シーンともに\( {0.7}\mathrm{\;m} \)の半径でより良い精度とリコール値を得た。グループ検出時には、V6KPから未認識のVAsも考慮した。これらのVAsは他のVAsとグループを形成する際にDGOに検出されず、結果に影響を与えた。精度は約2-3％低下し、リコールとF値は約5-10％低下した。これらの影響を受けた結果は表7に示す。

Table 7. Scene 1: precision, recall, and F-measure values for groups detected by robot.

表7. シーン1:ロボットによって検出されたグループの精度、リコール、F値。

<table><tr><td colspan="2">T</td><td>0%</td><td>10%</td><td>20%</td><td>\( \mathbf{{30}\% } \)</td><td>40%</td><td>50%</td><td>60%</td><td>70%</td><td>80%</td><td>90%</td><td>100%</td><td/></tr><tr><td rowspan="3">2/3</td><td>Precision</td><td>0.65</td><td>0.94</td><td>0.94</td><td>0.89</td><td>0.89</td><td>0.85</td><td>0.85</td><td>0.82</td><td>0.82</td><td>0.82</td><td>0.78</td><td/></tr><tr><td>Recall</td><td>0.64</td><td>0.85</td><td>0.85</td><td>0.80</td><td>0.80</td><td>0.76</td><td>0.76</td><td>0.72</td><td>0.70</td><td>0.70</td><td>0.67</td><td/></tr><tr><td>F-measure</td><td>0.65</td><td>0.89</td><td>0.89</td><td>0.84</td><td>0.84</td><td>0.81</td><td>0.81</td><td>0.76</td><td>0.76</td><td>0.76</td><td>0.72</td><td/></tr><tr><td rowspan="4">1</td><td>Precision</td><td>0.44</td><td>0.72</td><td>0.72</td><td>0.69</td><td>0.69</td><td>0.67</td><td>0.63</td><td>0.60</td><td>0.60</td><td>0.58</td><td>0.58</td><td/></tr><tr><td>Recall</td><td>0.41</td><td>0.64</td><td>0.64</td><td>0.61</td><td>0.61</td><td>0.60</td><td>0.56</td><td>0.52</td><td>0.50</td><td>0.49</td><td>0.49</td><td/></tr><tr><td>F-measure</td><td>0.42</td><td>0.68</td><td>0.68</td><td>0.64</td><td>0.64</td><td>0.63</td><td>0.60</td><td>0.55</td><td>0.55</td><td>0.53</td><td>0.53</td><td/></tr><tr><td/><td/><td/><td/><td/><td/><td/><td/><td/><td/><td/><td/><td/></tr></table>

<table><tbody><tr><td colspan="2">T</td><td>0%</td><td>10%</td><td>20%</td><td>\( \mathbf{{30}\% } \)</td><td>40%</td><td>50%</td><td>60%</td><td>70%</td><td>80%</td><td>90%</td><td>100%</td><td></td></tr><tr><td rowspan="3">2/3</td><td>精度</td><td>0.65</td><td>0.94</td><td>0.94</td><td>0.89</td><td>0.89</td><td>0.85</td><td>0.85</td><td>0.82</td><td>0.82</td><td>0.82</td><td>0.78</td><td></td></tr><tr><td>再現率</td><td>0.64</td><td>0.85</td><td>0.85</td><td>0.80</td><td>0.80</td><td>0.76</td><td>0.76</td><td>0.72</td><td>0.70</td><td>0.70</td><td>0.67</td><td></td></tr><tr><td>F値</td><td>0.65</td><td>0.89</td><td>0.89</td><td>0.84</td><td>0.84</td><td>0.81</td><td>0.81</td><td>0.76</td><td>0.76</td><td>0.76</td><td>0.72</td><td></td></tr><tr><td rowspan="4">1</td><td>精度</td><td>0.44</td><td>0.72</td><td>0.72</td><td>0.69</td><td>0.69</td><td>0.67</td><td>0.63</td><td>0.60</td><td>0.60</td><td>0.58</td><td>0.58</td><td></td></tr><tr><td>再現率</td><td>0.41</td><td>0.64</td><td>0.64</td><td>0.61</td><td>0.61</td><td>0.60</td><td>0.56</td><td>0.52</td><td>0.50</td><td>0.49</td><td>0.49</td><td></td></tr><tr><td>F値</td><td>0.42</td><td>0.68</td><td>0.68</td><td>0.64</td><td>0.64</td><td>0.63</td><td>0.60</td><td>0.55</td><td>0.55</td><td>0.53</td><td>0.53</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr></tbody></table>

'T' stands for the tolerance threshold from Section 5.2.

'T'はセクション5.2の許容閾値を表します。

From Table 7, the performance of DGO was better, with overlapping region percentage in between 10 and \( {20}\% \) for both the tolerance thresholds, i.e., \( \mathrm{T} = 2/3 \) and 1 . As the overlapping region increased from 10% to 100%, the precision, recall, and F-measure values decreased. Here, the precision reflects the ability of DGO to identify only the relevant groups; between 10 and 20%, DGO is correct 94% of the time. Precision decreasing from 30% means that our model was returning false positives incrementally. Here, the recall reflects the ability of DGO to find all the relevant groups within Scene 1. The recall is also high between 10 and \( {20}\%  - \mathrm{{DGO}} \) is correct \( {85}\% \) of the time. The decreasing recall means that our model was returning false negatives incrementally. Here, the F-measure provides DGO's accuracy in Scene 1, which was 89% between 10 and 20%. The presented values for tolerance threshold were \( \mathrm{T} = 2/3 \) (presented in Section 5.2). For \( \mathrm{T} = 1 \) , the precision was \( {72}\% \) , recall was \( {64}\% \) , and F-measure was \( {68}\% \) between 10 and \( {20}\% \) . The groups formed with \( 0\% \) overlapping region represent the VAs clustered into groups based on spatial information. After the O-spaces were initialized in the scene, VAs were assigned to their nearest O-space, resulting in groups. These groups were formed without considering the transactional segment of VAs. The groups which formed with 100% overlapping region represent the exact matching of our initialized O-spaces with the original O-spaces of the groups. The latter percentage was higher than the prior one.

表7から、DGOの性能はより良く、重なり領域の割合は10％から\( {20}\% \)の間であり、両方の許容閾値、すなわち\( \mathrm{T} = 2/3 \)と1においても同様です。重なり領域が10％から100％に増加するにつれて、精度、リコール、およびF値は低下しました。ここで、精度はDGOが関連するグループのみを識別する能力を反映しています。10％から20％の間では、DGOは94％の確率で正しいです。30％から精度が低下することは、モデルが誤検出を段階的に返していたことを意味します。リコールは、DGOがシーン1内のすべての関連グループを見つける能力を反映しています。リコールも10％から\( {20}\%  - \mathrm{{DGO}} \)の間で高く、\( {85}\% \)の確率で正しいです。リコールの低下は、モデルが誤陰性を段階的に返していたことを示しています。ここで、F値はシーン1におけるDGOの精度を示し、10％から20％の間で89％でした。許容閾値の値は\( \mathrm{T} = 2/3 \)(セクション5.2に記載)です。\( \mathrm{T} = 1 \)の場合、精度は\( {72}\% \)、リコールは\( {64}\% \)、F値は\( {68}\% \)であり、10％から\( {20}\% \)の間で示されました。\( 0\% \)の重なり領域で形成されたグループは、空間情報に基づいてクラスタリングされたVAsを表します。シーン内でOスペースが初期化された後、VAsは最も近いOスペースに割り当てられ、グループが形成されました。これらのグループは、VAsのトランザクションセグメントを考慮せずに形成されました。100％の重なり領域で形成されたグループは、初期化されたOスペースと元のグループのOスペースとの正確な一致を示します。後者の割合は前者より高かったです。

Regarding the runtime performance of DGO, the average time taken for the robot to detect groups in the scene for 28 positions was \( {3.25}\mathrm{\;s} \) . The time taken to compute the 2D pose was \( {2.97}\mathrm{\;s} \) , removing this would result in \( {0.28}\mathrm{\;s} \) -the time taken by DGO from extraction of the features to the detection of groups in the scene.

DGOの実行時間性能に関して、ロボットがシーン内でグループを検出するのに平均して\( {3.25}\mathrm{\;s} \)かかりました。2Dポーズの計算にかかる時間は\( {2.97}\mathrm{\;s} \)であり、これを除くと、特徴抽出からシーン内のグループ検出までのDGOの所要時間は\( {0.28}\mathrm{\;s} \)となります。

In Scene 2, VAs were positioned in same groups as the VAs in [76]. The robot was placed in the scene for each position and compared the detected groups against the concerned ground truth. This process was performed for all the 247 positions of the robot. The results, i.e., precision, recall, and F-measure per position, were calculated and averaged for all the positions, whose results are presented in Table 8. Similar to Scene 1, the unrecognized VAs were considered in this scene too, and the results-i.e., the precision decreased

シーン2では、VAsは[76]のVAsと同じグループに配置されました。ロボットは各位置でシーンに配置され、検出されたグループを該当するグラウンドトゥルースと比較しました。このプロセスはロボットの247のすべての位置で行われ、その結果、位置ごとの精度、リコール、F値が計算され、平均化されており、その結果は表8に示されています。シーン1と同様に、認識されなかったVAsもこのシーンで考慮され、結果として精度は約1-2％低下し、リコールとF値は約5％低下しました。

by approximately 1-2%, and recall and F-measure decreased by approximately 5%—are presented in Table 8.

これらの結果は表8に示されています。

Table 8. Scene 2: Precision, recall, and F-measure values for groups detected by robot.

表8. シーン2:ロボットによって検出されたグループの精度、リコール、F値。

<table><tr><td colspan="2">T</td><td>0%</td><td>10%</td><td>20%</td><td>\( \mathbf{{30}\% } \)</td><td>40%</td><td>\( \mathbf{{50}\% } \)</td><td>60%</td><td>70%</td><td>80%</td><td>90%</td><td>100%</td><td/></tr><tr><td rowspan="3">2/3</td><td>Precision</td><td>0.69</td><td>0.80</td><td>0.80</td><td>0.79</td><td>0.78</td><td>0.78</td><td>0.77</td><td>0.76</td><td>0.76</td><td>0.76</td><td>0.72</td><td/></tr><tr><td>Recall</td><td>0.70</td><td>0.69</td><td>0.69</td><td>0.67</td><td>0.67</td><td>0.66</td><td>0.65</td><td>0.63</td><td>0.63</td><td>0.60</td><td>0.58</td><td/></tr><tr><td>F-measure</td><td>0.70</td><td>0.75</td><td>0.74</td><td>0.73</td><td>0.72</td><td>0.71</td><td>0.71</td><td>0.69</td><td>0.69</td><td>0.68</td><td>0.64</td><td/></tr><tr><td rowspan="3">1</td><td>Precision</td><td>0.33</td><td>0.66</td><td>0.66</td><td>0.65</td><td>0.65</td><td>0.63</td><td>0.63</td><td>0.61</td><td>0.61</td><td>0.60</td><td>0.57</td><td/></tr><tr><td>Recall</td><td>0.34</td><td>0.57</td><td>0.56</td><td>0.55</td><td>0.55</td><td>0.53</td><td>0.52</td><td>0.50</td><td>0.50</td><td>0.48</td><td>0.45</td><td/></tr><tr><td>F-measure</td><td>0.33</td><td>0.61</td><td>0.60</td><td>0.59</td><td>0.59</td><td>0.58</td><td>0.57</td><td>0.55</td><td>0.55</td><td>0.53</td><td>0.50</td><td/></tr></table>

<table><tbody><tr><td colspan="2">T</td><td>0%</td><td>10%</td><td>20%</td><td>\( \mathbf{{30}\% } \)</td><td>40%</td><td>\( \mathbf{{50}\% } \)</td><td>60%</td><td>70%</td><td>80%</td><td>90%</td><td>100%</td><td></td></tr><tr><td rowspan="3">2/3</td><td>精度</td><td>0.69</td><td>0.80</td><td>0.80</td><td>0.79</td><td>0.78</td><td>0.78</td><td>0.77</td><td>0.76</td><td>0.76</td><td>0.76</td><td>0.72</td><td></td></tr><tr><td>再現率</td><td>0.70</td><td>0.69</td><td>0.69</td><td>0.67</td><td>0.67</td><td>0.66</td><td>0.65</td><td>0.63</td><td>0.63</td><td>0.60</td><td>0.58</td><td></td></tr><tr><td>F値</td><td>0.70</td><td>0.75</td><td>0.74</td><td>0.73</td><td>0.72</td><td>0.71</td><td>0.71</td><td>0.69</td><td>0.69</td><td>0.68</td><td>0.64</td><td></td></tr><tr><td rowspan="3">1</td><td>精度</td><td>0.33</td><td>0.66</td><td>0.66</td><td>0.65</td><td>0.65</td><td>0.63</td><td>0.63</td><td>0.61</td><td>0.61</td><td>0.60</td><td>0.57</td><td></td></tr><tr><td>再現率</td><td>0.34</td><td>0.57</td><td>0.56</td><td>0.55</td><td>0.55</td><td>0.53</td><td>0.52</td><td>0.50</td><td>0.50</td><td>0.48</td><td>0.45</td><td></td></tr><tr><td>F値</td><td>0.33</td><td>0.61</td><td>0.60</td><td>0.59</td><td>0.59</td><td>0.58</td><td>0.57</td><td>0.55</td><td>0.55</td><td>0.53</td><td>0.50</td><td></td></tr></tbody></table>

'T' stands for tolerance threshold from Section 5.2.

'T'はセクション5.2の許容閾値を表します。

From Table 8, the performance of DGO was better with overlapping region percentage between 10 and \( {20}\% \) for both \( \mathrm{T} = 2/3 \) and 1 . As the overlapping region increased from 10% to 100%, the precision, recall, and F-measure values decreased. Similar to Scene 1, the precision, recall, and F-measure reflect the ability of the DGO, and the values were higher between 10 and \( {20}\% \) for Scene 2. The precision was \( {80}\% \) , the recall was \( {69}\% \) , and the F-measure accuracy in Scene 2 was \( {75}\% \) for the tolerance threshold \( \mathrm{T} = 2/3 \) (presented in Section 5.2). For \( \mathrm{T} = 1 \) , the precision was \( {66}\% \) , the recall was \( {57}\% \) , and the \( \mathrm{F} \) -measure was 61% for 10% overlapping region.Similar to Scene 1, the groups formed with a 100% overlapping region had a higher percentage than the groups formed with a 0% overlapping region. The average runtime performance of DGO was similar to Scene 1.

表8から、DGOの性能は、重なり領域の割合が10％から\( {20}\% \)の範囲で、\( \mathrm{T} = 2/3 \)および1においても良好であった。重なり領域が10％から100％に増加するにつれて、精度、リコール、F値は低下した。シーン1と同様に、精度、リコール、F値はDGOの能力を反映しており、シーン2では10％から\( {20}\% \)の範囲でより高い値を示した。シーン2のとき、許容閾値\( \mathrm{T} = 2/3 \)において、精度は\( {80}\% \)、リコールは\( {69}\% \)、F値の正確性は\( {75}\% \)であった(セクション5.2に示す)。\( \mathrm{T} = 1 \)の場合、精度は\( {66}\% \)、リコールは\( {57}\% \)、F値は10％の重なり領域で61％であった。シーン1と同様に、100％の重なり領域で形成されたグループは、0％の重なり領域で形成されたグループよりも高い割合を示した。DGOの平均実行時間性能もシーン1と類似していた。

To summarize, the precision, recall, and F-measure values were higher for our DGO between 10 and \( {20}\% \) for both the tolerance threshold values of \( \mathrm{T} = 1 \) and \( 2/3 \) . With precision around \( {90}\% \) , recall around \( {80}\% \) , and \( \mathrm{F} \) -measure around80for \( \mathrm{T} = 2/3 \) and for \( \mathrm{T} = 1 \) , these values decreased around \( {20}\% \) , respectively. Our approach also works efficiently in real time, with a mobile robot using a built-in RGB camera from an egocentric view.

要約すると、私たちのDGOの精度、リコール、F値は、\( \mathrm{T} = 1 \)および\( 2/3 \)の両方の許容閾値に対して、10％から\( {20}\% \)の範囲でより高かった。精度は約\( {90}\% \)、リコールは約\( {80}\% \)、F値は約80であり、\( \mathrm{T} = 2/3 \)と\( \mathrm{T} = 1 \)ではこれらの値はそれぞれ\( {20}\% \)程度低下した。我々のアプローチは、自己中心的な視点からのRGBカメラを搭載したモバイルロボットを用いてリアルタイムで効率的に動作する。

These detected groups are further used in our framework to recognise the patterns of the groups by estimating F-formations.

これらの検出されたグループは、我々のフレームワーク内でF形成を推定することにより、グループのパターン認識にさらに利用される。

### 6.3. Estimating F-Formations

### 6.3. F形成の推定

Regarding estimating F-formations, firstly, Scene 1 does not contain a high enough number of groups or variety of F-formations. For this reason, Scene 2 was built with a number and variety of formations for the evaluation process. Secondly, while using a classifier in a dataset of \( {100}\% ,{80}\% \) data is used for training and the remaining \( {20}\% \) of data is used for testing. In this aspect, from Scene 1, if the 28 positions (which consists of 48 groups) are considered as a dataset, then the 80% data accounts for 22 positions (39 groups) for training and 6 positions (9 groups) for testing, which are very short training and testing data. For both reasons, we skipped training and testing of the classifier, using Scene 1.

F形成の推定に関して、まずシーン1には十分な数のグループや多様なF形成が含まれていない。そのため、評価プロセスのためにシーン2は形成の数と多様性を持つように構築された。次に、\( {100}\% ,{80}\% \)のデータセットに分類器を使用し、残りの\( {20}\% \)のデータをテストに用いる。この点において、シーン1から、48のグループからなる28の位置をデータセットと見なすと、80％のデータは22の位置(39のグループ)を訓練に、6の位置(9のグループ)をテストに使用した。これは非常に短い訓練とテストのデータである。これらの理由から、シーン1を用いた分類器の訓練とテストは省略した。

Next, Scene 2 consists of a good number of groups and variety of F-formations (seen in Figure 18). From Scene 2, the 247 robot positions resulted in a number of groups and a variety of formations, i.e., 56 vis-a-vis, 87 side-by-side, 136 L-shape, 63 circular, 28 semi-circular, and 20 triangular formations, which were used with the classifier. While training the classifier; instead of \( {80}\% \) of the number of positions, we considered \( {80}\% \) of each formation and combined them to train a classifier. For example, out of 56 vis-a-vis formations, 80% data, which is 44 formations, were used for training and 20% data, which is 12 formations, were used for testing. In this way, the training data of the first four formations (vis-a-vis, side-by-side, L-shape, and circular) were used to train the classifier and were tested on the remaining data of these formations. As the last two formations, i.e., semi-circular and triangular formations, were very short data. For this reason, both these formations were not included in the training or the testing part. These formations are very rarely observed in group interactions, which is the reason an algorithm 2 is presented to estimate these formations.

次に、シーン2は、多数のグループと多様なF形成(図18参照)を含む。シーン2から得られた247のロボット位置は、56のビザビザ、87の並列、136のL字型、63の円形、28の半円形、20の三角形の形成をもたらし、これらは分類器とともに使用された。分類器の訓練においては、位置数の代わりに各形成の数を考慮し、それらを組み合わせて訓練した。例えば、56のビザビザ形成のうち、80％のデータ(44形成)が訓練に、20％のデータ(12形成)がテストに使用された。この方法で、最初の4つの形成(ビザビザ、並列、L字型、円形)の訓練データは、これらの形成の残りのデータでテストされた。最後の2つの形成、すなわち半円形と三角形は非常に短いデータであったため、訓練やテストには含まれなかった。これらの形成はグループの相互作用では非常に稀に観察されるため、これらの形成を推定するためのアルゴリズム2が提案されている。

![bo_d3ecpr4601uc738ioje0_23_452_253_1089_705_0.jpg](images/bo_d3ecpr4601uc738ioje0_23_452_253_1089_705_0.jpg)

Figure 18. Scene 2 consists of a number and variety of F-formations. The 13 formations are numbered and listed as follows: 1 and 8 are vis-a-vis formations; 2 and 13 are side-by-side formations; 3, 6, and 9 are L-shape formations; 4, 5, 10, and 11 are circular formations; 12 is semi-circular formation; 7 is triangular formation.

図18.シーン2は、さまざまなF形成の数と種類で構成されています。13の形成は番号が付けられ、次のようにリストされています:1と8は対面形成、2と13は並列形成、3、6、9はL字型形成、4、5、10、11は円形形成、12は半円形形成、7は三角形形成です。

To evaluate our EFCR approach, 80% of data was used to train and 20% was used to test. The choice of training and testing data is very important in obtaining better performance. Due to this, we did not want to choose the data or put our choice as an option to avoid the risk of overfitting. So, we decided to use 0-80% of data as 80% training and 80-100% of data as 20% testing data. The unrecognized VAs had incomplete data and are negligible (i.e., 5%), which is the reason that we excluded this data while training and testing the classifier. For training the classifier, the spatial information(x, y)of the VAs, along with the ground truth information of head orientation, the groups, and the F-formations, was used for training-i.e., if two VAs were in the same group in the ground truth information of groups, then their information \( \left( {{x}_{1},{y}_{1},{\theta }_{1},{x}_{2},{y}_{2},{\theta }_{2}}\right) \) was used as an input feature vector, \( X \) , and their F-formation was used as output label, \( y \) ..

我々のEFCRアプローチを評価するために、データの80％を訓練に、20％をテストに使用しました。訓練データとテストデータの選択は、より良い性能を得るために非常に重要です。そのため、過剰適合のリスクを避けるために、データを選択したり選択肢として設定したりしたくありませんでした。したがって、データの0-80％を80％の訓練データ、80-100％を20％のテストデータとして使用することに決めました。認識されていないVAsは不完全なデータを持ち、無視できる程度(つまり5％)であるため、訓練とテストの際にこのデータを除外しました。分類器の訓練には、VAsの空間情報(x, y)と、頭の向き、グループ、F形成の真の情報を使用しました。つまり、グループの真の情報で2つのVAsが同じグループに属している場合、その情報\( \left( {{x}_{1},{y}_{1},{\theta }_{1},{x}_{2},{y}_{2},{\theta }_{2}}\right) \)を入力特徴ベクトルとして使用し、\( X \)、F形成を出力ラベルとして使用しました。

Regarding the classifier, the selected training data was then subjected to a polynomial SVM classifier with a degree of 2 and then evaluated using test data. This provided very good results, which are presented as confusion matrix in Table 9.

分類器については、選択された訓練データを2次の多項式SVM分類器にかけ、その後テストデータを用いて評価しました。これにより非常に良い結果が得られ、表9に混同行列として示されています。

Table 9. Estimating F-formations in Scene 2: confusion matrix and accuracy.

表9.シーン2におけるF形成の推定:混同行列と精度。

<table><tr><td>F-Formations</td><td>Vis-a-Vis</td><td>Side-by-Side</td><td>L-Shape</td><td>Circular</td><td>Accuracy</td><td>Total</td><td/></tr><tr><td>Vis-a-Vis</td><td>12</td><td>0</td><td>0</td><td>0</td><td>100%</td><td>12</td><td/></tr><tr><td>Side-by-Side</td><td>0</td><td>17</td><td>1</td><td>0</td><td>94%</td><td>18</td><td/></tr><tr><td>L-shape</td><td>0</td><td>1</td><td>27</td><td>0</td><td>96%</td><td>28</td><td/></tr><tr><td>Circular</td><td>0</td><td>0</td><td>0</td><td>13</td><td>100%</td><td>13</td><td/></tr></table>

<table><tbody><tr><td>F-フォーメーション</td><td>ビザ・ビズ</td><td>並列</td><td>L字型</td><td>円形</td><td>正確さ</td><td>合計</td><td></td></tr><tr><td>ビザ・ビズ</td><td>12</td><td>0</td><td>0</td><td>0</td><td>100%</td><td>12</td><td></td></tr><tr><td>並列</td><td>0</td><td>17</td><td>1</td><td>0</td><td>94%</td><td>18</td><td></td></tr><tr><td>L字型</td><td>0</td><td>1</td><td>27</td><td>0</td><td>96%</td><td>28</td><td></td></tr><tr><td>円形</td><td>0</td><td>0</td><td>0</td><td>13</td><td>100%</td><td>13</td><td></td></tr></tbody></table>

From Table 9, the overall accuracy of the approach was 97%, which shows that our approach worked very well and resulted in high accuracy. The vis-a-vis and circular formations had very high accuracy, i.e., 100%. The other formations also performed very well. The time taken to estimate the F-formations for the test data was \( {0.02}\mathrm{\;s} \) , which suggests that our approach works in real time.

表9から、全体の精度は97％であり、我々のアプローチが非常に効果的で高い精度を達成したことを示している。ビザビと円形の配置は非常に高い精度、すなわち100％を示した。他の配置も非常に良好に機能した。テストデータのF-formationの推定にかかった時間は\( {0.02}\mathrm{\;s} \)であり、我々のアプローチがリアルタイムで動作することを示唆している。

For robust evaluation, the trained classifier was tested with Scene 1 for all the 28 robot positions. The results are detailed as a confusion matrix in Table 10.

堅牢な評価のために、訓練済みの分類器をScene 1の28のロボット位置すべてでテストした。結果は表10の混同行列として詳述されている。

Table 10. Estimating F-formations in Scene 1: confusion matrix and accuracy.

表10. Scene 1におけるF-formationの推定:混同行列と精度。

<table><tr><td>F-Formations</td><td>Vis-a-Vis</td><td>Side-by-Side</td><td>L-Shape</td><td>Circular</td><td>Accuracy</td><td>Total</td></tr><tr><td>Vis-a-Vis</td><td>9</td><td>1</td><td>1</td><td>0</td><td>81%</td><td>11</td></tr><tr><td>Side-by-Side</td><td>0</td><td>0</td><td>0</td><td>0</td><td>-%</td><td>-</td></tr><tr><td>L-shape</td><td>6</td><td>0</td><td>11</td><td>0</td><td>64%</td><td>17</td></tr><tr><td>Circular</td><td>0</td><td>0</td><td>0</td><td>20</td><td>100%</td><td>20</td></tr></table>

<table><tbody><tr><td>F-フォーメーション</td><td>ビザ・ビズ</td><td>サイド・バイ・サイド</td><td>L字型</td><td>円形</td><td>正確さ</td><td>合計</td></tr><tr><td>ビザ・ビズ</td><td>9</td><td>1</td><td>1</td><td>0</td><td>81%</td><td>11</td></tr><tr><td>サイド・バイ・サイド</td><td>0</td><td>0</td><td>0</td><td>0</td><td>-%</td><td>-</td></tr><tr><td>L字型</td><td>6</td><td>0</td><td>11</td><td>0</td><td>64%</td><td>17</td></tr><tr><td>円形</td><td>0</td><td>0</td><td>0</td><td>20</td><td>100%</td><td>20</td></tr></tbody></table>

From Table 10, the results are very encouraging. The vis-a-vis formation performed well with 81% accuracy. There were no side-by-side formations in Scene 1. The L-shape had moderate accuracy for reasons which are currently unclear. The circular formation performed exceptionally well, with 100% accuracy. The overall accuracy of the approach was 83%, which shows that our approach worked with high accuracy in a simulation scene that was a replica of an actual human social scenario of a coffee break from an egocentric view.

表10から、結果は非常に有望です。ビザビ形成は81％の精度で良好に機能しました。シーン1には並列形成はありませんでした。L字型は、現在不明な理由で中程度の精度を示しました。円形形成は非常に良好で、100％の精度を達成しました。全体の精度は83％であり、私たちのアプローチがエゴセントリックな視点から見た実際の人間の社交シナリオのレプリカであるシミュレーションシーンにおいて高い精度で機能したことを示しています。

To this end, the robot predicts the F-formations, which could be used with [27] to find the optimal empty spot in the group to join the ongoing social interactions.

この目的のために、ロボットはF形成を予測し、[27]と組み合わせて、グループ内の最適な空きスポットを見つけて進行中の社会的交流に参加できるようにします。

For evaluating our EFLG approach, the semi-circular and triangular formations from Scene 2 were considered. These formations were fed to EFLG, which produced the results that are presented as a confusion matrix and accuracy in Table 11.

私たちのEFLGアプローチを評価するために、シーン2の半円形および三角形の形成を考慮しました。これらの形成はEFLGに入力され、結果は混同行列と精度として表11に示されています。

Table 11. Estimating constrained F-formations: confusion matrix and accuracy.

表11. 制約されたF形成の推定:混同行列と精度。

<table><tr><td>F-Formations</td><td>Triangular</td><td>Semi-Circular</td><td>Circular</td><td>Unrecognized</td><td>Accuracy</td><td>Total</td><td/></tr><tr><td>Triangle</td><td>9</td><td>0</td><td>9</td><td>2</td><td>45%</td><td>20</td><td/></tr><tr><td>Semi-Circular</td><td>0</td><td>28</td><td>0</td><td>0</td><td>100%</td><td>28</td><td/></tr></table>

<table><tbody><tr><td>F-形成</td><td>三角形</td><td>半円形</td><td>円形</td><td>未認識</td><td>正確さ</td><td>合計</td><td></td></tr><tr><td>三角形</td><td>9</td><td>0</td><td>9</td><td>2</td><td>45%</td><td>20</td><td></td></tr><tr><td>半円形</td><td>0</td><td>28</td><td>0</td><td>0</td><td>100%</td><td>28</td><td></td></tr></tbody></table>

From Table 11, the semi-circular formations were correctly estimated with 100% accuracy, but the triangular formations did not perform well. The triangular formations were wrongly estimated as circular formations. One reason for this is that, when observed from different perspectives, these formations appear as if the three VAs are standing in circular formations due to the formations appearance being closely related. The overall accuracy of the approach was \( {72}\% \) , which shows that our approach worked well with the said formations overall. Still, for more robust approaches and evaluation processes, there is a need for a real-time human scenario dataset from an egocentric view using a robot.

表11から、半円形の配置は100％の精度で正しく推定されましたが、三角形の配置はあまり良い結果を示しませんでした。三角形の配置は円形の配置として誤って推定されました。その理由の一つは、異なる視点から観察した場合、これらの配置が三つのVAが円形に立っているように見えるためであり、配置の外観が密接に関連していることによります。全体的な精度は\( {72}\% \)であり、我々のアプローチがこれらの配置に対して全体的に良好に機能したことを示しています。ただし、より堅牢なアプローチと評価プロセスのためには、ロボットを用いた自己中心的視点からのリアルタイムの人間シナリオデータセットが必要です。

To summarize, EFCR worked efficiently, with an average overall accuracy of 90%. The individual formations accuracies were also very good; EFCR was tested with Scene 1 for all the robot positions, which resulted in an overall accuracy of around 80%, with a good individual formations accuracies. At the same time, EFLG also worked well, with an overall accuracy of around 70%, and the individual formations accuracies are encouraging.

要約すると、EFCRは効率的に機能し、平均全体精度は90％でした。個々の配置の精度も非常に良好であり、EFCRはシーン1のすべてのロボット位置でテストされ、全体の精度は約80％で、個々の配置の精度も良好でした。同時に、EFLGも良好に機能し、全体の精度は約70％であり、個々の配置の精度も有望です。

## 7. Limitations and Future Works

## 7. 制限事項と今後の課題

There are some technical limitations in our framework, which are presented in this section along with the future research directions.

私たちのフレームワークにはいくつかの技術的制限があり、本節ではそれらと今後の研究方向について述べます。

First, our framework works with single images from the robot and does not track persons and their movements. This would result in wrong prediction during movement. For example, when two persons are interacting in an L-shape formation, and one person is frequently turning their body towards the other person, this would result in a wrong prediction as a vis-a-vis formation. So, future research could be directed towards solving this issue by adding short temporal duration, which could keep track of persons in the group or scene. Second, the methods in our framework use hand-engineered features, but there is a preference for data-driven approaches. Third, our framework constitutes a pipeline of approaches for different tasks. This means a failure or malfunction in one of the approaches leads to a failure or malfunction in the complete framework. To address the second and third limitations, future research could be directed towards training deep learning approaches, which would result in an end-to-end framework and could improve accuracy. This process may also lead to new features to detect groups and estimate F-formations in social interactions. Regarding the experimental scenes, using a simulation scene could have impacted the results obtained in this paper. If the experiments were conducted in a real human environment, a change might be noticed in our framework's performance, which is indeed worth investigating in future studies. For this, future research could be directed towards building large coffee break datasets from an egocentric view, with a number of persons interacting in multiple groups of varying group sizes, in all the different F-formations. Such datasets could also be useful in evaluating frameworks such as ours, in training deep learning approaches, and in studying socially acceptable behaviour, path, and placement for the robot to join the ongoing social group interactions. Finally, this paper presents seven different formations, and proposes approaches for six different formations, except the rectangle formation, because this formation occurs around a table, i.e., a dinner table or in conference room.

まず、私たちのフレームワークはロボットからの単一画像で動作し、人物やその動きを追跡しません。これにより、動いている間に誤った予測が生じる可能性があります。例えば、L字型の配置で二人の人物が交流している場合、一方の人物が頻繁にもう一方に向かって体を回すと、誤って対面配置と予測されることがあります。したがって、今後の研究では、短時間の時間的持続を追加し、グループやシーン内の人物を追跡できるようにすることが検討されます。第二に、私たちのフレームワークの手法は手作業で設計された特徴を使用していますが、データ駆動型のアプローチが好まれます。第三に、私たちのフレームワークは異なるタスクのためのパイプラインで構成されており、一つのアプローチの失敗や誤動作は全体のフレームワークの失敗や誤動作につながります。第二および第三の制限に対処するために、今後の研究では深層学習アプローチの訓練に向けた取り組みが検討され、エンドツーエンドのフレームワークの構築と精度向上が期待されます。この過程で、新たな特徴が導入され、社会的相互作用におけるグループの検出やF-formationの推定に役立つ可能性があります。実験シーンについては、シミュレーションシーンの使用が本論文の結果に影響を与えた可能性があります。実際の人間環境で実験を行えば、我々のフレームワークの性能に変化が見られるかもしれず、これは今後の研究において調査すべき重要な課題です。そのため、今後の研究では、多人数が複数のグループで交流し、さまざまなF-formationを持つ自己中心的視点からの大規模なコーヒーブレイクデータセットの構築を目指します。このようなデータセットは、我々のフレームワークの評価や深層学習アプローチの訓練、社会的に受け入れられる行動や経路、ロボットが参加すべき社会的グループ交流の研究にも有用です。最後に、本論文では7つの異なる配置を提示し、そのうち6つの配置に対するアプローチを提案しています。ただし、長方形配置については除きます。これは、この配置がテーブル(夕食用テーブルや会議室のテーブル)を囲む形で行われるためです。

## 8. Conclusions

## 8. 結論

In this paper, we proposed a framework, AGIR, which incorporates different approaches: computing head orientation of people in the scene, detecting groups, and estimating F-formations. For head orientation, V6KP considers the visibility of six key points and models into four distinct classes, i.e., facing directions. For detecting groups, we proposed DGO, which initializes O-spaces, models transactional segments for people, and then optimizes the O-spaces, which results in estimating groups and their members. For estimating F-formations, we proposed two approaches-EFCR and EFLG. In EFCR, we used a polynomial SVM classifier, and in EFLG, we proposed an algorithm for larger groups. For evaluation purposes, two simulation scenes were built, one based on a replica of the so-called coffee dataset and the second from our previous work. Scene 1 was built with 20 VAs, interacting in 7 different groups of varying sizes and 3 different formations. Scene 2 was built with 36 VAs positioned in 13 different groups of varying sizes and 6 different formations. A virtual Pepper robot was endowed with AGIR and placed in both the scenes in randomly generated positions to evaluate the presented approaches. The obtained results for our different approaches present significant performance with high accuracies, and also demonstrate that AGIR works well when using a robot from an egocentric view in a real-time simulation.

本論文では、シーン内の人物の頭の向きを推定し、グループを検出し、F-formationを推定するさまざまなアプローチを組み込んだフレームワークであるAGIRを提案しました。頭の向きについては、V6KPは6つの重要点の可視性を考慮し、4つの異なるクラス(向き)にモデル化します。グループ検出には、Oスペースを初期化し、人物のトランザクショナルセグメントをモデル化し、その後Oスペースを最適化するDGOを提案し、これによりグループとそのメンバーを推定します。F-formationの推定には、EFCRとEFLGの二つのアプローチを提案しました。EFCRでは多項式SVM分類器を使用し、EFLGでは大規模グループ向けのアルゴリズムを提案しました。評価のために、二つのシミュレーションシーンを構築しました。一つはいわゆるコーヒーデータセットのレプリカに基づき、もう一つは我々の以前の研究に基づいています。シーン1は20のVAを用いて、7つの異なるグループと3つの異なる配置で交流させて構築しました。シーン2は36のVAを用いて、13の異なるグループと6つの異なる配置で構築しました。仮想のPepperロボットにAGIRを搭載し、両シーンにランダムに配置して提案手法を評価しました。得られた結果は、我々のさまざまなアプローチが高い精度で有意な性能を示し、また、リアルタイムシミュレーションにおいて自己中心的視点からロボットを使用した場合にAGIRが良好に機能することを示しています。

Author Contributions: Conceptualization, S.K.P.; data curation, S.K.P.; formal analysis, S.K.P.; investigation, S.K.P.; methodology, S.K.P.; resources, S.K.P.; software, S.K.P.; supervision, A.K. and A.L.; validation, S.K.P.; visualization, S.K.P.; writing-original draft preparation, S.K.P.; writing-review and editing, A.K. and A.L. All authors have read and agreed to the published version of the manuscript.

著者の貢献:概念化、S.K.P.；データキュレーション、S.K.P.；正式分析、S.K.P.；調査、S.K.P.；方法論、S.K.P.；リソース、S.K.P.；ソフトウェア、S.K.P.；監督、A.K.とA.L.；検証、S.K.P.；可視化、S.K.P.；原稿執筆(草稿作成)、S.K.P.；レビューと編集、A.K.とA.L.。全著者は原稿の公開版を読了し、同意しています。

Funding: Örebro University is funding this research through a strategic initiative of Successful Ageing Programme. The statements made herein are solely the responsibility of the authors.

資金提供:オレブロ大学は、成功高齢化プログラムの戦略的イニシアチブを通じて本研究に資金を提供しています。ここに記載された声明は、著者のみの責任です。

Institutional Review Board Statement: Not applicable.

倫理審査委員会の声明:該当なし。

Informed Consent Statement: Informed consent was obtained from all subjects involved in this study.

インフォームドコンセントの声明:本研究に参加したすべての被験者からインフォームドコンセントを取得しています。

Data Availability Statement: The data generated during and/or analyzed during the current study are not publicly available due to its large size and we could not commit to public repository. However, the data may be made available from the corresponding author upon reasonable request.

データ利用可能性の声明:本研究中に生成または分析されたデータは、その大きさのために公開されておらず、公開リポジトリにコミットできません。ただし、合理的なリクエストに応じて、対応著者から提供される場合があります。

Conflicts of Interest: The authors declare no conflict of interest. References

利益相反:著者は利益相反を宣言しません。参考文献

1. Taylor, A.; Chan, D.M.; Riek, L.D.R. Robot-Centric Perception of Human Groups. ACM Trans. Hum.-Robot. Interact. 2020, 9, 1-21. [CrossRef]

1. Taylor, A.; Chan, D.M.; Riek, L.D.R. 人間集団のロボット中心の認識。ACM Trans. Hum.-Robot. Interact. 2020, 9, 1-21. [CrossRef]

2. Vázquez, M. Reasoning about Spatial Patterns of Human Behavior during Group Conversations with Robots. Ph.D. Thesis, Carnegie Mellon University, Pittsburgh, PA, USA, 2017.

2. Vázquez, M. ロボットとのグループ会話中の人間の行動空間パターンに関する推論。カーネギーメロン大学博士論文、ピッツバーグ、PA、米国、2017年。

3. Satake, S.; Kanda, T.; Glas, D.F.; Imai, M.; Ishiguro, H.; Hagita, N. How to approach humans? Strategies for social robots to initiate interaction. In Proceedings of the 4th ACM/IEEE International Conference on Human Robot Interaction, San Diego, CA, USA, 11-13 March 2009; pp. 109-116.

3. 佐竹, S.; 神田, T.; Glas, D.F.; 今井, M.; 石黒, H.;萩田, N. 人間へのアプローチ方法は？社会ロボットが交流を開始するための戦略。第4回ACM/IEEE国際人間ロボットインタラクション会議の議事録、サンディエゴ、CA、米国、2009年3月11-13日；pp. 109-116。

4. Satake, S.; Kanda, T.; Glas, D.F.; Imai, M.; Ishiguro, H.; Hagita, N. A robot that approaches pedestrians. IEEE Trans. Robot. 2012, 29, 508-524. [CrossRef]

4. 佐竹, S.; 神田, T.; Glas, D.F.; 今井, M.; 石黒, H.;萩田, N. 歩行者に近づくロボット。IEEE Trans. Robot. 2012, 29, 508-524. [CrossRef]

5. Walters, M.L.; Dautenhahn, K.; TeBoekhorst, R.; Koay, K.L.; Syrdal, D.S.; Nehaniv, C.L. An empirical framework for human-robot proxemics. In Proceedings of the Symposium on New Frontiers in Human-Robot Interaction, AISB2009, Edinburgh, Scotland, 8-9 April 2009; pp. 144-149 .

5. Walters, M.L.; Dautenhahn, K.; TeBoekhorst, R.; Koay, K.L.; Syrdal, D.S.; Nehaniv, C.L. 人間-ロボットの近接空間に関する経験的枠組み。ヒューマン・ロボット・インタラクションの新たなフロンティアに関するシンポジウム、AISB2009、エディンバラ、スコットランド、2009年4月8-9日；pp. 144-149。

6. Cristani, M.; Bazzani, L.; Paggetti, G.; Fossati, A.; Tosato, D.; Del Bue, A.; Menegaz, G.; Murino, V. Social interaction discovery by statistical analysis of F-formations. In Proceedings of the BMVC 2011-Proceedings of the British Machine Vision Conference 2011, Dundee, UK, 29 August-2 September 2011.

6. Cristani, M.; Bazzani, L.; Paggetti, G.; Fossati, A.; Tosato, D.; Del Bue, A.; Menegaz, G.; Murino, V. F-形成の統計分析による社会的交流の発見。BMVC 2011 - 英国機械視覚会議の議事録、ダンディー、UK、2011年8月29日-9月2日。

7. Setti, F.; Russell, C.; Bassetti, C.; Cristani, M. F-formation detection: Individuating free-standing conversational groups in images. PLoS ONE 2015, 10, e0123783. [CrossRef]

7. Setti, F.; Russell, C.; Bassetti, C.; Cristani, M. F-形成検出:画像内の自由立ち会話グループの個別化。PLoS ONE 2015, 10, e0123783. [CrossRef]

8. Vascon, S.; Mequanint, E.Z.; Cristani, M.; Hung, H.; Pelillo, M.; Murino, V. A Game-Theoretic Probabilistic Approach for Detecting Conversational Groups. In Asian Conference on Computer Vision; Springer: Singapore, 2014.

8. Vascon, S.; Mequanint, E.Z.; Cristani, M.; Hung, H.; Pelillo, M.; Murino, V. 会話グループ検出のためのゲーム理論的確率的アプローチ。アジアコンピュータビジョン会議、Springer:シンガポール、2014年。

9. Correia, F.; Alves-Oliveira, P.; Maia, N.; Ribeiro, T.; Petisca, S.; Melo, F.S.; Paiva, A. Just follow the suit! trust in human-robot interactions during card game playing. In Proceedings of the 2016 25th IEEE International Symposium on Robot and Human Interactive Communication (RO-MAN), New York, NY, USA, 26-31 August 2016; pp. 507-512.

9. Correia, F.; Alves-Oliveira, P.; Maia, N.; Ribeiro, T.; Petisca, S.; Melo, F.S.; Paiva, A. カードゲーム中の人間-ロボットインタラクションにおける信頼:スーツに従うだけ！。2016年IEEEロボットと人間のインタラクション国際シンポジウム(RO-MAN)、ニューヨーク、NY、米国、2016年8月26-31日；pp. 507-512。

10. Oliveira, R.; Arriaga, P.; Correia, F.; Paiva, A. The stereotype content model applied to human-robot interactions in groups. In Proceedings of the 2019 14th ACM/IEEE International Conference on Human-Robot Interaction (HRI), Daegu, Korea, 11-14 March 2019; pp. 123-132.

10. Oliveira, R.; Arriaga, P.; Correia, F.; Paiva, A. グループ内の人間-ロボットインタラクションに適用されたステレオタイプ内容モデル。2019年第14回ACM/IEEE国際人間ロボットインタラクション会議(HRI)、大邱、韓国、2019年3月11-14日；pp. 123-132。

11. Leite, I.; Martinho, C.; Paiva, A. Social robots for long-term interaction: A survey. Int. J. Soc. Robot. 2013, 5, 291-308. [CrossRef]

11. Leite, I.; Martinho, C.; Paiva, A. 長期的な相互作用を目的としたソーシャルロボットの調査。Int. J. Soc. Robot. 2013, 5, 291-308. [CrossRef]

12. Flickner, M.D.; Haritaoglu, R.I. Method of Detecting and Tracking Groups of People. U.S. Patent No. 7,688,349, 30 March 2010.

12. Flickner, M.D.; Haritaoglu, R.I. 人のグループの検出と追跡方法。米国特許第7,688,349号、2010年3月30日。

13. Lau, B.; Arras, K.O.; Burgard, W. Tracking groups of people with a multi-model hypothesis tracker. In Proceedings of the 2009 IEEE International Conference on Robotics and Automation, Kobe, Japan, 12-17 May 2009; pp. 3180-3185.

13. Lau, B.; Arras, K.O.; Burgard, W. マルチモデル仮説追跡器を用いた人のグループ追跡。2009年IEEEロボティクス・オートメーション国際会議(Kobe, Japan、2009年5月12-17日)論文集、pp. 3180-3185。

14. Linder, T.; Arras, K.O. Multi-model hypothesis tracking of groups of people in RGB-D data. In Proceedings of the 17th International Conference on Information Fusion (FUSION), Salamanca, Spain, 7-10 July 2014; pp. 1-7.

14. Linder, T.; Arras, K.O. RGB-Dデータにおける人のグループのマルチモデル仮説追跡。第17回情報融合国際会議(FUSION)、スペイン、サラマンカ、2014年7月7-10日、pp. 1-7。

15. Luber, M.; Arras, K.O. Multi-hypothesis social grouping and tracking for mobile robots. In Robotics: Science and Systems; Springer: Berlin, Germany, 2013.

15. Luber, M.; Arras, K.O. 移動ロボットのためのマルチ仮説社会的グループ化と追跡。ロボティクス:サイエンスとシステムズ、Springer、ベルリン、ドイツ、2013年。

16. Hall, E.T. The Hidden Dimension; Doubleday: Garden City, NY, USA, 1966; Volume 609.

16. Hall, E.T. 隠された次元; Doubleday: ガーデンシティ、ニューヨーク州、アメリカ合衆国、1966年; 第609巻。

17. Kendon, A. Conducting Interaction: Patterns of Behavior in Focused Encounters; CUP Archive: Cambridge, UK, 1990.

17. Kendon, A. 対話の進行:焦点を当てた出会いにおける行動パターン; CUPアーカイブ:ケンブリッジ、英国、1990年。

18. Kendon, A. Spacing and Orientation in Co-Present Interaction; Springer: Berlin/Heidelberg, Germany, 2010.

18. Kendon, A. 共在相互作用における間隔と方位; Springer:ベルリン/ハイデルベルク、ドイツ、2010年。

19. Swofford, M.; Peruzzi, J.; Vázquez, M. Conversational group detection with deep convolutional networks. arXiv 2018, arXiv:181004039.

19. Swofford, M.; Peruzzi, J.; Vázquez, M. 深層畳み込みネットワークを用いた会話グループの検出。arXiv 2018年、arXiv:181004039。

20. Taylor, A.; Riek, L.D. Robot Perception of Human Groups in the Real World: State of the Art. In AAAI Fall Symposia Series; AAAI: Arlington, VA, USA, 2016.

20. Taylor, A.; Riek, L.D. 実世界における人間グループのロボット認識:最新の状況。AAAI秋季シンポジウムシリーズ; AAAI:アーリントン、バージニア州、アメリカ合衆国、2016年。

21. Brščić, D.; Zanlungo, F.; Kanda, T. Modelling of pedestrian groups and application to group recognition. In Proceedings of the 2017 40th International Convention on Information and Communication Technology, Electronics and Microelectronics (MIPRO), Opatija, Croatia, 22-26 May 2017; pp. 564-569.

21. Brščić, D.; Zanlungo, F.; Kanda, T. 歩行者グループのモデル化とグループ認識への応用。2017年第40回情報通信技術、電子工学およびマイクロエレクトロニクス国際会議(MIPRO)、クロアチア、オパティア、2017年5月22-26日、pp. 564-569。

22. Caine, K.; Šabanovic, S.; Carter, M. The effect of monitoring by cameras and robots on the privacy enhancing behaviors of older adults. In Proceedings of the Seventh Annual ACM/IEEE International Conference on Human-Robot Interaction, New York, NY, USA, 5 March 2012; pp. 343-350.

22. Caine, K.; Šabanovic, S.; Carter, M. カメラとロボットによる監視が高齢者のプライバシー向上行動に与える影響。第7回年次ACM/IEEE国際ヒューマンロボットインタラクション会議、ニューヨーク、NY、2012年3月5日、pp. 343-350。

23. Kaminski, M.E.; Rueben, M.; Smart, W.D.; Grimm, C.M. Averting robot eyes. Md. L. Rev. 2016, 76, 983.

23. Kaminski, M.E.; Rueben, M.; Smart, W.D.; Grimm, C.M. ロボットの目をそらす。Md. L. Rev. 2016年、76巻、983ページ。

24. Mazzon, R.; Poiesi, F.; Cavallaro, A. Detection and tracking of groups in crowd. In Proceedings of the 2013 10th IEEE International Conference on Advanced Video and Signal Based Surveillance, Krakow, Poland, 27-30 August 2013; pp. 202-207.

24. Mazzon, R.; Poiesi, F.; Cavallaro, A. 群衆におけるグループの検出と追跡。2013年IEEE第10回高度映像・信号監視国際会議(Krakow, Poland、2013年8月27-30日)、pp. 202-207。

25. Ramírez, O.A.I.; Varni, G.; Andries, M.; Chetouani, M.; Chatila, R. Modeling the dynamics of individual behaviors for group detection in crowds using low-level features. In Proceedings of the 2016 25th IEEE International Symposium on Robot and Human Interactive Communication (RO-MAN), New York, NY, USA, 26-31 August 2016; pp. 1104-1111.

25. Ramírez, O.A.I.; Varni, G.; Andries, M.; Chetouani, M.; Chatila, R. 低レベル特徴を用いた群衆内の個人行動のダイナミクスモデル化とグループ検出。2016年IEEE第25回ロボットと人間のインタラクション国際シンポジウム(RO-MAN)、ニューヨーク、NY、2016年8月26-31日、pp. 1104-1111。

26. Pathi, S.K.; Kiselev, A.; Loutfi, A. Estimating F-formations for mobile robotic telepresence. In Proceedings of the ACM/IEEE International Conference on Human-Robot Interaction, Vienna, Austria, 6-9 March 2017.

26. Pathi, S.K.; Kiselev, A.; Loutfi, A. 移動ロボットの遠隔操作におけるF形成の推定。2017年ACM/IEEE国際ヒューマンロボットインタラクション会議、ウィーン、オーストリア、2017年3月6-9日。

27. Pathi, S.K.; Kristofferson, A.; Kiselev, A.; Loutfi, A. Estimating Optimal Placement for a Robot in Social Group Interaction. In Proceedings of the 2019 28th IEEE International Conference on Robot and Human Interactive Communication, RO-MAN, New Delhi, India, 14-18 October 2019.

27. Pathi, S.K.; Kristofferson, A.; Kiselev, A.; Loutfi, A. 社会的グループ交流におけるロボットの最適配置の推定。2019年第28回IEEE国際ロボット・ヒューマンインタラクション通信会議RO-MANの議事録、インド・ニューデリー、2019年10月14-18日。

28. Barua, H.B.; Pramanick, P.; Sarkar, C.; Mg, T.H. Let me join you! Real-time F-formation recognition by a socially aware robot. arXiv 2020, arXiv:2008.10078.

28. Barua, H.B.; Pramanick, P.; Sarkar, C.; Mg, T.H. 社会的認知を持つロボットによるリアルタイムF形成認識:「私に参加させて！」arXiv 2020、arXiv:2008.10078。

29. Tseng, S.H.; Chao, Y.; Lin, C.; Fu, L.C. Service robots: System design for tracking people through data fusion and initiating interaction with the human group by inferring social situations. Robot. Auton. Syst. 2016, 83, 188-202. [CrossRef]

29. Tseng, S.H.; Chao, Y.; Lin, C.; Fu, L.C. サービスロボット:データ融合による人追跡システム設計と社会的状況推測による人間グループとの交流開始。ロボット・自律システム 2016年、83、188-202。[CrossRef]

30. Patterson, M. Spatial factors in social interactions. Hum. Relat. 1968, 21, 351-361. [CrossRef]

30. Patterson, M. 社会的交流における空間的要因。人間関係 1968年、21、351-361。[CrossRef]

31. Walters, M.L.; Syrdal, D.S.; Koay, K.L.; Dautenhahn, K.; TeBoekhorst, R. Human approach distances to a mechanical-looking robot with different robot voice styles. In Proceedings of the RO-MAN 2008-The 17th IEEE International Symposium on Robot and Human Interactive Communication, Munich, Germany, 1-3 August 2008; pp. 707-712.

31. Walters, M.L.; Syrdal, D.S.; Koay, K.L.; Dautenhahn, K.; TeBoekhorst, R. 異なるロボット音声スタイルを持つ機械的外観のロボットに対する人間の接近距離。2008年RO-MAN第17回IEEE国際ロボット・ヒューマンインタラクション通信会議、ドイツ・ミュンヘン、2008年8月1-3日、pp. 707-712。

32. Hinds, P.J.; Roberts, T.L.; Jones, H. Whose job is it anyway? A study of human-robot interaction in a collaborative task. Hum.-Comput. Interact. 2004, 19, 151-181. [CrossRef]

32. Hinds, P.J.; Roberts, T.L.; Jones, H. いったい誰の仕事？協働作業における人間とロボットの相互作用の研究。ヒューマン・コンピュータ・インタラクション 2004年、19、151-181。[CrossRef]

33. Friedman, B.; Kahn, P.H., Jr.; Hagman, J. Hardware companions? What online AIBO discussion forums reveal about the human-robotic relationship. In Proceedings of the SIGCHI Conference on Human Factors in Computing Systems, Ft. Lauderdale, FL, USA, 5-10 April 2003; pp. 273-280.

33. Friedman, B.; Kahn, P.H., Jr.; Hagman, J. ハードウェアの伴侶？オンラインのAIBO討議フォーラムが示す人間とロボットの関係。SIGCHI人間工学会議の議事録、フロリダ州フォートローダーデール、2003年4月5-10日、pp. 273-280。

34. Hall, E.T.; Birdwhistell, R.L.; Bock, B.; Bohannan, P.; Diebold, A.R., Jr.; Durbin, M.; Edmonson, M.S.; Fischer, J.L.; Hymes, D.; Kimball, S.T.; et al. Proxemics [and comments and replies]. Curr. Anthropol. 1968, 9, 83-108. [CrossRef]

34. Hall, E.T.; Birdwhistell, R.L.; Bock, B.; Bohannan, P.; Diebold, A.R., Jr.; Durbin, M.; Edmonson, M.S.; Fischer, J.L.; Hymes, D.; Kimball, S.T.; 他。近接空間学 [コメントと返信も含む]。現代人類学 1968年、9、83-108。[CrossRef]

35. Sommer, R. Personal Space. The Behavioral Basis of Design; Prentice Hall: Englewood Cliffs, NJ, USA, 1969.

35. Sommer, R. パーソナルスペース。行動に基づく設計原則；プリンチスホール:イングルウッド・クリフズ、ニュージャージー州、1969年。

36. Marshall, P.; Rogers, Y.; Pantidi, N. Using F-formations to analyse spatial patterns of interaction in physical environments. In Proceedings of the ACM Conference on Computer Supported Cooperative Work, CSCW, Hangzhou, China, 19-23 March 2011.

36. Marshall, P.; Rogers, Y.; Pantidi, N. F形成を用いた物理環境における空間パターンの分析。ACMコンピュータ支援協働作業会議の議事録、CSCW、中国・杭州、2011年3月19-23日。

37. Serna, A.; Pageaud, S.; Tong, L.; George, S.; Tabard, A. F-formations and collaboration dynamics study for designing mobile collocation. In Proceedings of the 18th International Conference on Human-Computer Interaction with Mobile Devices and Services Adjunct, MobileHCI 2016, Florence, Italy, 6-9 September 2016; Association for Computing Machinery, Inc.: New York, NY, USA, 2016; pp. 1138-1141. Available online: http://dl.acm.org/citation.cfm?doid=2957265.2962656 (accessed on 6 March 2019).

37. Serna, A.; Pageaud, S.; Tong, L.; George, S.; Tabard, A. 移動コロケーション設計のためのF形成と協調ダイナミクスの研究。第18回ヒューマン・コンピュータインタラクションとモバイルデバイス・サービス国際会議の議事録、MobileHCI 2016、イタリア・フィレンツェ、2016年9月6-9日。ACM発行、ニューヨーク、2016年、pp. 1138-1141。オンライン閲覧:http://dl.acm.org/citation.cfm?doid=2957265.2962656(2019年3月6日アクセス)

38. Murphy-Chutorian, E.; Trivedi, M.M. Head pose estimation in computer vision: A survey. IEEE Trans. Pattern Anal. Mach. Intell. 2009, 31, 607-626. [CrossRef]

38. Murphy-Chutorian, E.; Trivedi, M.M. コンピュータビジョンにおける頭部姿勢推定:調査。IEEEパターン分析・機械知能誌 2009年、31、607-626。[CrossRef]

39. Alletto, S.; Serra, G.; Calderara, S.; Cucchiara, R. Head pose estimation in first-person camera views. In Proceedings of the International Conference on Pattern Recognition, Stockholm, Sweden, 24-28 August 2014.

39. Alletto, S.; Serra, G.; Calderara, S.; Cucchiara, R. 一人称カメラ映像における頭部姿勢推定。国際パターン認識会議の議事録、スウェーデン・ストックホルム、2014年8月24-28日。

40. Robertson, N.; Reid, I. Estimating gaze direction from low-resolution faces in video. In European Conference on Computer Vision; Springer: Berlin/Heidelberg, Germany, 2006; pp. 402-415.

40. Robertson, N.; Reid, I. 低解像度の顔からの視線方向推定。ヨーロッパコンピュータビジョン会議の議事録、スプリンガー、ベルリン/ハイデルベルク、ドイツ、2006年、pp. 402-415。

41. Tosato, D.; Spera, M.; Cristani, M.; Murino, V. Characterizing humans on riemannian manifolds. IEEE Trans. Pattern Anal. Mach. Intell. 2012, 35, 1972-1984. [CrossRef]

41. Tosato, D.; Spera, M.; Cristani, M.; Murino, V. リーマニアン多様体上の人間の特徴付け。IEEEパターン分析・機械知能誌 2012年、35、1972-1984。[CrossRef]

42. Tosato, D.; Farenzena, M.; Spera, M.; Murino, V.; Cristani, M. Multi-class classification on riemannian manifolds for video surveillance. In European Conference on Computer Vision; Springer: Berlin/Heidelberg, Germany, 2010; pp. 378-391.

42. Tosato, D.; Farenzena, M.; Spera, M.; Murino, V.; Cristani, M. ビデオ監視のためのリーマン多様体上のマルチクラス分類。欧州コンピュータビジョン会議での発表; Springer: ベルリン/ハイデルベルク, ドイツ, 2010; pp. 378-391.

43. Raytchev, B.; Yoda, I.; Sakaue, K. Head pose estimation by nonlinear manifold learning. In Proceedings of the International Conference on Pattern Recognition, Cambridge, UK, 26 August 2004.

43. Raytchev, B.; Yoda, I.; Sakaue, K. 非線形多様体学習による頭部姿勢推定。パターン認識国際会議の proceedings, ケンブリッジ, 英国, 2004年8月26日.

44. Fanelli, G.; Gall, J.; Van Gool, L. Real time head pose estimation with random regression forests. In Proceedings of the IEEE Computer Society Conference on Computer Vision and Pattern Recognition, Colorado Springs, CO, USA, 20-25 June 2011.

44. Fanelli, G.; Gall, J.; Van Gool, L. ランダム回帰森林を用いたリアルタイム頭部姿勢推定。IEEEコンピュータビジョンとパターン認識会議の proceedings, コロラドスプリングス, コロラド州, 米国, 2011年6月20-25日.

45. Ruiz, N.; Chong, E.; Rehg, J.M. Fine-grained head pose estimation without keypoints. In Proceedings of the IEEE Computer Society Conference on Computer Vision and Pattern Recognition Workshops, Salt Lake City, UT, USA, 18-22 June 2018.

45. Ruiz, N.; Chong, E.; Rehg, J.M. キーポイントなしの微細な頭部姿勢推定。IEEEコンピュータビジョンとパターン認識ワークショップの proceedings, ソルトレイクシティ, ユタ州, 米国, 2018年6月18-22日.

46. Godec, M.; Roth, P.M.; Bischof, H. Hough-based tracking of non-rigid objects. Comput. Vis. Image Underst. 2012, 117, 1245-1256. [CrossRef]

46. Godec, M.; Roth, P.M.; Bischof, H. 非剛体物体のハフ変換に基づく追跡。コンピュータビジョンと画像理解, 2012年, 117, 1245-1256. [CrossRef]

47. Rother, C.; Kolmogorov, V.; Blake, A. "Grabcut": Interactive foreground extraction using iterated graph cuts. ACM Trans. Graph. 2004, 23, 309-314. [CrossRef]

47. Rother, C.; Kolmogorov, V.; Blake, A. 「Grabcut」:反復グラフカットを用いたインタラクティブな前景抽出。ACMトランザクション・オン・グラフィックス, 2004年, 23, 309-314. [CrossRef]

48. Alletto, S.; Serra, G.; Calderara, S.; Cucchiara, R. Understanding social relationships in egocentric vision. Pattern Recognit. 2015, 48, 4082-4096. [CrossRef]

48. Alletto, S.; Serra, G.; Calderara, S.; Cucchiara, R. 自己中心視野における社会的関係の理解。パターン認識, 2015年, 48, 4082-4096. [CrossRef]

49. Katevas, K.; Haddadi, H.; Tokarchuk, L.; Clegg, R.G. Detecting group formations using iBeacon technology. In Proceedings of the 2016 ACM International Joint Conference on Pervasive and Ubiquitous Computing: Adjunct, Heidelberg, Germany, 12-16 September 2016; pp. 742-752.

49. Katevas, K.; Haddadi, H.; Tokarchuk, L.; Clegg, R.G. iBeacon技術を用いたグループ形成の検出。2016年のACM国際ユビキタスコンピューティング会議の付録, ハイデルベルク, ドイツ, 2016年9月12-16日; pp. 742-752.

50. Hung, H.; Englebienne, G.; CabreraQuiros, L. Detecting conversing groups with a single worn accelerometer. In Proceedings of the 16th International Conference on Multimodal Interaction, Istanbul, Turkey, 12-16 November 2014; pp. 84-91.

50. Hung, H.; Englebienne, G.; CabreraQuiros, L. 単一の装着型加速度計による会話グループの検出。第16回多モーダルインタラクション国際会議の proceedings, イスタンブール, トルコ, 2014年11月12-16日; pp. 84-91.

51. Tao, Y.; Mitsven, S.G.; Perry, L.K.; Messinger, D.S.; Shyu, M.L. Audio-Based Group Detection for Classroom Dynamics Analysis. In Proceedings of the 2019 International Conference on Data Mining Workshops (ICDMW), Beijing, China, 8-11 November 2019; pp. 855-862.

51. Tao, Y.; Mitsven, S.G.; Perry, L.K.; Messinger, D.S.; Shyu, M.L. 教室のダイナミクス分析のための音声ベースのグループ検出。2019年のデータマイニングワークショップ国際会議(ICDMW)の proceedings, 北京, 中国, 2019年11月8-11日; pp. 855-862.

52. Solera, F.; Calderara, S.; Cucchiara, R. Socially constrained structural learning for groups detection in crowd. IEEE Trans. Pattern Anal. Mach. Intell. 2015, 38, 995-1008. [CrossRef]

52. Solera, F.; Calderara, S.; Cucchiara, R. 群衆における社会的制約を考慮した構造学習によるグループ検出。IEEEパターン分析・機械知能トランザクション, 2015年, 38, 995-1008. [CrossRef]

53. Fern, O.T.; Denman, S.; Sridharan, S.; Fookes, C. Gd-gan: Generative adversarial networks for trajectory prediction and group detection in crowds. In Asian Conference on Computer Vision; Springer: Singapore, 2018; pp. 314-330.

53. Fern, O.T.; Denman, S.; Sridharan, S.; Fookes, C. Gd-gan:群衆の軌跡予測とグループ検出のための敵対的生成ネットワーク。アジアコンピュータビジョン会議; Springer: シンガポール, 2018; pp. 314-330.

54. Hung, H.; Kröse, B. Detecting F-formations as dominant sets. In Proceedings of the ICMI'11-Proceedings of the 2011 ACM International Conference on Multimodal Interaction, Alicante, Spain, 14-18 November 2011.

54. Hung, H.; Kröse, B. F-formationを支配集合として検出。2011年のACM国際マルチモーダルインタラクション会議(ICMI'11)の proceedings, アリカンテ, スペイン, 2011年11月14-18日.

55. Setti, F.; Lanz, O.; Ferrario, R.; Murino, V.; Cristani, M. Multi-scale f-formation discovery for group detection. In Proceedings of the 2013 IEEE International Conference on Image Processing, ICIP 2013-Proceedings, Melbourne, VIC, Australia, 15-18 September 2013; pp. 3547-3551.

55. Setti, F.; Lanz, O.; Ferrario, R.; Murino, V.; Cristani, M. グループ検出のための多スケールF-formation発見。2013年IEEE国際画像処理会議(ICIP 2013)の proceedings, メルボルン, ビクトリア州, オーストラリア, 2013年9月15-18日; pp. 3547-3551.

56. Ricci, E.; Varadarajan, J.; Subramanian, R.; Bulo, S.R.; Ahuja, N.; Lanz, O. Uncovering interactions and interactors: Joint estimation of head, body orientation and f-formations from surveillance videos. In Proceedings of the IEEE International Conference on Computer Vision (ICCV), Santiago, Chile, 7-15 December 2015; pp. 4660-4668.

56. Ricci, E.; Varadarajan, J.; Subramanian, R.; Bulo, S.R.; Ahuja, N.; Lanz, O. 監視映像からの頭部、身体の向きとF-formationの共同推定による相互作用とインタラクターの解明。IEEE国際コンピュータビジョン会議(ICCV)の proceedings, サンティアゴ, チリ, 2015年12月7-15日; pp. 4660-4668.

57. Zhang, L.; Hung, H. Beyond F-formations: Determining social involvement in free standing conversing groups from static images. In Proceedings of the IEEE Computer Society Conference on Computer Vision and Pattern Recognition, Las Vegas, NV, USA, 27-30 June 2016; pp. 1086-1095.

57. Zhang, L.; Hung, H. Fフォーム形成を超えて:静止画像からの自由立ち会話グループにおける社会的関与の判定。IEEEコンピュータ社会会議のコンピュータビジョンとパターン認識に関する会議録、ラスベガス、ネバダ州、アメリカ合衆国、2016年6月27-30日；pp. 1086-1095。

58. Vazquez, M.; Steinfeld, A.; Hudson, S.E. Parallel detection of conversational groups of free-standing people and tracking of their lower-body orientation. In Proceedings of the IEEE International Conference on Intelligent Robots and Systems, Hamburg, Germany, 28 September-2 October 2015.

58. Vazquez, M.; Steinfeld, A.; Hudson, S.E. 自由立ち人の会話グループの並列検出と下半身の向き追跡。IEEEインテリジェントロボットとシステム国際会議の議事録、ハンブルク、ドイツ、2015年9月28日-10月2日。

59. Aghaei, M.; Dimiccoli, M.; Ferrer, C.C.; Radeva, P. Towards social pattern characterization in egocentric photo-streams. Comput. Vis. Image Underst. 2018, 171, 104-117. [CrossRef]

59. Aghaei, M.; Dimiccoli, M.; Ferrer, C.C.; Radeva, P. 自己中心的写真ストリームにおける社会的パターンの特徴付けに向けて。コンピュータビジョンと画像理解、2018年、171、104-117。[CrossRef]

60. Swofford, M.; Peruzzi, J.; Tsoi, N.; Thompson, S.; Martin-Martin, R.; Savarese, S.; Vázquez, M. Improving Social Awareness Through DANTE: Deep Affinity Network for Clustering Conversational Interactants. In Proceedings of the ACM on Human-Computer Interaction, New York, NY, USA, 28 May 2020; Volume 4, pp. 1-23.

60. Swofford, M.; Peruzzi, J.; Tsoi, N.; Thompson, S.; Martin-Martin, R.; Savarese, S.; Vázquez, M. DANTEを用いた社会的認識の向上:会話相手のクラスタリングのための深層親和性ネットワーク。ACMヒューマンコンピュータインタラクションの会議録、ニューヨーク、アメリカ合衆国、2020年5月28日；第4巻、pp. 1-23。

61. Hüttenrauch, H.; Eklundh, K.S.; Green, A.; Topp, E.A. Investigating spatial relationships in human-robot interaction. In Proceedings of the 2006 IEEE/RSJ Ineternational Conference on Intelligent Robots and Systems, Beijing, China, 9-15 October 2006; pp. 5052-5059.

61. Hüttenrauch, H.; Eklundh, K.S.; Green, A.; Topp, E.A. 人間とロボットの相互作用における空間関係の調査。2006年IEEE/RSJインテリジェントロボットとシステム国際会議の議事録、中国北京、2006年10月9-15日；pp. 5052-5059。

62. Yamaoka, F.; Kanda, T.; Ishiguro, H.; Hagita, N. How close? Model of proximity control for information-presenting robots. In Proceedings of the 2008 3rd ACM/IEEE International Conference on Human-Robot Interaction (HRI), Amsterdam, The Netherlands, 12-15 March 2008; pp. 137-144.

62. Yamaoka, F.; Kanda, T.; Ishiguro, H.; Hagita, N. どれくらい近い？情報提示ロボットの近接制御モデル。2008年の第3回ACM/IEEE国際人間-ロボット相互作用会議(HRI)、オランダ・アムステルダム、2008年3月12-15日；pp. 137-144。

63. Kuzuoka, H.; Suzuki, Y.; Yamashita, J.; Yamazaki, K. Reconfiguring spatial formation arrangement by robot body orientation. In Proceedings of the 2010 5th ACM/IEEE International Conference on Human-Robot Interaction (HRI), Osaka, Japan, 2-5 March 2010; pp. 285-292.

63. Kuzuoka, H.; Suzuki, Y.; Yamashita, J.; Yamazaki, K. ロボットの身体の向きによる空間配置の再構成。2010年の第5回ACM/IEEE国際人間-ロボット相互作用会議(HRI)、日本・大阪、2010年3月2-5日；pp. 285-292。

64. Vroon, J.; Joosse, M.; Lohse, M.; Kolkmeier, J.; Kim, J.; Truong, K.; Englebienne, G.; Heylen, D.; Evers, V. Dynamics of social positioning patterns in group-robot interactions. In Proceedings of the IEEE International Workshop on Robot and Human Interactive Communication, Kobe, Japan, 31 August-4 September 2015.

64. Vroon, J.; Joosse, M.; Lohse, M.; Kolkmeier, J.; Kim, J.; Truong, K.; Englebienne, G.; Heylen, D.; Evers, V. グループロボット相互作用における社会的配置パターンのダイナミクス。IEEEロボットと人間のインタラクション国際ワークショップの議事録、神戸、日本、2015年8月31日-9月4日。

65. Johal, W.; Jacq, A.; Paiva, A.; Dillenbourg, P. Child-robot spatial arrangement in a learning by teaching activity. In Proceedings of the 25th IEEE International Symposium on Robot and Human Interactive Communication, RO-MAN 2016, New York, NY, USA, 26-31 August 2016.

65. Johal, W.; Jacq, A.; Paiva, A.; Dillenbourg, P. 学習支援活動における子供とロボットの空間配置。第25回IEEEロボットと人間のインタラクション国際シンポジウム(RO-MAN 2016)、ニューヨーク、アメリカ合衆国、2016年8月26-31日。

66. Kristoffersson, A.; Eklundh, K.S.; Loutfi, A. Measuring the Quality of Interaction in Mobile Robotic Telepresence: A Pilot's Perspective. Int. J. Soc. Robot. 2013, 5, 89-101. [CrossRef]

66. Kristoffersson, A.; Eklundh, K.S.; Loutfi, A. モバイルロボット遠隔操作におけるインタラクションの質の測定:操作者の視点。国際社会ロボットジャーナル、2013年、5、89-101。[CrossRef]

67. Fangkai, Y.; Christopher Peters, C. AppGAN: Generative adversarial networks for generating robot approach behaviors into small groups of people. In Proceedings of the 2019 28th IEEE International Conference on Robot and Human Interactive Communication (RO-MAN), New Delhi, India, 14-18 October 2019.

67. Fangkai, Y.; Christopher Peters, C. AppGAN:小規模グループへのロボット接近行動生成のための敵対的生成ネットワーク。2019年の第28回IEEEロボットと人間のインタラクション国際会議(RO-MAN)、インド・ニューデリー、2019年10月14-18日。

68. Gao, Y.; Yang, F.; Frisk, M.; Hemandez, D.; Peters, C.; Castellano, G. Learning socially appropriate robot approaching behavior toward groups using deep reinforcement learning. In Proceedings of the 2019 28th IEEE International Conference on Robot and Human Interactive Communication (RO-MAN), New Delhi, India, 14-18 October 2019;

68. Gao, Y.; Yang, F.; Frisk, M.; Hemandez, D.; Peters, C.; Castellano, G. 深層強化学習を用いた社会的に適切なロボットのグループ接近行動の学習。2019年の第28回IEEEロボットと人間のインタラクション国際会議(RO-MAN)、インド・ニューデリー、2019年10月14-18日。

69. Cao, Z.; Simon, T.; Wei, S.E.; Sheikh, Y. Realtime multi-person 2D pose estimation using part affinity fields. In Proceedings of the 30th IEEE Conference on Computer Vision and Pattern Recognition, CVPR 2017, Honolulu, HI, USA, 21-26 July 2016.

69. Cao, Z.; Simon, T.; Wei, S.E.; Sheikh, Y. パーツアフィニティフィールドを用いたリアルタイム多人数2D姿勢推定。30th IEEE Conference on Computer Vision and Pattern Recognition(CVPR 2017)、ハワイ州ホノルル、2016年7月21-26日。

70. Narasimhan, K.P.; White, G. An agent-based analyses of f-formations. In Proceedings of the International Conference on Practical Applications of Agents and Multi-Agent Systems, Salamanca, Spain, 23-24 May 2013; Springer: Berlin/Heidelberg, Germany, 2013; pp. 239-250.

70. Narasimhan, K.P.; White, G. エージェントベースのf形成の分析。国際エージェントおよびマルチエージェントシステム実用応用会議の議事録、スペインサラマンカ、2013年5月23-24日；Springer:ベルリン/ハイデルベルク、ドイツ、2013年；pp. 239-250。

71. Support Vector Machines. Available online: https://www.datacamp.com/community/tutorials/svm-classification-scikit-learn-python (accessed on 26 November 2021).

71. サポートベクターマシン。オンラインで利用可能:https://www.datacamp.com/community/tutorials/svm-classification-scikit-learn-python(2021年11月26日アクセス)。

72. Polynomial Kernel. Available online: https://en.wikipedia.org/wiki/Polynomial_kernel (accessed on 26 November 2021).

72. 多項式カーネル。オンラインで利用可能:https://en.wikipedia.org/wiki/Polynomial_kernel(2021年11月26日アクセス)。

73. Support Vector Machines Kernels. Available online: https://scikit-learn.org/stable/modules/svm.html#svm-kernels (accessed on 23 December 2021).

73. サポートベクターマシンのカーネル。オンラインで利用可能:https://scikit-learn.org/stable/modules/svm.html#svm-kernels(2021年12月23日アクセス)。

74. Zen, G.; Lepri, B.; Ricci, E.; Lanz, O. Space speaks: Towards socially and personality aware visual surveillance. In Proceedings of the 1st ACM International Workshop on Multimodal Pervasive Video Analysis, Firenze, Italy, 29 October 2010; pp. 37-42.

74. Zen, G.; Lepri, B.; Ricci, E.; Lanz, O. 空間は語る:社会的および性格的認識を備えた視覚監視に向けて。第1回ACM国際マルチモーダル常時映像解析ワークショップの議事録、フィレンツェ、イタリア、2010年10月29日；pp. 37-42。

75. Alameda-Pineda, X.; Staiano, J.; Subramanian, R.; Batrinca, L.; Ricci, E.; Lepri, B.; Lanz, O.; Sebe, N. Salsa: A novel dataset for multimodal group behavior analysis. IEEE Trans. Pattern Anal. Mach. Intell. 2015, 38, 1707-1720. [CrossRef]

75. Alameda-Pineda, X.; Staiano, J.; Subramanian, R.; Batrinca, L.; Ricci, E.; Lepri, B.; Lanz, O.; Sebe, N. Salsa:多モーダルグループ行動分析のための新しいデータセット。IEEEパターン分析・機械知能トランザクション、2015年、38巻、1707-1720ページ。[CrossRef]

76. Pathi, S.K.; Kristoffersson, A.; Kiselev, A.; Loutfi, A. F-Formations for Social Interaction in Simulation Using Virtual Agents and Mobile Robotic Telepresence Systems. Multimodal Technol. Interact. 2019, 3, 69. [CrossRef]

76. Pathi, S.K.; Kristoffersson, A.; Kiselev, A.; Loutfi, A. 仮想エージェントとモバイルロボット遠隔操作システムを用いたシミュレーションにおける社会的相互作用のためのF形成。マルチモーダル技術・インタラクション、2019年、3巻、69ページ。[CrossRef]

77. Unity Real-Time Development Platform I3D, 2D VR & AR Engine. Available online: https://unity.com/ (accessed on 10 October 2021).

77. Unityリアルタイム開発プラットフォームI3D、2D VR＆ARエンジン。オンラインで利用可能:https://unity.com/(2021年10月10日アクセス)。

78. Make Human Community. Available online: http://makehumancommunity.org/ (accessed on 6 April 2021).

78. Make Humanコミュニティ。オンラインで利用可能:http://makehumancommunity.org/(2021年4月6日アクセス)。

79. Mixamo. Available online: https://www.mixamo.com/ (accessed on 15 June 2021).

79. Mixamo。オンラインで利用可能:https://www.mixamo.com/(2021年6月15日アクセス)。

80. GitHub-DeNA/Chainer_Realtime_Multi-Person_Pose_Estimation: Chainer version of Realtime Multi-Person Pose Esti-amtion. Available online: https://github.com/DeNA/Chainer_Realtime_Multi-Person_Pose_Estimation (accessed on 26 November 2020).

80. GitHub-DeNA/Chainer_Realtime_Multi-Person_Pose_Estimation:Chainer版のリアルタイム多人数姿勢推定。オンラインで利用可能:https://github.com/DeNA/Chainer_Realtime_Multi-Person_Pose_Estimation(2020年11月26日アクセス)。