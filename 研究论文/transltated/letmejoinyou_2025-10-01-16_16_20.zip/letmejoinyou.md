# Let me join you! Real-time F-formation recognition by a socially aware robot

# 参加させてください！社会的認知を持つロボットによるリアルタイムF形成認識

Hrishav Bakul Barua \( {}^{1} \) , Pradip Pramanick \( {}^{1} \) , Chayan Sarkar \( {}^{1} \) , and Theint Haythi Mg \( {}^{2} \)

Hrishav Bakul Barua \( {}^{1} \) , Pradip Pramanick \( {}^{1} \) , Chayan Sarkar \( {}^{1} \) , and Theint Haythi Mg \( {}^{2} \)

\( {}^{1} \) TCS Research & Innovation, India

\( {}^{1} \) TCSリサーチ＆イノベーション、インド

\( {}^{2} \) Myanmar Institute of Information Technology, Mandalay, Myanmar

\( {}^{2} \) ミャンマー情報技術研究所、マンダレー、ミャンマー

Abstract-This paper presents a novel architecture to detect social groups in real-time from a continuous image stream of an ego-vision camera. F-formation defines social orientations in space where two or more person tends to communicate in a social place. Thus, essentially, we detect F-formations in social gatherings such as meetings, discussions, etc. and predict the robot's approach angle if it wants to join the social group. Additionally, we also detect outliers, i.e., the persons who are not part of the group under consideration. Our proposed pipeline consists of - a) a skeletal key points estimator (a total of 17) for the detected human in the scene, b) a learning model (using a feature vector based on the skeletal points) using CRF to detect groups of people and outlier person in a scene, and c) a separate learning model using a multi-class Support Vector Machine (SVM) to predict the exact F-formation of the group of people in the current scene and the angle of approach for the viewing robot. The system is evaluated using two data-sets. The results show that the group and outlier detection in a scene using our method establishes an accuracy of \( {91}\% \) . We have made rigorous comparisons of our systems with a state-of-the-art F-formation detection system and found that it outperforms the state-of-the-art by \( {29}\% \) for formation detection and \( {55}\% \) for combined detection of the formation and approach angle.

概要-本論文は、エゴビジョンカメラの連続画像ストリームからリアルタイムで社会的グループを検出する新しいアーキテクチャを提案する。F形成は、二人以上の人が社会的な場所でコミュニケーションをとる傾向がある空間的な社会的方向性を定義する。したがって、主に会議や討議などの社会的集まりにおいてF形成を検出し、ロボットが社会グループに参加したい場合のアプローチ角度を予測する。さらに、考慮されていないグループに属さない人物、すなわち外れ値も検出する。我々の提案するパイプラインは、a) シーン内の検出された人間の骨格の主要点(合計17点)を推定する骨格キーポイント推定器、b) 骨格点に基づく特徴ベクトルを用いたCRFによる学習モデルで、シーン内の人々のグループと外れ値を検出し、c) 現在のシーン内の人々のF形成とロボットのアプローチ角度を予測するための多クラスサポートベクターマシン(SVM)を用いた別の学習モデルから構成される。システムは二つのデータセットを用いて評価されている。結果は、我々の方法を用いたシーン内のグループと外れ値の検出が\( {91}\% \)の精度を確立していることを示している。我々は、最先端のF形成検出システムと比較を行い、形成検出において\( {29}\% \)、形成とアプローチ角度の併用検出において\( {55}\% \)の優位性を見出した。

## Keywords: F-Formation, Social Robotics

## キーワード:F形成、社会的ロボティクス

## I. INTRODUCTION

## I. はじめに

Social robotics has gained exponential momentum in recent years, where the aim is to make the robot behave acceptably and safely in social setups. Some of the interesting use cases of popular robotics applications are telepresence robots [1], [2], teleoperation robots, service robots, co-worker robots [3], etc. In many such applications, robots often need to join a group of people for interaction [4]. People in a group tend to maintain a pattern while they interact with each other. These patterns usually adhere to some orientations and distances among the participating people. So, the robots should be aware of the societal norms of joining existing groups for meetings and discussions [5], [6].

社会的ロボティクスは近年爆発的に注目を集めており、ロボットが社会的な場面で受け入れられ、安全に振る舞うことを目的としている。代表的なロボット応用例には、遠隔操作ロボット[1]、[2]、テレプレゼンスロボット、サービスロボット、協働ロボット[3]などがある。これらの多くの応用では、ロボットが人々のグループに参加して交流する必要がある[4]。グループ内の人々は、交流中に一定のパターンや規範を維持しようとする。これらのパターンは、参加者間の方位や距離に従うことが多い。したがって、ロボットは会議や討議のために既存のグループに参加する社会的規範を理解している必要がある[5]、[6]。

F-formation is a theory proposed by Kendon [7] that has been widely realized in group formations among people. It generally consists of three major areas or spaces, which define the intimacy level and societal norms of the interaction. Fig. 1 depicts a typical face-to-face (or vis-a-vis) and triangular (or triangle) F-formation. As described by Kendon, p-space is the area where the people stand in a patter, o-space is where the standing people look towards, generally inwards towards each other, and the r-space is the area that lies outside them. Generally, people in r-space are not considered as a part of the conversing group.

F形成は、Kendon[7]によって提案された理論であり、人々のグループ形成に広く実現されている。これは一般に、三つの主要な領域または空間から構成され、交流の親密さや社会的規範を定義する。図1は、典型的な対面(またはvis-a-vis)と三角形(またはtriangle)のF形成を示している。Kendonによると、p空間は人々が一定のパターンで立つ領域、o空間は立っている人々が互いに向き合う、一般的に内側を向いている空間、r空間はそれらの外側に位置する領域である。一般に、r空間にいる人々は会話グループの一部とはみなされない。

![bo_d3ecmp3ef24c73cu42a0_0_912_525_744_219_0.jpg](images/bo_d3ecmp3ef24c73cu42a0_0_912_525_744_219_0.jpg)

Fig. 1: Face-to-face and Triangular F-formation with the o-space, p-space and r-space marked.

図1:対面および三角形のF形成と、o空間、p空間、r空間のマーク。

![bo_d3ecmp3ef24c73cu42a0_0_918_862_735_283_0.jpg](images/bo_d3ecmp3ef24c73cu42a0_0_918_862_735_283_0.jpg)

Fig. 2: A high-level pipeline to detect F-formation and classify it from live camera feed in a robot.

図2:ロボットのライブカメラ映像からF形成を検出し分類する高レベルのパイプライン。

Motivation. The primary focus of this work is to make robots respect the societal norms while joining a group like a fellow human being. This will lead to more acceptability of a human towards a robot in social setups and would help a person in developing a certain level of confidence towards a robot. The existing methods to detect F-formations are mostly rule-based. The accuracy of such systems in a dynamic environment is not up to the mark. Moreover, if the group is being viewed from such an angle that some parts of the group are occluded, then the existing methods do not perform acceptably. Secondly, the existing works estimate F-formation based on the head pose and orientation, which may result in the wrong detection as someone might change his/her head orientation for a second and then again get back to his/her original orientation without changing the body orientation. So, the temporal information should also be taken into account in such dynamic cases. Such a method also finds application in COVID-19 scenario for monitoring human social distancing for ensuring safety and well being of the people in this difficult time.

動機。本研究の主な目的は、ロボットが人間と同じようにグループに参加する際に社会的規範を尊重させることである。これにより、社会的場面での人間のロボットに対する受容性が高まり、ロボットに対する一定の信頼感を育むことができる。既存のF形成検出方法はほとんどルールベースであり、動的環境下での精度は十分ではない。さらに、グループが一部遮蔽された角度から見られる場合、既存の方法は満足のいく結果を出せないことが多い。第二に、既存の研究は頭部の姿勢と向きに基づいてF形成を推定しているが、これにより誤検出が生じる可能性がある。なぜなら、誰かが一瞬頭の向きを変えても、身体の向きは変わらず、再び元に戻ることがあるからである。したがって、そのような動的なケースでは時間的情報も考慮すべきである。このような方法は、COVID-19の状況下においても、人々の社会的距離を監視し、安全と健康を確保するために応用できる。

Approach. In this work, we develop a machine learning based method to detect social groups of people (Fig. 2). We use a state-of-the-art deep learning model to detect some key points in the skeleton of the body of all the persons in the scene [8], [9]. Based on these key points, we devise classifiers that take into account the confidence value of each of the key points for training. We create the data-set using a camera mounted on a robot for four real-life formations - face-to-face, side-by-side, L-shaped, and triangular (Fig. 5) from various angles and distances.

アプローチ。本研究では、社会的グループを検出するための機械学習に基づく手法を開発します(図2)。最先端の深層学習モデルを用いて、シーン内のすべての人物の骨格のいくつかの重要なポイントを検出します[8]、[9]。これらの重要ポイントに基づき、各ポイントの信頼度値を考慮した分類器を設計します。ロボットに搭載されたカメラを用いて、さまざまな角度と距離からの4つの実生活のフォーメーション(対面、並列、L字型、三角形)(図5)に対してデータセットを作成します。

We tackle the problem of detecting social groups and the probable outliers in a scene. The forming of clusters of people into a group and then find the group of interest so that it can be further considered for F-formation detection. Then, we develop a robust real-time F-formation detection system that works atop the pre-processing model of avoiding outliers suiting it for robotic applications. Our system is not hampered due to the outliers in a scene. The system also gives the approach angle for the detected F-formation, i.e., the F-formation's orientation w.r.t. the robot or vice versa. This approach angle can be utilized if the robot wants to join the group and find a suitable spot for itself within the group.

私たちは、シーン内の社会的グループと可能性のある外れ値を検出する問題に取り組みます。人々のクラスタを形成し、それらをグループにまとめ、その中から関心のあるグループを特定し、F-formationの検出にさらに考慮できるようにします。その後、外れ値を避ける前処理モデルの上に動作する堅牢なリアルタイムF-formation検出システムを開発します。このシステムは、シーン内の外れ値による妨害を受けません。また、検出されたF-formationのアプローチ角度、すなわちロボットに対するF-formationの向きや逆も含めた角度も提供します。このアプローチ角度は、ロボットがグループに参加し、自身に適した位置を見つける際に利用できます。

Contributions: We have developed an end-to-end system that can detect the formation of social groups (F-formation) from an ego-vision camera in real-time. Our main contributions are listed in the following.

貢献:私たちは、エゴビジョンカメラからリアルタイムで社会的グループ(F-formation)の形成を検出できるエンドツーエンドのシステムを開発しました。主な貢献は以下の通りです。

- We have developed a robust and highly accurate multi-class SVM based F-formation classifier (Sections III-D and IV-C).

- 高い精度を持つ堅牢なマルチクラスSVMベースのF-formation分類器を開発しました(セクションIII-DおよびIV-C)。

- To decide the final pose of the robot while joining the group, we also detect the approach angle detection of the F-formation by the robot. This provides the angle of orientation of the group w.r.t. the robot (Sections III-D and IV-D).

- グループに参加する際のロボットの最終姿勢を決定するために、ロボットによるF-formationのアプローチ角度検出も行います。これにより、ロボットに対するグループの向きの角度が得られます(セクションIII-DおよびIV-D)。

- We detect social groups of people in a scene by avoiding outliers using our own CRF probabilistic model. This helps to detect who is part of the same p-space (Sections III-C and IV-B).

- 独自のCRF確率モデルを用いて外れ値を避けながらシーン内の社会的グループを検出します。これにより、誰が同じpスペースの一部であるかを検出するのに役立ちます(セクションIII-CおよびIV-B)。

## II. SURVEY OF RELATED WORKS

## II. 関連研究の調査

The problem of detecting social groups and interaction setups is the focus area of this paper. Setti et al. [10] provides a lucid literature study of the various group detection methods and algorithms with meaningful taxonomies. In this section, we summarize some of the relevant works dealing with similar problems.

社会的グループやインタラクションの設定を検出する問題は、本論文の焦点です。Settiら[10]は、さまざまなグループ検出方法とアルゴリズムについて明快な文献調査を提供しており、有意義な分類体系を示しています。本節では、類似の問題に取り組むいくつかの関連研究を要約します。

F-formation is used for formally defining a structure in a social gathering where people interact with each other [7]. The structures resemble certain geometric shapes like triangle, circle, square, etc. The predominant approaches use rule-based classifiers to detect F-formations [11], [12]. They use the Haar-cascade classifier to detect faces in an image sequence and then divide the face into four quadrants. The eye placement in the quadrants determines whether the head is oriented left or right. This although doesn't give a very accurate orientational information but serves the purpose. Alternatively, learning-based approaches are also explored in the literature. For example, Hedayati et al. [13] proposed a machine learning model for F-formation detection. The technique, first, deconstructs the image frames to finds all possible pairs of people. Then these pair-wise data with labels are fed into the model to classify if they are a part of any F-formation or not. And, finally, the pair-wise data are reconstructed into the full F-formation data. This method uses the Kinect mounted on a real robot to perceive 3D human poses. Similarly, Aghaei et al. [14] proposed a model inspired by Spatio-temporal aspects of any interaction among humans. They use two-dimensional time-series data, i.e., distances among participants over time and orientation of the participants over space and time. This sequence of images data is being used to train an LSTM based network. Ego-centric vision is used in the method and real-world scenarios are tested successfully with good accuracy. Alletto at al. [15] proposed yet another data-driven technique using Structural SVM. The article employs correlation-based clustering to assign a pair of people into social interactions or groups. The orientation and distance parameters are used to decide the affinity of two people in a group or interaction. The paper also attends to the dynamics of interacting groups and the varying meanings of distances and orientations among people in different social setups by introducing a Structural SVM to learn the weight vectors of correlation clustering. The method has been tested with ego-centric datasets although not implemented in a real robot. The paper says that it achieves real-time response in detecting interactions. Another contribution gives a graph-cuts minimization based algorithm to cluster participants of a social setup into groups [10]. The graph-cut finds the o-space in the group of people whose transactional segments (the area in front of any participant/robot/human where the sense of hearing and viewing is maximum) overlap. The transactional segments are identified by orientation of head, shoulder, or feet. They have reported good results for most of the interaction scenarios in real-time.

F-formationは、人々が互いに交流する社会的集まりの中で構造を正式に定義するために使用されます[7]。これらの構造は、三角形、円、正方形などの特定の幾何学的形状に似ています。主流のアプローチは、ルールベースの分類器を用いてF-formationを検出します[11]、[12]。これらは、画像シーケンス内の顔を検出するためにハールカスケード分類器を使用し、その後顔を4つの象限に分割します。象限内の目の位置により、頭の向きが左か右かを判断します。これは正確な向き情報を提供しませんが、目的には十分です。代替として、学習ベースのアプローチも文献で検討されています。例えば、Hedayatiら[13]は、F-formation検出のための機械学習モデルを提案しています。この手法は、まず画像フレームを分解して、すべての可能なペアの人々を見つけ出します。次に、これらのペアデータにラベルを付けてモデルに入力し、F-formationの一部かどうかを分類します。最後に、ペアごとのデータを再構築して完全なF-formationデータにします。この方法は、実際のロボットに搭載されたKinectを使用して3D人間ポーズを認識します。同様に、Aghaeiら[14]は、人間間の相互作用の時空間的側面に着想を得たモデルを提案しています。彼らは、時間を通じた参加者間の距離や空間と時間における参加者の向きなど、2次元の時系列データを使用します。この画像シーケンスデータを用いて、LSTMベースのネットワークを訓練しています。エゴセントリックビジョンを用いた方法であり、実世界のシナリオで良好な精度で成功裏にテストされています。Allettoら[15]は、構造SVMを用いたもう一つのデータ駆動型手法を提案しています。この記事では、相関に基づくクラスタリングを用いて、二人の人々を社会的交流やグループに割り当てます。向きと距離のパラメータを用いて、二人の関係性や交流の親密さを判断します。さらに、異なる社会的設定における人々の間の距離や向きの意味の変化や、相互作用グループのダイナミクスに対応するために、相関クラスタリングの重みベクトルを学習するための構造SVMを導入しています。この方法は、エゴセントリックなデータセットでテストされていますが、実際のロボットには実装されていません。論文では、リアルタイムでの相互作用検出が可能であると述べています。もう一つの貢献は、グラフカット最小化に基づくアルゴリズムを提案し、社会的設定の参加者をグループにクラスタリングします[10]。このグラフカットは、参加者(またはロボットや人間)の前方にある最大の感覚範囲(トランザクショナルセグメント)が重なるグループ内のo-spaceを見つけ出します。トランザクショナルセグメントは、頭、肩、または足の向きによって識別されます。これらの手法は、多くの相互作用シナリオにおいてリアルタイムで良好な結果を報告しています。

Alternatively, Vazquez et al. [16] talks about a new exocentric method to track people's lower body orientation (dynamic Bayesian Network) and head pose detection based on their position and objects of interest in their interaction vicinity, after that group detection (Hough voting scheme) takes place for the participating people in the scene. They also use the concept of soft assignment of participants to o-spaces which in turn allows much faster recovery from errors in group detection of low body orientation trackers. The visual focus of attention is an important cue in understanding social interaction quality and estimation. Bazzani et al. [17] focus on finding the Visual Focus of Attention (VFOA) of a person in 3D. The paper defines Subjective View Frustum (SVF) for the 3D representation and an Inter-Relation Pattern Matrix for capturing interactions between people in the scene. The paper [18] uses a social scientific approach to analyze human proxemics and behaviors in group interaction. The three main parameters being explored are - individual, physical, and psychological. HMMs are trained using two different feature representations: physical and psychological to identify Spatiotemporal behaviors. The significance of these behaviors is marked as the starting and ending of social interaction. The use of two different feature representations helps in a more robust proxemics behavior representation for a robot to be deployed in social setups for interactions. In a recent work [19], the authors make an interesting study on the formation of groups for interactions where a person is present in the group through a telepresence robot in one case and physically present in another. They found differences in group formation comparing these two cases. However, they established that the positions of each of the participants can be estimated based on the number of participants in the group and the group moderator's position.

あるいは、Vazquezら[16]は、低身体系の向き(動的ベイジアンネットワーク)と頭部姿勢検出を、相互作用の近傍における位置や関心対象に基づいて追跡する新しいエクソセントリック手法について述べています。その後、シーン内の参加者のグループ検出(Hough投票方式)が行われます。彼らはまた、参加者をo-spaceにソフトに割り当てる概念を用いており、これにより低身体系追跡器の誤りからの回復が格段に速くなります。視覚的注視点は、社会的相互作用の質と推定を理解する上で重要な手がかりです。Bazzaniら[17]は、3D空間における個人の視覚的注視点(VFOA)を見つけることに焦点を当てています。論文では、Subjective View Frustum(SVF)という3D表現と、シーン内の人々の相互作用を捉えるための相互関係パターンマトリックスを定義しています。さらに、[18]は、社会科学的アプローチを用いて、人間のプロクセミクスと行動をグループ内の相互作用において分析しています。主に探究されるパラメータは、個人、物理的、心理的です。HMMは、物理的および心理的な2つの異なる特徴表現を用いて訓練され、時空間的行動を識別します。これらの行動の重要性は、社会的相互作用の開始と終了として示されます。2つの異なる特徴表現の使用により、社会的設定での相互作用に適したより堅牢なプロクセミクス行動の表現が可能となります。最近の研究[19]では、グループ形成に関する興味深い研究が行われています。ここでは、ある人がテレプレゼンスロボットを通じてグループに参加している場合と、物理的に参加している場合の2つのケースを比較しています。これらのケースでのグループ形成の違いを発見しましたが、参加者の位置は、グループ内の参加者数とグループの司会者の位置に基づいて推定できると結論付けています。

Inspecting the related works we see that the main limitation is the use of ML/DL based methods due to the unavailability of appropriate datasets. Rule-based methods fail in dynamic environments and occlusions. Some methods consider only head pose and orientation which makes the system less robust to dynamism. We try to attend to these limitations in our work.

関連研究を検討すると、主な制限は適切なデータセットの不足によりML/DLベースの手法の使用にあります。ルールベースの方法は、動的環境や遮蔽に弱いです。一部の方法は頭部の向きと姿勢のみを考慮しており、動的な状況に対して堅牢性が低くなります。私たちの研究では、これらの制限に対応することを目指しています。

### III.OUR SYSTEM: OVERVIEW AND DESIGN

### III.私たちのシステム:概要と設計

An overview of our system is shown in Fig. 3. It consists of two main sub-systems - a) the group detection and human clustering avoiding outliers, and b) F-formation detection with the type (classification) and approach angle prediction. The first component clusters humans in a scene into socially interacting groups based on some spatial and orientation features. It also detects outliers in the scene to exclude them from groups. The second component finds the F-formation type for each of the detected groups from the previous component. Moreover, it also detects the orientation of the F-formation w.r.t. to the viewing camera (the robot) or the approach angle. This approach angle helps in estimating the optimal pose of the robot to join the group of people. In the following, we discuss all the components of this pipeline in detail.

私たちのシステムの概要は図3に示されています。これは主に二つのサブシステムから構成されており、a) アウトライヤーを避けながらのグループ検出と人間のクラスタリング、b) タイプ(分類)とアプローチ角度の予測を伴うF-formation検出です。最初のコンポーネントは、空間的および向きの特徴に基づいて、シーン内の人々を社会的に交流するグループにクラスタリングします。また、シーン内のアウトライヤーを検出し、それらをグループから除外します。二つ目のコンポーネントは、前のコンポーネントで検出された各グループのF-formationタイプを見つけ出します。さらに、カメラ(ロボット)やアプローチ角度に対するF-formationの向きも検出します。このアプローチ角度は、ロボットがグループに参加するための最適なポーズを推定するのに役立ちます。以下では、このパイプラインのすべてのコンポーネントについて詳しく説明します。

## A. Skeletal key point detection

## A. 骨格のキーポイント検出

To detect groups in a scene, first, we need to detect all the people in a scene and their corresponding body orientation. Then we need to detect the relationship of each of the persons with another one in the scene. There exist several deep learning-based models that can detect multi-person body skeleton and provide a number of key points corresponding to each person. In this work, we use Posenet \( {}^{1} \) to find multi-person skeletal points. As Posenet is a light-weight and highly accurate model, we use it to achieve real-time F-formation detection. Posenet typically yields 17 key points (with coordinates) of a human skeleton with some confidence ranging from 0 to 1 . The skeleton includes the following human body points- nose, leftEye, rightEye, leftEar, rightEar, leftShoulder, rightShoulder, leftElbow, rightElbow, leftWrist, rightWrist, left-Hip, rightHip, leftKnee, rightKnee, leftAnkle, and rightAnkle. Then these key-points are utilized to find the individual and relative orientation of the people, which leads to F-formation detection.

シーン内のグループを検出するには、まずシーン内のすべての人とその体の向きを検出する必要があります。次に、各人物と他の人物との関係性を検出します。複数の人の身体骨格を検出し、それぞれの人物に対応する重要なポイントを提供できる深層学習モデルがいくつか存在します。本研究では、Posenet \( {}^{1} \)を用いて複数人の骨格ポイントを検出します。Posenetは軽量で高精度なモデルであるため、リアルタイムのF-formation検出に利用しています。Posenetは通常、信頼度が0から1の範囲で、人体の骨格の17の重要ポイント(座標付き)を出力します。これらの骨格ポイントには、鼻、左目、右目、左耳、右耳、左肩、右肩、左肘、右肘、左手首、右手首、左腰、右腰、左膝、右膝、左足首、右足首が含まれます。次に、これらのポイントを用いて個々の人の向きと相対的な向きを特定し、それによりF-formationの検出を行います。

## B. Feature selection

## B. 特徴選択

As mentioned earlier, Posenet processes an image frame and provides the skeletal key points of each person in the scene. It associates a confidence value with each key point prediction. We assign four labels to each of these key points based on their confidence value - \( \{ \) Low: O - 0.25, Medium: O.25 - 0.5, High: O.5 - 0.75, Very high: 0.75 - 1\}. The list of key point coordinates along with their labels are used as the feature vector for our classifiers.

前述の通り、Posenetは画像フレームを処理し、シーン内の各人物の骨格の主要なポイントを提供します。各ポイントの予測には信頼値が関連付けられています。これらのポイントには、信頼値に基づいて4つのラベルを割り当てます - \( \{ \) 低:0.25未満、中:0.25〜0.5、高:0.5〜0.75、非常に高:0.75〜1。これらのポイントの座標とラベルのリストは、分類器の特徴ベクトルとして使用されます。

## C. Groups and outlier detection

## C. グループと異常値検出

The problem of group identification and detection in a populated scene is non-trivial. As there can be different types of F-formation with varying number of people along with different body orientation, it poses a challenge who are part of the group. Also, there can be some person standing nearby who is not part of any formation/group; thus should also not be considered for F-formation detection (outliers).

混雑したシーンにおけるグループの識別と検出の問題は容易ではない。異なる人数や身体の向きの異なるF-formationの種類が存在するため、誰がグループの一員であるかを特定することは難しい。また、近くに立っているがいずれのフォーメーションやグループにも属さない人物も存在し得るため、これらはF-formationの検出対象外(外れ値)とすべきである。

We use a conditional random field (CRF) based probabilistic model to formulate feature functions to predict whether the detected people in a scene are a part of a group or not (see Fig. 1 for outliers in a scene). As mentioned earlier, we use the label marking based on the confidence value to create the feature vector. The confidence value of a key point is dependent on the orientation of the person of which the skeleton is being detected by Posenet. Moreover, the location of the corresponding key points of two people can vary significantly based on their closeness or distance between them in the scene. We select such features for our CRF to detect social groups and outliers in a scene.

私たちは、条件付き確率場(CRF)に基づく確率モデルを使用して、特徴関数を定式化し、シーン内で検出された人々がグループの一部であるかどうかを予測します(シーン内の異常値については図1を参照)。前述のように、信頼値に基づくラベル付けを用いて特徴ベクトルを作成します。キーポイントの信頼値は、Posenetによって検出される骨格の向きに依存します。さらに、二人の人の対応するキーポイントの位置は、彼らの近さや距離に応じて大きく異なることがあります。私たちは、シーン内の社会的グループや異常値を検出するために、これらの特徴をCRFに選択しています。

Given a left-to-right sequence of 2d-poses \( {p}_{1},{p}_{2},\ldots ,{p}_{n} \) , of the people present in an image, we use a CRF to predict a sequence of group membership label, \( {g}_{1},{g}_{2},\ldots ,{g}_{n} \) , where \( {g}_{i} \in  G, O \) , where \( G \) and \( O \) denotes a person in a group and an outlier, respectively. We use the following CRF for this prediction,

画像に写っている人々の左から右への2Dポーズ列\( {p}_{1},{p}_{2},\ldots ,{p}_{n} \)が与えられたとき、我々はCRFを用いてグループ所属ラベルの列\( {g}_{1},{g}_{2},\ldots ,{g}_{n} \)を予測する。このとき、\( {g}_{i} \in  G, O \)はグループ内の人物、\( G \)はアウトライヤーをそれぞれ表し、\( O \)はグループ外の人物を示す。以下のCRFを用いてこの予測を行う、

\[
P\left( {{g}_{1 : n} \mid  {p}_{1 : n}}\right)  = \alpha \exp \left\{  {\mathop{\sum }\limits_{{i = 0}}^{n}\mathop{\sum }\limits_{{j = 0}}^{k}}\right.
\]

\[
\left. {{\lambda }_{j}{f}_{j}\left( {{p}_{i - 1},{p}_{i},{p}_{i + 1},{g}_{i - 1},{g}_{i}}\right) }\right\}  \text{,}
\]

where, each node of the CRF uses observation feature functions \( {f}_{j} \) defined over the current pose and its left and right neighbors, \( k \) is the number of such features functions, including a transition feature and \( \alpha \) is the normalization factor.

各CRFのノードは、現在の姿勢とその左および右の隣接ノードに基づいて定義された観測特徴関数\( {f}_{j} \)を使用し、\( k \)はそのような特徴関数の数(遷移特徴を含む)であり、\( \alpha \)は正規化係数である。

## D. F-formation detection with approach/robot joining angle

## D. アプローチ/ロボット結合角を用いたF-形成検出

We use a multi-class Support Vector Machine (SVM) with a Gaussian Radial Bias Function (RBF) kernel, both for the prediction of the F-formation and approach angle. This kernel minimizes the weighted squared Euclidean distance between the feature vectors of two arbitrary samples \( {X}_{i},{X}_{j} \) , i.e.,

私たちは、多クラスサポートベクターマシン(SVM)を、ガウシアンラジアル基底関数(RBF)カーネルとともに使用し、F形成とアプローチ角の予測を行います。このカーネルは、任意の2つのサンプルの特徴ベクトル間の加重二乗ユークリッド距離を最小化します。\( {X}_{i},{X}_{j} \) ,つまり、

\[
K\left( {{X}_{i},{X}_{j}}\right)  = \exp  - \gamma {\begin{Vmatrix}{X}_{i} - {X}_{j}\end{Vmatrix}}^{2},
\]

where the free parameter \( \gamma \) is learnt from the training data.

自由パラメータ\( \gamma \)は学習データから学習される。

---

\( {}^{1} \) https://github.com/tensorflow/tfjs-models/tree/master/posenet

\( {}^{1} \) https://github.com/tensorflow/tfjs-models/tree/master/posenet

---

![bo_d3ecmp3ef24c73cu42a0_3_312_144_1163_272_0.jpg](images/bo_d3ecmp3ef24c73cu42a0_3_312_144_1163_272_0.jpg)

Fig. 3: The overview of the pipeline of real-time F-formation classification and approach angle detection.

図3:リアルタイムF形成分類とアプローチ角度検出のパイプラインの概要。

![bo_d3ecmp3ef24c73cu42a0_3_242_526_1298_368_0.jpg](images/bo_d3ecmp3ef24c73cu42a0_3_242_526_1298_368_0.jpg)

Fig. 4: Four different F-formations with the considered approach angles layout map (red dotted arrows signify the approach/joining angles of a robot and blue dotted arrows are the orientations of the people in group interaction/formation).

図4:考慮されたアプローチ角度のレイアウトマップを持つ4つの異なるFフォーメーション(赤の点線矢印はロボットのアプローチ/合流角度を示し、青の点線矢印はグループインタラクション/フォーメーションにおける人々の向きを示す)。

Given a set of person-poses after the filtering by the group and outlier detection module, we use the SVM classifier for predicting the F-formation, and based on this prediction, we predict the approximate approach angle. We use the same feature vector for both the prediction, except for approach angle prediction, we use the output of the F-formation classifier as an additional feature and also filter it based on the set of people who belong to the same group. We also show an approach to jointly predict the F-formation and the approach angle in a single classifier and show its efficacy against a baseline approach in Section IV.

グループおよび外れ値検出モジュールによるフィルタリング後の人物ポーズのセットに対して、我々はSVM分類器を用いてF-formationを予測し、この予測に基づいておおよその接近角度を推定する。同じ特徴ベクトルを両方の予測に使用し、接近角度の予測においては、F-formation分類器の出力を追加の特徴として利用し、同じグループに属する人物のセットに基づいてフィルタリングする。また、F-formationと接近角度を共同で予測する単一の分類器のアプローチも提案し、その有効性をセクションIVでベースラインアプローチと比較して示す。

We consider the angles \( - {0}^{ \circ  },{30}^{ \circ  },{60}^{ \circ  },{90}^{ \circ  }, - {30}^{ \circ  }, - {60}^{ \circ  } \) and \( - {90}^{ \circ  } \) from which the formation is being viewed by the robot. This prediction reveals the orientation of the formation, thus the joining angle for the robot can be estimated. Fig. 4 shows an approach/joining angle layout map that we consider for our leaning models. We consider a complete set of angles for a robot that covers the major part of the formations. We consider \( - {90}^{ \circ  } \) to be the angle/direction which is the optimal angle for a robot to join the formation (in case of L-shaped and triangle) and \( - {90}^{ \circ  } \) as well as \( {90}^{ \circ  } \) in case of face-to-face and side-by-side depending on the situation. So, if the robot detects the formation from any other angle than \( - {90}^{ \circ  } \) and \( {90}^{ \circ  } \) (as per the formation), it can move to either left or right direction towards a \( - {90}^{ \circ  } \) or \( {90}^{ \circ  } \) angle (as per the formation and situation) and then it can move forward to join the group using some distance estimation method such as [20] and stopping criteria as elaborated in the literature survey [21].

ロボットが観察している形成の角度\( - {0}^{ \circ  },{30}^{ \circ  },{60}^{ \circ  },{90}^{ \circ  }, - {30}^{ \circ  }, - {60}^{ \circ  } \)と\( - {90}^{ \circ  } \)を考慮します。この予測は形成の向きを明らかにし、ロボットの合流角度を推定することができます。図4は、我々の学習モデルで考慮しているアプローチ／合流角度のレイアウトマップを示しています。主要な形成をカバーするロボットの角度の完全なセットを考慮しています。\( - {90}^{ \circ  } \)は、ロボットが形成に参加する最適な角度／方向(L字型や三角形の場合)とし、\( - {90}^{ \circ  } \)および\( {90}^{ \circ  } \)は、状況に応じて正面対面や並列の場合に使用される角度です。したがって、ロボットが\( - {90}^{ \circ  } \)および\( {90}^{ \circ  } \)以外の角度から形成を検出した場合(形成に応じて)、左または右の方向に移動し、\( - {90}^{ \circ  } \)または\( {90}^{ \circ  } \)の角度に向かいます(形成と状況に応じて)そして、その後、距離推定法(例: [20])や文献調査[21]で詳述されている停止基準を用いて前進し、グループに合流します。

The Face-to-face formation (Fig. 4a), is symmetrical, and therefore the same joining angle can be considered for the - \( {90}^{ \circ  }, - {60}^{ \circ  }, - {30}^{ \circ  } \) , and \( {0}^{ \circ  } \) angles and their symmetrical angles. As for the side-by-side formation (Fig. 4b), both the below \( {0}^{ \circ  } \) and above \( {0}^{ \circ  } \) angles are non-symmetric. Here also the remaining semi-circle is irrelevant as its symmetric. For Fig. 4c, which shows the L-shaped formation, the entire set of angles are relevant due to its non-symmetric nature. For the triangle formation in Fig. 4d the same argument holds tight.

対面形成(図4a)は対称的であるため、- \( {90}^{ \circ  }, - {60}^{ \circ  }, - {30}^{ \circ  } \) および \( {0}^{ \circ  } \) の角度とその対称角について同じ結合角を考えることができる。横並び形成(図4b)については、下の \( {0}^{ \circ  } \) と上の \( {0}^{ \circ  } \) の角度は非対称である。ここでも、残りの半円は対称であるため無関係である。図4cのL字型形成については、その非対称性のため、すべての角度が関係している。図4dの三角形形成についても、同じ議論が当てはまる。

## IV. EXPERIMENTS AND EVALUATION

## IV. 実験と評価

In this section, we evaluate our system on two aspects - the CRF probabilistic model for group and outlier detection and the multi-class SVM model with a radial bias function (RBF) kernel for F-formation detection and approach angle prediction. We only compared the accuracy of F-formation detection with a rule-based state-of-the-art system as proposed by Pathi et al. [12]. Since multiple group detection and approach angle detection is not done by any existing literature, we could not compare it with any.

このセクションでは、私たちのシステムを2つの側面で評価します。1つは、グループおよび異常検出のためのCRF確率モデル、もう1つは、F形成検出とアプローチ角度予測のための放射バイアス関数(RBF)カーネルを用いたマルチクラスSVMモデルです。F形成検出の精度については、Pathiら[12]が提案したルールベースの最先端システムと比較しただけです。複数のグループ検出やアプローチ角度検出は既存の文献では行われていないため、それらと比較することはできませんでした。

## A. Datasets and Setups

## A. データセットと設定

For training and testing our models, we have used two sets of data - the EGO-GROUP \( {}^{2} \) [15] dataset and a locally collected dataset. The EGO-GROUP dataset contains a total of 2900 frames annotated with groups. In different frames, they have used 19 different human subjects. In has 4 different scenarios to make it more challenging for detection. The dataset considers a laboratory setting, a coffee break setting, a festive scenario, and an outdoor scenario. All these scenarios have different levels of background clutter, lighting conditions, and orientation settings.

私たちのモデルの訓練とテストのために、2つのデータセットを使用しました。1つはEGO-GROUP \( {}^{2} \) [15] データセットで、もう1つは現地で収集したデータセットです。EGO-GROUPデータセットには、グループが注釈付けされた合計2900フレームが含まれています。異なるフレームでは、19人の異なる人間が使用されています。検出の難易度を高めるために、4つの異なるシナリオが設定されています。データセットは、実験室設定、コーヒーブレイクの設定、祭典のシナリオ、屋外のシナリオを考慮しています。これらのシナリオは、背景の雑然さ、照明条件、向きの設定がそれぞれ異なります。

---

\( {}^{2} \) http://imagelab.ing.unimore.it/files/EGO-GROUP.zip

\( {}^{2} \) http://imagelab.ing.unimore.it/files/EGO-GROUP.zip

---

TABLE I: Results for the prediction of group membership sequence given the sequence of \( 2\mathrm{D} \) poses.

表I:\( 2\mathrm{D} \)ポーズのシーケンスに基づくグループメンバーシップ予測の結果。

<table><tr><td>Group membership</td><td>Precision</td><td>Recall</td><td>\( \mathbf{{F1}} \)</td></tr><tr><td>Group</td><td>0.92</td><td>0.92</td><td>0.92</td></tr><tr><td>Outlier</td><td>0.89</td><td>0.89</td><td>0.89</td></tr><tr><td>\( \mathbf{{Avg}.} \)</td><td>0.91</td><td>0.91</td><td>0.91</td></tr></table>

<table><tbody><tr><td>グループメンバーシップ</td><td>精度</td><td>再現率</td><td>\( \mathbf{{F1}} \)</td></tr><tr><td>グループ</td><td>0.92</td><td>0.92</td><td>0.92</td></tr><tr><td>外れ値</td><td>0.89</td><td>0.89</td><td>0.89</td></tr><tr><td>\( \mathbf{{Avg}.} \)</td><td>0.91</td><td>0.91</td><td>0.91</td></tr></tbody></table>

We have also created a local dataset of four common F-formations - face-to-face, L-shaped, side-by-side, and triangle. For each of these formations, we collected the data using 4 different subjects from 7 different angles \( - {0}^{ \circ  },{30}^{ \circ  },{60}^{ \circ  } \) , \( {90}^{ \circ  }, - {30}^{ \circ  }, - {60}^{ \circ  } \) and \( - {90}^{ \circ  } \) as shown in Fig. 4 Moreover, for every formation and every angle, we have collected data from different distances from the center of the o-space ranging from 2 meters to 5 meters. Further, we considered different lighting conditions, backgrounds, partial occlusion, and cluttered background while collecting the data. The dataset consists of 4692 image frames in total, which are annotated with the four formations and the approach angles. We collected the images from a video stream using a RealSense \( {}^{3} \) camera mounted on a Double \( {2}^{4} \) robot. We make an \( {80}\%  - {20}\% \) split (for each formation) of the dataset for training and testing correspondingly. The experiments have been conducted with a single-core CPU with 8GB RAM (even lower memory is fine) without any graphics processing units (GPU). Thus, our system can be run on any embedded system or robotic hardware.

私たちはまた、対面型、L字型、並列型、三角形の4つの一般的なF型配置のローカルデータセットを作成しました。これらの各配置について、7つの異なる角度から4人の異なる被験者を用いてデータを収集しました \( - {0}^{ \circ  },{30}^{ \circ  },{60}^{ \circ  } \) 、\( {90}^{ \circ  }, - {30}^{ \circ  }, - {60}^{ \circ  } \) および \( - {90}^{ \circ  } \) 図4に示すように。さらに、各配置と各角度について、中心からの距離を2メートルから5メートルまで変えてデータを収集しました。加えて、異なる照明条件、背景、部分的な遮蔽、雑然とした背景も考慮しながらデータを収集しました。データセットは合計4692フレームの画像から構成されており、4つの配置とアプローチ角度で注釈付けされています。画像は、RealSense \( {}^{3} \) カメラを搭載したダブル \( {2}^{4} \) ロボットからのビデオストリームを用いて収集しました。各配置ごとにトレーニング用とテスト用にデータセットを \( {80}\%  - {20}\% \) に分割しています。実験は、グラフィックス処理ユニット(GPU)を使用せず、8GBのRAMを搭載したシングルコアCPU上で行いました。そのため、私たちのシステムはあらゆる組み込みシステムやロボットハードウェア上で動作可能です。

## B. Group membership classification results

## B. グループメンバーシップ分類結果

The CRF model for group and outlier detection is trained and tested using a subset of the EGO-GROUP dataset which contains 969 image frames, with an avg. of 3.6 persons per frame, where we used an \( {80} - {20}\% \) split for training and testing. We selected only those frames that contain the four F-formations and outliers to make the subset. The system displays an average accuracy of \( {91}\% \) in detecting the outlier, who are not part of the interacting group. Table I shows the evaluation metrics for the two membership classes. By analyzing the failure cases, we find the classifier makes errors in some frames where the outlier is in close proximity to the group and also has a very similar orientation. However, this can be mitigated by introducing temporal information in the classification. Overall, the detection of social groups before the prediction of F-formation should contribute to the robustness of the system.

グループおよび外れ値検出のためのCRFモデルは、969フレームの画像を含むEGO-GROUPデータセットのサブセットを用いて訓練およびテストされました。このサブセットは、平均3.6人の人物が各フレームに含まれるもので、訓練とテストには\( {80} - {20}\% \)の分割を使用しました。四つのF型配置と外れ値を含むフレームのみを選択してサブセットを作成しました。システムは外れ値を検出する際に平均精度\( {91}\% \)を示します。外れ値は、相互作用しているグループの一部ではない人物です。表Iは、二つのメンバーシップクラスの評価指標を示しています。失敗例を分析した結果、外れ値がグループに近接し、かつ非常に似た向きを持つフレームで誤分類が起きることがわかりました。ただし、これらは時間情報を導入することで軽減可能です。全体として、F型配置の予測前に社会的グループを検出することは、システムの堅牢性向上に寄与します。

## C. F-formation classification results

## C. F型配置分類結果

As mentioned earlier, we use the encoded skeletal key points vector to train a multi-class SVM classifier for F-formation detection. We compare the accuracy of our system with the state-of-the-art (rule-based) method in [12]. Table II summarizes the prediction accuracy of these two methods. Since the state-of-the-art system is originally tested for only a limited approach angle, i.e., \( - {90}^{ \circ  } \) and \( {90}^{ \circ  } \) for face-to-face, only -90 for side-by-side, and only -90 \( {}^{ \circ  } \) for L-shaped and finally - \( {90}^{ \circ  } \) and \( + {90}^{ \circ  } \) for triangle, this table represents the accuracy for the subset of data with these approach angles only. It is evident that our system improves the accuracy significantly (98% as compared to \( \mathbf{{69}\% } \) ) and achieves a near-perfect accuracy for all the formations with these approach angles. The main reason is that the rule-based method considers only head pose orientation features such as eyes and ears for writing the rules. The head pose/orientation detection is also limited to left, right, and front direction prediction for the rule-based, hence limiting its formation detection capability to a great extent. However, in our learning-based SVM method we consider full body orientation features as given by skeletal key points (e.g., Posenet DL model) and not limited to a fixed number of orientations. This also contributes to its spike in accuracy compared to the other method. Also, the rule-based method doesn't take into account partial occlusion and so it fails if the head and its features are not visible partially whereas our method overcomes that situation through rigorous learning.

前述の通り、我々はエンコードされた骨格のキーポイントベクターを用いて、多クラスSVM分類器を訓練し、F型配置の検出を行います。私たちのシステムの精度を、[12]の最先端(ルールベース)手法と比較します。表IIは、これら二つの方法の予測精度をまとめたものです。最先端のシステムは、もともと対面型に対してのみ、\( - {90}^{ \circ  } \)と\( {90}^{ \circ  } \)のアプローチ角度でテストされており、並列型は-90度のみ、L字型と三角形はそれぞれ\( {}^{ \circ  } \)と\( {90}^{ \circ  } \)および\( + {90}^{ \circ  } \)の角度でテストされています。この表は、これらのアプローチ角度に限定したデータのサブセットに対する精度を示しています。私たちのシステムは、精度を大幅に向上させ(98％対\( \mathbf{{69}\% } \))、これらのアプローチ角度においてほぼ完璧な精度を達成しています。主な理由は、ルールベースの方法が目と耳などの頭部姿勢の特徴のみを用いてルールを記述している点にあります。頭部の姿勢/向きの検出も、左、右、前方の予測に限定されており、そのため配置検出能力が制限されていました。一方、私たちの学習ベースのSVM手法では、骨格のキーポイント(例:Posenet DLモデル)によって示される全身の向きの特徴を考慮し、固定された方向数に限定されません。これにより、精度の向上に寄与しています。また、ルールベースの方法は部分的な遮蔽を考慮しておらず、頭部やその特徴が部分的に見えない場合は失敗しますが、私たちの方法は厳密な学習を通じてその状況を克服します。

TABLE II: F-formation prediction results for our method (learning based) and rule based method.

表II:私たちの方法(学習ベース)とルールベースの方法によるF型配置予測結果。

<table><tr><td>F-formation</td><td>Precision</td><td>Recall</td><td>\( \mathbf{{F1}} \)</td><td>Rule based method \( {}^{5} \)</td></tr><tr><td>face-to-face</td><td>0.99</td><td>0.99</td><td>0.99</td><td>0.68</td></tr><tr><td>side-by-side</td><td>0.95</td><td>0.99</td><td>0.97</td><td>0.94</td></tr><tr><td>L-shaped</td><td>1.00</td><td>0.96</td><td>0.98</td><td>0.49</td></tr><tr><td>triangle</td><td>1.00</td><td>1.00</td><td>1.00</td><td>0.63</td></tr><tr><td>\( \mathbf{{Avg}.} \)</td><td>0.98</td><td>0.98</td><td>0.98</td><td>0.69</td></tr></table>

<table><tbody><tr><td>F-formation</td><td>精度</td><td>再現率</td><td>\( \mathbf{{F1}} \)</td><td>ルールベースの方法 \( {}^{5} \)</td></tr><tr><td>対面</td><td>0.99</td><td>0.99</td><td>0.99</td><td>0.68</td></tr><tr><td>並列</td><td>0.95</td><td>0.99</td><td>0.97</td><td>0.94</td></tr><tr><td>L字型</td><td>1.00</td><td>0.96</td><td>0.98</td><td>0.49</td></tr><tr><td>三角形</td><td>1.00</td><td>1.00</td><td>1.00</td><td>0.63</td></tr><tr><td>\( \mathbf{{Avg}.} \)</td><td>0.98</td><td>0.98</td><td>0.98</td><td>0.69</td></tr></tbody></table>

TABLE III: Approximate approach angle prediction results.

表III:近似アプローチ角度予測結果。

<table><tr><td>Approximate angle</td><td>Precision</td><td>Recall</td><td>\( \mathbf{{F1}} \)</td></tr><tr><td>-90°</td><td>0.93</td><td>0.98</td><td>0.95</td></tr><tr><td>-60°</td><td>0.98</td><td>0.95</td><td>0.96</td></tr><tr><td>\( - {30}^{ \circ  } \)</td><td>0.98</td><td>0.99</td><td>0.98</td></tr><tr><td>\( {0}^{ \circ  } \)</td><td>0.94</td><td>0.99</td><td>0.97</td></tr><tr><td>\( {30}^{ \circ  } \)</td><td>0.97</td><td>0.89</td><td>0.93</td></tr><tr><td>\( {60}^{ \circ  } \)</td><td>0.93</td><td>0.94</td><td>0.94</td></tr><tr><td>\( {90}^{ \circ  } \)</td><td>0.97</td><td>0.95</td><td>0.96</td></tr><tr><td>\( \mathbf{{Avg}.} \)</td><td>0.96</td><td>0.96</td><td>0.96</td></tr></table>

<table><tbody><tr><td>近似角度</td><td>精度</td><td>再現率</td><td>\( \mathbf{{F1}} \)</td></tr><tr><td>-90°</td><td>0.93</td><td>0.98</td><td>0.95</td></tr><tr><td>-60°</td><td>0.98</td><td>0.95</td><td>0.96</td></tr><tr><td>\( - {30}^{ \circ  } \)</td><td>0.98</td><td>0.99</td><td>0.98</td></tr><tr><td>\( {0}^{ \circ  } \)</td><td>0.94</td><td>0.99</td><td>0.97</td></tr><tr><td>\( {30}^{ \circ  } \)</td><td>0.97</td><td>0.89</td><td>0.93</td></tr><tr><td>\( {60}^{ \circ  } \)</td><td>0.93</td><td>0.94</td><td>0.94</td></tr><tr><td>\( {90}^{ \circ  } \)</td><td>0.97</td><td>0.95</td><td>0.96</td></tr><tr><td>\( \mathbf{{Avg}.} \)</td><td>0.96</td><td>0.96</td><td>0.96</td></tr></tbody></table>

## D. Joint prediction of F-formation approach/joining angle

## D. F形成アプローチ/接近角の共同予測

The approach angle detection is necessary to understand the orientation of the F-formation with respect to the detecting camera/robot. This facilitates efficient navigation of the robot/device to join the formation at an appropriate spot (as discussed in Section III-D). Table III reports the result of approach angle prediction (Precision, Recall, and F1-score) for any F-formation using our learning-based method. The results show an acceptable accuracy of \( {96}\% \) for approach angle prediction alone. The problem of approach angle prediction in F-formation is novel to the best of our knowledge and has not been attended so far. The rule-based method in [12] has not considered approach angle prediction along with F-formation using their rule-based classifier as its head pose/orientation detection rules displays limited capability in detecting formations. However, we have used similar rules to implement a rule-based method. So, we compare these two methods among themselves in Table IV. The table contains the combined results for F-formation and approach angle prediction. As we can see clearly that our learning-based method has outperformed our rule-based method (similar to rule-based method [12]) with a high margin. A difference of 55% in overall accuracy establishes the efficacy of our learning-based method over rule-based counterpart.

アプローチ角度の検出は、F形成の向きを検出カメラ/ロボットに対して理解するために必要です。これにより、ロボットやデバイスが適切な場所で形成に参加するための効率的なナビゲーションが可能になります(第III-D節で説明)。表IIIは、我々の学習ベースの方法を用いた任意のF形成におけるアプローチ角予測の結果(精度、リコール、F1スコア)を報告しています。結果は、アプローチ角予測だけで許容できる精度\( {96}\% \)を示しています。F形成におけるアプローチ角予測の問題は、我々の知る限り新規であり、これまで対処されていません。文献[12]のルールベースの方法は、ルールベースの分類器を用いた頭部姿勢/向き検出ルールに限定されており、形成の検出能力が限られているため、アプローチ角予測を考慮していませんでした。しかし、我々は類似のルールを用いてルールベースの方法を実装しました。したがって、表IVではこれら二つの方法を比較しています。この表には、F形成とアプローチ角予測の結合結果が含まれています。明らかに、我々の学習ベースの方法は、ルールベースの方法([12]と類似)よりも大きな差で優れていることがわかります。全体の精度において55％の差があり、我々の学習ベースの方法の有効性を示しています。

---

\( {}^{3} \) https://www.intel.in/content/www/in/en/architecture-and-

\( {}^{3} \) https://www.intel.in/content/www/in/en/architecture-and-

technology/realsense-overview.html

technology/realsense-overview.html

\( {}^{4} \) https://www.doublerobotics.com/double2.html

\( {}^{4} \) https://www.doublerobotics.com/double2.html

\( {}^{5} \) For multi-class classification, we use weighted avg. F1 score and accuracy interchangeably.

\( {}^{5} \) 多クラス分類には、重み付け平均F1スコアと正確度を互換的に使用します。

---

TABLE IV: Accuracy of the joint prediction of F-formation and approach angle.

表IV:F形成とアプローチ角の共同予測の精度。

<table><tr><td>F-formation and angle</td><td>Our learning based method (joint prediction accuracy for F-formation and approach angle)</td><td>State-of-the- art (prediction accuracy for only F-formation)</td></tr><tr><td>face-to-face -90</td><td>80%</td><td>54%</td></tr><tr><td>face-to-face -60</td><td>86%</td><td>43%</td></tr><tr><td>face-to-face -30</td><td>96%</td><td>45%</td></tr><tr><td>face-to-face 0</td><td>100%</td><td>0%</td></tr><tr><td>face-to-face 30</td><td>98%</td><td>22%</td></tr><tr><td>face-to-face 60</td><td>95%</td><td>3%</td></tr><tr><td>face-to-face 90</td><td>70%</td><td>82%</td></tr><tr><td>side-by-side -90</td><td>91%</td><td>94%</td></tr><tr><td>side-by-side -60</td><td>82%</td><td>96%</td></tr><tr><td>side-by-side -30</td><td>88%</td><td>86%</td></tr><tr><td>side-by-side 0</td><td>96%</td><td>0%</td></tr><tr><td>side-by-side 30</td><td>83%</td><td>21%</td></tr><tr><td>side-by-side 60</td><td>88%</td><td>2%</td></tr><tr><td>side-by-side 90</td><td>97%</td><td>2%</td></tr><tr><td>L-shaped -90</td><td>99%</td><td>49%</td></tr><tr><td>L-shaped -60</td><td>98%</td><td>29%</td></tr><tr><td>L-shaped -30</td><td>82%</td><td>6%</td></tr><tr><td>L-shaped 0</td><td>90%</td><td>25%</td></tr><tr><td>L-shaped 30</td><td>81%</td><td>10%</td></tr><tr><td>L-shaped 60</td><td>93%</td><td>30%</td></tr><tr><td>L-shaped 90</td><td>83%</td><td>1%</td></tr><tr><td>triangle -90</td><td>97%</td><td>48%</td></tr><tr><td>triangle -60</td><td>100%</td><td>56%</td></tr><tr><td>triangle -30</td><td>90%</td><td>0%</td></tr><tr><td>triangle 0</td><td>100%</td><td>56%</td></tr><tr><td>triangle 30</td><td>100%</td><td>0%</td></tr><tr><td>triangle 60</td><td>99%</td><td>91%</td></tr><tr><td>triangle 90</td><td>97%</td><td>78%</td></tr><tr><td>\( \mathbf{{Avg}.} \)</td><td>92%</td><td>37%</td></tr></table>

<table><tbody><tr><td>F形成と角度</td><td>私たちの学習ベースの方法(F形成と接近角度の共同予測精度)</td><td>最先端(F形成のみの予測精度)</td></tr><tr><td>対面 -90</td><td>80%</td><td>54%</td></tr><tr><td>対面 -60</td><td>86%</td><td>43%</td></tr><tr><td>対面 -30</td><td>96%</td><td>45%</td></tr><tr><td>対面 0</td><td>100%</td><td>0%</td></tr><tr><td>対面 30</td><td>98%</td><td>22%</td></tr><tr><td>対面 60</td><td>95%</td><td>3%</td></tr><tr><td>対面 90</td><td>70%</td><td>82%</td></tr><tr><td>横並び -90</td><td>91%</td><td>94%</td></tr><tr><td>横並び -60</td><td>82%</td><td>96%</td></tr><tr><td>横並び -30</td><td>88%</td><td>86%</td></tr><tr><td>横並び 0</td><td>96%</td><td>0%</td></tr><tr><td>横並び 30</td><td>83%</td><td>21%</td></tr><tr><td>横並び 60</td><td>88%</td><td>2%</td></tr><tr><td>横並び 90</td><td>97%</td><td>2%</td></tr><tr><td>L字型 -90</td><td>99%</td><td>49%</td></tr><tr><td>L字型 -60</td><td>98%</td><td>29%</td></tr><tr><td>L字型 -30</td><td>82%</td><td>6%</td></tr><tr><td>L字型 0</td><td>90%</td><td>25%</td></tr><tr><td>L字型 30</td><td>81%</td><td>10%</td></tr><tr><td>L字型 60</td><td>93%</td><td>30%</td></tr><tr><td>L字型 90</td><td>83%</td><td>1%</td></tr><tr><td>三角形 -90</td><td>97%</td><td>48%</td></tr><tr><td>三角形 -60</td><td>100%</td><td>56%</td></tr><tr><td>三角形 -30</td><td>90%</td><td>0%</td></tr><tr><td>三角形 0</td><td>100%</td><td>56%</td></tr><tr><td>三角形 30</td><td>100%</td><td>0%</td></tr><tr><td>三角形 60</td><td>99%</td><td>91%</td></tr><tr><td>三角形 90</td><td>97%</td><td>78%</td></tr><tr><td>\( \mathbf{{Avg}.} \)</td><td>92%</td><td>37%</td></tr></tbody></table>

Table IV has some interesting results if we look at the individual rows. The rows in pink color gives us those formation with approach angle where rule-based method failed completely. For side-by-side 0 and face-to-face 0 (see Fig. 6a and 6b), the person nearer to the camera occludes the other person within the formation highly. So, the rule-based method, where only head pose orientation along with eyes and ears position is considered, fails in this case. But in our learning model, since we use the entire human body pose features for prediction (not simply relying on the head pose, orientation, and eye/ear positions) it gives excellent results. The triangle -30 and triangle 30 have similar occlusions of one of the members of the formation, hence the failure in rule-based method (see Fig. 6c and 6d). However, in these two cases, miss-classifications have taken place more than \( {50}\% \) of times, predicting them as face-to-face, side-by-side, or L-shaped in some cases due to occlusion of one member. This is clearly shown in the four cases of Fig. 6 The other cases with very low accuracy have similar reasons for occlusions and/or miss-classifications in the rule-based method. Fig. 7a and 7b show two cases of L-shaped formation where miss-classifications have taken place to a great extent predicting them as side-by-side or face-to-face.

表IVは、個々の行を見ればいくつかの興味深い結果を示しています。ピンク色の行は、ルールベースの方法が完全に失敗したアプローチ角度の形成を示しています。横並び0と正面0(図6aおよび6b参照)の場合、カメラに近い人物が他の人物を形成内で高度に遮蔽します。したがって、頭の姿勢の向きと目や耳の位置だけを考慮するルールベースの方法はこのケースでは失敗します。しかし、私たちの学習モデルは、頭の姿勢や向き、目・耳の位置だけでなく、全身の姿勢特徴を用いて予測を行うため、優れた結果を示します。三角形-30と三角形30は、形成の一員の遮蔽が類似しており、そのためルールベースの方法が失敗します(図6cおよび6d参照)。しかし、これらの二つの場合、誤分類が\( {50}\% \)回以上発生し、遮蔽のために正面、横並び、L字型のいずれかとして誤って予測されることがあります。これは図6の4つのケースで明らかです。その他の非常に精度の低いケースも、遮蔽や誤分類の理由は類似しています。図7aおよび7bは、L字型形成の二つのケースで、誤分類が大きく横並びや正面と予測された例を示しています。

![bo_d3ecmp3ef24c73cu42a0_5_980_210_612_639_0.jpg](images/bo_d3ecmp3ef24c73cu42a0_5_980_210_612_639_0.jpg)

Fig. 5: Triangle, L-shaped, Side-by-side and Face-to-face formations from \( - {90}^{ \circ  } \) approach angle with black marks in the floor to define the formation.

図5:アプローチ角度に基づく三角形、L字型、横並び、正面向きの形成と、床に黒いマークを付けて形成を示す。

![bo_d3ecmp3ef24c73cu42a0_5_943_1084_686_499_0.jpg](images/bo_d3ecmp3ef24c73cu42a0_5_943_1084_686_499_0.jpg)

Fig. 6: Occlusion of one of the member in a Side-by-side, Face-to-face and Triangle formations.

図6:横並び、正面向き、三角形形成における一方のメンバーの遮蔽。

![bo_d3ecmp3ef24c73cu42a0_5_944_1791_681_243_0.jpg](images/bo_d3ecmp3ef24c73cu42a0_5_944_1791_681_243_0.jpg)

Fig. 7: L-shaped formations.

図7:L字型形成。

The rows in blue (Table IV) color gives us the cases where the rule-based method outperforms the learning-based method. These are roughly the cases where the rules as stated in [12] best suit the conditions. These angles of viewing the F-formations are the best-case scenarios for the rule-based classifier. The other such cases where the rule-based method has quite a high accuracy are pertaining to the same fact. There is a decline of \( 6\% \) in the accuracy of our learning-based method while considering approach angle is due to the lesser number of training data samples when the dataset is divided among various approach angles for the different formations.

青色(表IV)の行は、ルールベースの方法が学習ベースの方法を上回るケースを示しています。これらは概ね、[12]に記載されたルールが最も適している条件に合致します。これらのF-formationの視角は、ルールベースの分類器にとって最良のシナリオです。ルールベースの方法が高い精度を示す他のケースも同じ理由によります。アプローチ角度を考慮した場合、私たちの学習ベースの方法の精度が\( 6\% \)低下するのは、異なる形成のためにデータセットを複数のアプローチ角度に分割した際の訓練データサンプル数が少ないことによるものです。

## V. CONCLUSIONS AND FUTURE WORKS

## V. 結論と今後の課題

This work presents a novel method to detect the formation of a social group of people, a.k.a., F-formation in real-time in a given scene. We can also detect outliers in the process, i.e., people who are visible but not part of the interacting group. This plays a key role in correct F-formation detection in a real-life crowded environment. Additionally, when a collocated robot plans to join the group it has to detect a pose for itself along with detecting the formation. Thus, we also provide the approach angle for the robot, which can help it to determine the final pose in a socially acceptable manner. Although considerable works are present in this domain, accuracy is limited due to the prevalent rule-driven methods. On the other hand, the existing learning-based approaches lack robustness under varied conditions of light, occlusion, and backgrounds. We have created a dataset catering to such scenarios. Our method of jointly detecting formation orientation and approach angle for a robot is not addressed in any of the existing literature to the best of our knowledge. The results show that our system outperforms the state-of-the-art method significantly in detecting F-formations correctly.

本研究は、リアルタイムでシーン内の社会的グループ、すなわちF-formationを検出する新しい方法を提案します。また、インタラクションに参加していないが見える人々などの異常値も検出可能です。これは、実生活の混雑した環境で正確なF-formation検出に重要な役割を果たします。さらに、コラボレーションロボットがグループに参加しようと計画する際には、自身の姿勢を検出するとともに、形成を認識する必要があります。したがって、ロボットのアプローチ角度も提供し、社会的に適切な最終姿勢を決定するのに役立てます。この分野には多くの研究がありますが、精度は従来のルール駆動型手法の普及により制限されています。一方、既存の学習ベースのアプローチは、光、遮蔽、背景の変化に対して堅牢性に欠けます。私たちは、そのようなシナリオに対応したデータセットを作成しました。私たちの方法は、ロボットのための形成の向きとアプローチ角度を共同で検出するものであり、現存する文献ではほとんど見られません。結果は、私たちのシステムが最先端の方法よりも大幅に優れており、F-formationの正確な検出において優れた性能を示しています。

An immediate extension of this work can be detecting other F-formations along with the 4 major types discussed in this article. This work also puts forward a novel idea of detecting the orientation of the formation to understand where should a robot navigate to join the group. But, the main limitation here is a human-aware navigation strategy to be stitched with this method so that the robot can navigate to join the formation after detecting the F-formation class and approach angle satisfactorily. Going further a human/user experience study is to be conducted for the entire system of detecting and joining a group by a robot. Additionally, we also intend to extend the system by detection of multiple groups in a scene along with outliers which can facilitate monitoring of new social norms in COVID-19 scenario. ACKNOWLEDGMENT

この研究の即時の拡張として、この記事で議論した4つの主要なタイプに加え、他のF-formationを検出することが考えられます。また、形成の向きを検出する新しいアイデアも提案しており、これによりロボットがどこにナビゲートすべきかを理解できます。ただし、主な制限は、人間を意識したナビゲーション戦略とこの方法を組み合わせることで、ロボットがF-formationのクラスとアプローチ角度を検出した後に形成に参加できるようにすることです。今後は、ロボットによるグループ検出と参加の全システムに対して、人間やユーザーの体験調査を行う予定です。さらに、シーン内の複数のグループと異常値を検出し、COVID-19の状況下での新しい社会的規範の監視を促進するシステムの拡張も計画しています。謝辞

We would like to thank Mr. Sai Krishna Pathi of rebro University to provide us the source code of his work that we utilized for comparing performance of our system. We would also like to thank Mr. Sayan Paul and Ms. Marichi Agarwal of TCS Research for helping us in collecting the data. REFERENCES

私たちは、パティ・サイ・クリシュナ氏(レブロ大学)に感謝します。彼の研究のソースコードを提供していただき、私たちのシステムの性能比較に利用しました。また、データ収集に協力してくれたSayan Paul氏とMarichi Agarwal氏(TCSリサーチ)にも感謝します。参考文献

[1] H. Bakul Barua, C. Sarkar, A. A. Kumar, A. Pal et al., "I can attend a meeting too! towards a human-like telepresence avatar robot to attend meeting on your behalf," arXiv preprint - https://arxiv.org/abs/2006.15647, 2020.

[1] H. Bakul Barua, C. Sarkar, A. A. Kumar, A. Pal ら、「私も会議に出席できる！人間のようなテレプレゼンスアバターロボットによる代理出席の実現へ」、arXivプレプリント - https://arxiv.org/abs/2006.15647、2020年。

[2] A. Sau, R. D. Roychoudhury, H. B. Barua, C. Sarkar, S. Paul, B. Bhowmick, A. Pal, and B. P, "Demo: Edge-centric telepresence avatar robot for geographically distributed environment," arXiv preprint

[2] A. Sau, R. D. Roychoudhury, H. B. Barua, C. Sarkar, S. Paul, B. Bhowmick, A. Pal ら、「デモ:地理的に分散した環境向けのエッジ中心のテレプレゼンスアバターロボット」、arXivプレプリント

- https://arxiv.org/abs/2007.12990, 2020.

- https://arxiv.org/abs/2007.12990、2020年。

[3] P. Pramanick and C. Sarkar, "Defatigue: Online non-intrusive fatigue detection by a robot co-worker," in 2018 27th IEEE International Symposium on Robot and Human Interactive Communication (RO- \( {MAN}) \) . IEEE,2018, pp. 1129-1136.

[3] P. Pramanick と C. Sarkar、「Defatigue:ロボット協働者によるオンラインの非侵襲的疲労検出」、2018年の第27回IEEEロボットと人間のインタラクション通信シンポジウム(RO-\( {MAN}) \))。IEEE、2018年、pp. 1129-1136。

[4] S. K. Pathi, A. Kristoffersson, A. Kiselev, and A. Loutfi, "F-formations for social interaction in simulation using virtual agents and mobile robotic telepresence systems," Multimodal Technologies and Interaction, vol. 3, no. 4, p. 69, 2019.

[4] S. K. Pathi、A. Kristoffersson、A. Kiselev、A. Loutfi、「仮想エージェントと移動ロボットテレプレゼンスシステムを用いたシミュレーションにおける社会的相互作用のためのF-formation」、マルチモーダル技術とインタラクション、vol. 3、no. 4、p. 69、2019年。

[5] T. Kruse, A. K. Pandey, R. Alami, and A. Kirsch, "Human-aware robot navigation: A survey," Robotics and Autonomous Systems, vol. 61, no. 12, pp. 1726-1743, 2013.

[5] T. Kruse、A. K. Pandey、R. Alami、A. Kirsch、「人間を意識したロボットナビゲーション:調査」、ロボティクスと自律システム、vol. 61、no. 12、pp. 1726-1743、2013年。

[6] K. Charalampous, I. Kostavelis, and A. Gasteratos, "Recent trends in social aware robot navigation: A survey," Robotics and Autonomous Systems, vol. 93, pp. 85-104, 2017.

[6] K. Charalampous、I. Kostavelis、A. Gasteratos、「社会的意識を持つロボットナビゲーションの最新動向:調査」、ロボティクスと自律システム、vol. 93、pp. 85-104、2017年。

[7] A. Kendon, Conducting interaction: Patterns of behavior in focused encounters. CUP Archive, 1990, vol. 7.

[7] A. Kendon、「相互作用の実践:焦点を当てた出会いにおける行動パターン」、CUPアーカイブ、1990年、vol. 7。

[8] G. Papandreou, T. Zhu, N. Kanazawa, A. Toshev, J. Tompson, C. Bregler, and K. Murphy, "Towards accurate multi-person pose estimation in the wild," in Proceedings of the IEEE Conference on Computer Vision and Pattern Recognition, 2017, pp. 4903-4911.

[8] G. Papandreou、T. Zhu、N. Kanazawa、A. Toshev、J. Tompson、C. Bregler、K. Murphy、「野外での多人数姿勢推定の精度向上に向けて」、IEEEコンピュータビジョンとパターン認識会議の proceedings、2017年、pp. 4903-4911。

[9] G. Papandreou, T. Zhu, L.-C. Chen, S. Gidaris, J. Tompson, and K. Murphy, "Personlab: Person pose estimation and instance segmentation with a bottom-up, part-based, geometric embedding model," in Proceedings of the European Conference on Computer Vision (ECCV), 2018, pp. 269-286.

[9] G. Papandreou、T. Zhu、L.-C. Chen、S. Gidaris、J. Tompson、K. Murphy、「Personlab:ボトムアップ、パーツベースの幾何学的埋め込みモデルを用いた人物姿勢推定とインスタンスセグメンテーション」、欧州コンピュータビジョン会議(ECCV)の proceedings、2018年、pp. 269-286。

[10] F. Setti, C. Russell, C. Bassetti, and M. Cristani, "F-formation detection: Individuating free-standing conversational groups in images," PloS one, vol. 10, no. 5, p. e0123783, 2015.

[10] F. Setti、C. Russell、C. Bassetti、M. Cristani、「F-formation検出:画像内の自由立ち会話グループの個別化」、PloS one、vol. 10、no. 5、p. e0123783、2015年。

[11] S. Krishna, A. Kiselev, and A. Loutfi, "Towards a method to detect f-formations in real-time to enable social robots to join groups," in ECCE Workshop 2017:: Robots in Contexts: Human-Robot Interaction as Physically and Socially Embedded conducted at Umeå University, Sweden, 19 September, 2017. Umeå University, 2017.

[11] S. Krishna、A. Kiselev、A. Loutfi、「社会的ロボットがグループに参加できるようにリアルタイムでF-formationを検出する方法の模索」、ECCEワークショップ2017:文脈におけるロボット:物理的および社会的に埋め込まれた人間-ロボット相互作用、スウェーデン・ウメオ大学にて、2017年9月19日。ウメオ大学、2017年。

[12] S. K. Pathi, A. Kiselev, and A. Loutfi, "Estimating f-formations for mobile robotic telepresence," in Proceedings of the Companion of the 2017 ACM/IEEE International Conference on Human-Robot Interaction, 2017, pp. 255-256.

[12] S. K. Pathi、A. Kiselev、A. Loutfi、「移動ロボットテレプレゼンスのためのF-formationの推定」、2017年のACM/IEEE国際人間-ロボット相互作用会議のサブセッション proceedings、2017年、pp. 255-256。

[13] H. Hedayati, D. Szafir, and S. Andrist, "Recognizing f-formations in the open world," in 2019 14th ACM/IEEE International Conference on Human-Robot Interaction (HRI). IEEE, 2019, pp. 558-559.

[13] H. Hedayati、D. Szafir、S. Andrist、「オープンワールドにおけるF-formationの認識」、2019年の第14回ACM/IEEE国際人間-ロボット相互作用会議(HRI)。IEEE、2019年、pp. 558-559。

[14] M. Aghaei, M. Dimiccoli, and P. Radeva, "With whom do i interact? detecting social interactions in egocentric photo-streams," in 2016 23rd International Conference on Pattern Recognition (ICPR). IEEE, 2016, pp. 2959-2964.

[14] M. Aghaei、M. Dimiccoli、P. Radeva、「誰と交流しているのか？自己中心的な写真ストリームにおける社会的相互作用の検出」、2016年の第23回国際パターン認識会議(ICPR)。IEEE、2016年、pp. 2959-2964。

[15] S. Alletto, G. Serra, S. Calderara, F. Solera, and R. Cucchiara, "From ego to nos-vision: Detecting social relationships in first-person views," in Proceedings of the IEEE Conference on Computer Vision and Pattern Recognition Workshops, 2014, pp. 580-585.

[15] S. Alletto, G. Serra, S. Calderara, F. Solera, and R. Cucchiara, "エゴからノーズビジョンへ:一人称視点における社会的関係の検出," in Proceedings of the IEEE Conference on Computer Vision and Pattern Recognition Workshops, 2014, pp. 580-585.

[16] M. Vázquez, A. Steinfeld, and S. E. Hudson, "Parallel detection of conversational groups of free-standing people and tracking of their lower-body orientation," in 2015 IEEE/RSJ International Conference on Intelligent Robots and Systems (IROS). IEEE, 2015, pp. 3010-3017.

[16] M. Vázquez, A. Steinfeld, and S. E. Hudson, "自由立ちの人々の会話グループの並列検出と下半身の向きの追跡," in 2015 IEEE/RSJ International Conference on Intelligent Robots and Systems (IROS). IEEE, 2015, pp. 3010-3017.

[17] L. Bazzani, M. Cristani, D. Tosato, M. Farenzena, G. Paggetti, G. Menegaz, and V. Murino, "Social interactions by visual focus of attention in a three-dimensional environment," Expert Systems, vol. 30, no. 2, pp. 115-127, 2013.

[17] L. Bazzani, M. Cristani, D. Tosato, M. Farenzena, G. Paggetti, G. Menegaz, and V. Murino, "三次元環境における視覚的焦点による社会的相互作用," Expert Systems, vol. 30, no. 2, pp. 115-127, 2013.

[18] R. Mead, A. Atrash, and M. J. Matarić, "Automated proxemic feature extraction and behavior recognition: Applications in human-robot interaction," International Journal of Social Robotics, vol. 5, no. 3, pp. 367-378, 2013.

[18] R. Mead, A. Atrash, and M. J. Matarić, "自動化された近接距離特徴抽出と行動認識:人間とロボットの相互作用への応用," International Journal of Social Robotics, vol. 5, no. 3, pp. 367-378, 2013.

[19] H. Hedayati, D. Szafir, and J. Kennedy, "Comparing f-formations between humans and on-screen agents," in Extended Abstracts of the 2020 CHI Conference on Human Factors in Computing Systems, 2020, pp. 1-9.

[19] H. Hedayati, D. Szafir, and J. Kennedy, "人間とスクリーン上のエージェント間のFフォーメーションの比較," in Extended Abstracts of the 2020 CHI Conference on Human Factors in Computing Systems, 2020, pp. 1-9.

[20] S. K. Pathi, A. Kiselev, A. Kristoffersson, D. Repsilber, and A. Loutfi, "A novel method for estimating distances from a robot to humans using egocentric rgb camera," Sensors, vol. 19, no. 14, p. 3142, 2019.

[20] S. K. Pathi, A. Kiselev, A. Kristoffersson, D. Repsilber, and A. Loutfi, "自己中心RGBカメラを用いたロボットと人間の距離推定の新手法," Sensors, vol. 19, no. 14, p. 3142, 2019.

[21] P. A. Ruijten and R. H. Cuijpers, "Stopping distance for a robot approaching two conversating persons," in 2017 26th IEEE International Symposium on Robot and Human Interactive Communication (ROMAN). IEEE, 2017, pp. 224-229.

[21] P. A. Ruijten and R. H. Cuijpers, "会話中の二人の人間に近づくロボットの停止距離," in 2017 26th IEEE International Symposium on Robot and Human Interactive Communication (ROMAN). IEEE, 2017, pp. 224-229.