# Do As I Can, Not As I Say: Grounding Language in Robotic Affordances

# できることを行い、言うことを行わない:ロボットのアフォーダンスに基づく言語の基礎付け

\( {}^{1} \) Michael Ahn*, Anthony Brohan*, Noah Brown*, Yevgen Chebotar*, Omar Cortes*, Byron David*,

\( {}^{1} \) Michael Ahn*、Anthony Brohan*、Noah Brown*、Yevgen Chebotar*、Omar Cortes*、Byron David*、

Chelsea Finn \( {}^{ * } \) , Chuyuan \( {\mathrm{{Fu}}}^{ \dagger  } \) , Keerthana Gopalakrishnan \( {}^{ * } \) , Karol Hausman \( {}^{ * } \) , Alex Herzog \( {}^{ \dagger  } \) ,

Chelsea Finn \( {}^{ * } \) 、Chuyuan \( {\mathrm{{Fu}}}^{ \dagger  } \) 、Keerthana Gopalakrishnan \( {}^{ * } \) 、Karol Hausman \( {}^{ * } \) 、Alex Herzog \( {}^{ \dagger  } \) 、

Daniel \( {\mathrm{{Ho}}}^{ \dagger  } \) , Jasmine \( {\mathrm{{Hsu}}}^{ * } \) , Julian Ibarz \( {}^{ * } \) , Brian Ichter \( {}^{ * } \) , Alex Irpan \( {}^{ * } \) , Eric Jang \( {}^{ * } \) ,

Daniel \( {\mathrm{{Ho}}}^{ \dagger  } \) 、Jasmine \( {\mathrm{{Hsu}}}^{ * } \) 、Julian Ibarz \( {}^{ * } \) 、Brian Ichter \( {}^{ * } \) 、Alex Irpan \( {}^{ * } \) 、Eric Jang \( {}^{ * } \) 、

Rosario Jauregui Ruano*, Kyle Jeffrey*, Sally Jesmonth*, Nikhil J Joshi*, Ryan Julian*,

Rosario Jauregui Ruano*、Kyle Jeffrey*、Sally Jesmonth*、Nikhil J Joshi*、Ryan Julian*、

Dmitry Kalashnikov*, Yuheng Kuang*, Kuang-Huei Lee*, Sergey Levine*, Yao Lu*, Linda Luu*,

Dmitry Kalashnikov*、Yuheng Kuang*、Kuang-Huei Lee*、Sergey Levine*、Yao Lu*、Linda Luu*、

Carolina Parada*, Peter Pastor \( {}^{ \dagger  } \) , Jornell Quiambao*, Kanishka Rao \( {}^{ * } \) , Jarek Rettinghouse \( {}^{ * } \) ,

Carolina Parada*、Peter Pastor \( {}^{ \dagger  } \) 、Jornell Quiambao*、Kanishka Rao \( {}^{ * } \) 、Jarek Rettinghouse \( {}^{ * } \) 、

Diego Reyes*, Pierre Sermanet*, Nicolas Sievers*, Clayton Tan*, Alexander Toshev*,

Diego Reyes*、Pierre Sermanet*、Nicolas Sievers*、Clayton Tan*、Alexander Toshev*、

Vincent Vanhoucke*, Fei Xia*, Ted Xiao*, Peng Xu*, Sichun Xu*, Mengyuan Yan \( {}^{ \dagger  } \) , Andy Zeng \( {}^{ * } \)

Vincent Vanhoucke*、Fei Xia*、Ted Xiao*、Peng Xu*、Sichun Xu*、Mengyuan Yan \( {}^{ \dagger  } \) 、Andy Zeng \( {}^{ * } \)

## *Robotics at Google, \( {}^{ \dagger  } \) Everyday Robots

## *Googleのロボティクス、\( {}^{ \dagger  } \) Everyday Robots

Abstract: Large language models can encode a wealth of semantic knowledge about the world. Such knowledge could be extremely useful to robots aiming to act upon high-level, temporally extended instructions expressed in natural language. However, a significant weakness of language models is that they lack real-world experience, which makes it difficult to leverage them for decision making within a given embodiment. For example, asking a language model to describe how to clean a spill might result in a reasonable narrative, but it may not be applicable to a particular agent, such as a robot, that needs to perform this task in a particular environment. We propose to provide real-world grounding by means of pretrained skills, which are used to constrain the model to propose natural language actions that are both feasible and contextually appropriate. The robot can act as the language model's "hands and eyes," while the language model supplies high-level semantic knowledge about the task. We show how low-level skills can be combined with large language models so that the language model provides high-level knowledge about the procedures for performing complex and temporally extended instructions, while value functions associated with these skills provide the grounding necessary to connect this knowledge to a particular physical environment. We evaluate our method on a number of real-world robotic tasks, where we show the need for real-world grounding and that this approach is capable of completing long-horizon, abstract, natural language instructions on a mobile manipulator. The project's website, the video, and open sourced code in a tabletop domain can be found at say-can. github. io.

概要:大規模言語モデルは世界に関する豊富な意味的知識を符号化できる。このような知識は、自然言語で表現された高レベルで時間的に拡張された指示に基づいて行動しようとするロボットにとって非常に有用である可能性がある。しかし、言語モデルの大きな弱点は、実世界の経験が欠如していることであり、これにより、特定の身体を持つエージェント内での意思決定に活用することが難しい。例えば、言語モデルにこぼれた液体を掃除する方法を説明させると、合理的な物語になるかもしれないが、特定の環境でこの作業を行う必要があるロボットのようなエージェントには適用できない場合がある。我々は、事前学習されたスキルを用いて実世界の基盤付けを行うことを提案し、モデルが実行可能で文脈に適した自然言語の行動を提案できるよう制約をかける。ロボットは言語モデルの「手と目」として機能し、言語モデルはタスクに関する高レベルの意味的知識を提供する。低レベルのスキルと大規模言語モデルを組み合わせることで、言語モデルは複雑で時間的に拡張された指示を実行する手順に関する高レベルの知識を提供し、これらのスキルに関連付けられた価値関数がこの知識を特定の物理環境に結びつけるための基盤付けを可能にする。我々の方法を実世界のロボットタスクで評価し、実世界の基盤付けの必要性と、このアプローチが長期的で抽象的な自然言語指示を移動型マニピュレータで完遂できることを示す。プロジェクトのウェブサイト、ビデオ、テーブルトップドメインのオープンソースコードはsay-can.github.ioで閲覧できる。

![bo_d3eb5nk601uc738ioai0_0_319_1474_1160_353_0.jpg](images/bo_d3eb5nk601uc738ioai0_0_319_1474_1160_353_0.jpg)

Figure 1: LLMs have not interacted with their environment and observed the outcome of their responses, and thus are not grounded in the world. SayCan grounds LLMs via value functions of pretrained skills, allowing them to execute real-world, abstract, long-horizon commands on robots.

図1:LLMsは環境と相互作用し、その応答の結果を観察していないため、世界に基づいていない。SayCanは、事前学習されたスキルの価値関数を通じてLLMsを基盤付けし、ロボット上で実世界の抽象的で長期的なコマンドを実行できるようにしている。

## 1 Introduction

## 1 はじめに

Recent progress in training large language models (LLMs) has led to systems that can generate complex text based on prompts, answer questions, or even engage in dialogue on a wide range of topics. These models absorb vast quantities of knowledge from text corpora mined from the web, and we might wonder whether knowledge of everyday tasks that is encoded in such models can be used by robots to perform complex tasks in the real world. But how can embodied agents extract and harness the knowledge of LLMs for physically grounded tasks?

近年の大規模言語モデル(LLMs)の訓練の進展により、プロンプトに基づいて複雑なテキストを生成したり、質問に答えたり、さまざまなトピックについて対話したりできるシステムが登場している。これらのモデルは、ウェブから抽出された大量のテキストコーパスから知識を吸収しており、こうしたモデルにエンコードされた日常のタスクに関する知識をロボットが実世界で複雑なタスクを実行するために利用できるかどうか疑問に思うこともある。しかし、身体を持つエージェントは、LLMsの知識をどのように抽出し、物理的に基盤付けて活用できるのだろうか？

---

\( {}^{1} \) Authors listed in alphabetical order. Contributions in Appendix B.

\( {}^{1} \) 著者はアルファベット順に記載。貢献は付録Bに記載。

Corresponding emails: \{ichter, xiafei, karolhausman\}@google.com.

連絡先メール:\{ichter, xiafei, karolhausman\}@google.com。

---

This question poses a major challenge. LLMs are not grounded in the physical world and they do not observe the consequences of their generations on any physical process [1]. This can lead LLMs to not only make mistakes that seem unreasonable or humorous to people, but also to interpret instructions in ways that are nonsensical or unsafe for a particular physical situation. Figure 1 shows an example - a kitchen robot capable of executing skills such as "pick up the sponge" or "go to the table" may be asked for help cleaning up a spill ("I spilled my drink, can you help?"). A language model may respond with a reasonable narrative that is not feasible or useful for the robot. "You could try using a vacuum cleaner" is impossible if there is no vacuum in the scene or if the robot is incapable of using one. With prompt engineering, a LLM may be capable of splitting the high-level instruction into sub-tasks, but it cannot do so without the context of what the robot is capable of given its abilities and the current state of the robot and the environment.

この問題は大きな課題を提起します。LLMsは物理的な世界に基づいておらず、彼らの生成結果が物理的な過程に与える影響を観察しません[1]。これにより、LLMsは人々にとって不合理または面白く見える誤りを犯すだけでなく、特定の物理的状況にとって意味のないまたは安全でない方法で指示を解釈することもあります。図1はその例を示しています。例えば、「スポンジを拾う」や「テーブルに行く」といったスキルを実行できるキッチンロボットに、「こぼしたものを片付けてほしい」(「飲み物をこぼしたので手伝ってくれる？」)と頼むことがあります。言語モデルは、ロボットにとって実現不可能または役に立たない合理的な物語で応答することがあります。「掃除機を使ってみてはどうですか」といった提案は、シーンに掃除機がない場合や、ロボットが掃除機を使えない場合には不可能です。プロンプトエンジニアリングにより、LLMは高レベルの指示をサブタスクに分割できるかもしれませんが、ロボットの能力や現在の状態、環境のコンテキストなしにはそれを行うことはできません。

Motivated by this example, we study the problem of how to extract the knowledge in LLMs for enabling an embodied agent, such as a robot, to follow high-level textual instructions. The robot is equipped with a repertoire of learned skills for "atomic" behaviors that are capable of low-level visuomotor control. We make use of the fact that, in addition to asking the LLM to simply interpret an instruction, we can use it to score the likelihood that an individual skill makes progress towards completing the high-level instruction. Then, if each skill has an affordance function that quantifies how likely it is to succeed from the current state (such as a learned value function), its value can be used to weight the skill's likelihood. In this way, the LLM describes the probability that each skill contributes to completing the instruction, and the affordance function describes the probability that each skill will succeed - combining the two provides the probability that each skill will perform the instruction successfully. The affordance functions make the LLM aware of the current scene, and constraining the completions to the skill descriptions makes the LLM aware of the robot's capabilities. Furthermore, this combination results in a fully explainable sequence of steps that the robot will execute to accomplish an instruction - an interpretable plan that is expressed through language.

この例に触発されて、私たちはLLMsに蓄積された知識を抽出し、ロボットのような具現化されたエージェントが高レベルのテキスト指示に従うことを可能にする問題を研究します。ロボットは、「原子」レベルの行動を実行できる学習済みスキルのレパートリーを備えており、これらは低レベルの視覚運動制御を可能にします。私たちは、LLMに指示を単に解釈させるだけでなく、個々のスキルが高レベルの指示の完了に向けて進展している可能性を評価するためにスコア付けに利用できることを利用します。次に、各スキルが現在の状態から成功する可能性を定量化するアフォーダンス関数(学習済みの価値関数など)を持つ場合、その値を用いてスキルの成功確率に重み付けを行います。この方法により、LLMは各スキルが指示の完了に寄与する確率を記述し、アフォーダンス関数は各スキルが成功する確率を示します。これら二つを組み合わせることで、各スキルが指示を成功裏に実行する確率を提供します。アフォーダンス関数は、シーンの現在の状況をLLMに認識させ、スキルの記述に制約をかけることで、ロボットの能力をLLMに理解させます。さらに、この組み合わせにより、ロボットが指示を達成するために実行する一連のステップを完全に説明可能なシーケンスとして生成できる—言語を通じて表現された解釈可能な計画となります。

Our method, SayCan, extracts and leverages the knowledge within LLMs in physically-grounded tasks. The LLM (Say) provides a task-grounding to determine useful actions for a high-level goal and the learned affordance functions (Can) provide a world-grounding to determine what is possible to execute upon the plan. We use reinforcement learning (RL) as a way to learn language-conditioned value functions that provide affordances of what is possible in the world. We evaluate the proposed approach on 101 real-world robotic tasks that involve a mobile robot accomplishing a large set of language instructions in a real kitchen in a zero-shot fashion. Our experiments validate that SayCan can execute temporally-extended, abstract instructions. Grounding the LLM in the real-world via affordances nearly doubles the performance over the non-grounded baselines. Additionally, by evaluating the performance of the system with different LLMs, we show that a robot's performance can be improved simply by enhancing the underlying language model.

私たちの手法、SayCanは、物理的に基づくタスクにおいてLLMs内の知識を抽出し活用します。LLM(Say)は高レベルの目標に役立つ行動を決定するためのタスク・グラウンディングを提供し、学習済みのアフォーダンス関数(Can)は計画に基づいて何が可能かを判断するための世界・グラウンディングを提供します。私たちは、強化学習(RL)を用いて、世界で何が可能かを示すアフォーダンスを提供する言語条件付きの価値関数を学習します。提案手法を、実際のキッチンで多くの言語指示をゼロショットで達成する移動ロボットを対象とした101の実世界ロボットタスクで評価しました。実験により、SayCanは時間的に拡張された抽象的な指示を実行できることが検証されました。アフォーダンスを通じてLLMを実世界にグラウンディングさせることで、非グラウンディングのベースラインと比べて性能がほぼ倍増します。さらに、異なるLLMを用いたシステムの性能評価により、基盤となる言語モデルを強化するだけでロボットの性能を向上させることができることも示しています。

## 2 Preliminaries

## 2 前提知識

Large Language Models. Language models seek to model the probability \( p\left( W\right) \) of a text \( W = \left\{  {{w}_{0},{w}_{1},{w}_{2},\ldots ,{w}_{n}}\right\} \) , a sequence of strings \( w \) . This is generally done through factorizing the probability via the chain rule to be \( p\left( W\right)  = {\Pi }_{j = 0}^{n}p\left( {{w}_{j} \mid  {w}_{ < j}}\right) \) , such that each successive string is predicted from the previous. Recent breakthroughs initiated by neural network-based Attention architectures [2] have enabled efficient scaling of so-called Large Language Models (LLMs). Such models include Transformers [2], BERT [3], T5 [4], GPT-3 [5], Gopher [6], LAMDA [7], FLAN [8], and PaLM [9], each showing increasingly large capacity (billions of parameters and terabytes of text) and subsequent ability to generalize across tasks.

大規模言語モデル。言語モデルは、テキスト\( p\left( W\right) \)の確率\( W = \left\{  {{w}_{0},{w}_{1},{w}_{2},\ldots ,{w}_{n}}\right\} \)、文字列のシーケンス\( w \)の確率をモデル化しようとします。これは一般に、連鎖ルールを用いて確率を分解し、\( p\left( W\right)  = {\Pi }_{j = 0}^{n}p\left( {{w}_{j} \mid  {w}_{ < j}}\right) \)、各次の文字列を前の文字列から予測する形で行われます。近年、ニューラルネットワークに基づくアテンションアーキテクチャ[2]によるブレークスルーにより、いわゆる大規模言語モデル(LLMs)の効率的なスケーリングが可能になっています。これらのモデルには、Transformers[2]、BERT[3]、T5[4]、GPT-3[5]、Gopher[6]、LAMDA[7]、FLAN[8]、PaLM[9]などがあり、それぞれがより大きな容量(数十億のパラメータやテラバイトのテキスト)を持ち、タスク間の一般化能力を示しています。

In this work, we utilize the vast semantic knowledge contained in LLMs to determine useful tasks for solving high-level instructions.

本研究では、LLMsに含まれる膨大な意味的知識を利用して、高レベルの指示を解決するための有用なタスクを決定します。

Value functions and RL. Our goal is to be able to accurately predict whether a skill (given by a language command) is feasible at a current state. We use temporal-difference-based (TD) reinforcement learning to accomplish this goal. In particular, we define a Markov decision process (MDP) \( \mathcal{M} = \left( {\mathcal{S},\mathcal{A}, P, R,\gamma }\right) \) , where \( \mathcal{S} \) and \( \mathcal{A} \) are state and action spaces, \( P : \mathcal{S} \times  \mathcal{A} \times  \mathcal{S} \rightarrow  {\mathbb{R}}_{ + } \) is a state-transition probability function, \( R : \mathcal{S} \times  \mathcal{A} \rightarrow  \mathbb{R} \) is a reward function and \( \gamma \) is a discount factor. The goal of TD methods is to learn state or state-action value functions (Q-function) \( {Q}^{\pi }\left( {s, a}\right) \) , which represents the discounted sum of rewards when starting from state \( s \) and action \( a \) , followed by the actions produced by the policy \( \pi \) , i.e. \( {Q}^{\pi }\left( {s, a}\right)  = {\mathbb{E}}_{a \sim  \pi \left( {a \mid  s}\right) }\mathop{\sum }\limits_{t}R\left( {{s}_{t},{a}_{t}}\right) \) . The Q-function, \( {Q}^{\pi }\left( {s, a}\right) \) can be learned via approximate dynamic programming approaches that optimize the following loss: \( {L}_{TD}\left( \theta \right)  = {\mathbb{E}}_{\left( {s, a,{s}^{\prime }}\right)  \sim  \mathcal{D}}\left\lbrack  {R\left( {s, a}\right)  + \gamma {\mathbb{E}}_{{a}^{ * } \sim  \pi }{Q}_{\theta }^{\pi }\left( {{s}^{\prime },{a}^{ * }}\right)  - {Q}_{\theta }^{\pi }\left( {s, a}\right) }\right\rbrack \) , where \( \mathcal{D} \) is the dataset of states and actions and \( \theta \) are the parameters of the Q-function.

価値関数とRL。私たちの目標は、言語コマンドによって与えられたスキルが現在の状態で実行可能かどうかを正確に予測できるようにすることです。この目的を達成するために、時間差分(TD)に基づく強化学習を使用します。特に、マルコフ決定過程(MDP)\( \mathcal{M} = \left( {\mathcal{S},\mathcal{A}, P, R,\gamma }\right) \)を定義し、\( \mathcal{S} \)と\( \mathcal{A} \)を状態空間と行動空間とし、\( P : \mathcal{S} \times  \mathcal{A} \times  \mathcal{S} \rightarrow  {\mathbb{R}}_{ + } \)を状態遷移確率関数、\( R : \mathcal{S} \times  \mathcal{A} \rightarrow  \mathbb{R} \)を報酬関数、\( \gamma \)を割引因子とします。TD法の目的は、状態または状態-行動価値関数(Q関数)\( {Q}^{\pi }\left( {s, a}\right) \)を学習することであり、これは状態\( s \)と行動\( a \)から始めたときの割引された報酬の合計を表します。その後、方針\( \pi \)によって生成される行動に続き、\( {Q}^{\pi }\left( {s, a}\right)  = {\mathbb{E}}_{a \sim  \pi \left( {a \mid  s}\right) }\mathop{\sum }\limits_{t}R\left( {{s}_{t},{a}_{t}}\right) \)となります。Q関数、\( {Q}^{\pi }\left( {s, a}\right) \)は、次の損失を最適化する近似動的計画法アプローチを通じて学習できます:\( {L}_{TD}\left( \theta \right)  = {\mathbb{E}}_{\left( {s, a,{s}^{\prime }}\right)  \sim  \mathcal{D}}\left\lbrack  {R\left( {s, a}\right)  + \gamma {\mathbb{E}}_{{a}^{ * } \sim  \pi }{Q}_{\theta }^{\pi }\left( {{s}^{\prime },{a}^{ * }}\right)  - {Q}_{\theta }^{\pi }\left( {s, a}\right) }\right\rbrack \)、ここで\( \mathcal{D} \)は状態と行動のデータセット、\( \theta \)はQ関数のパラメータです。

In this work, we utilize TD-based methods to learn said value function that is additionally conditioned on the language command and utilize those to determine whether a given command is feasible from the given state. It is worth noting that in the undiscounted, sparse reward case, where the agent receives the reward of 1.0 at the end of the episode if it was successful and 0.0 otherwise, the value function trained via RL corresponds to an affordance function [10] that specifies whether a skill is possible in a given state. We leverage that intuition in our setup and express affordances via value functions of sparse reward tasks.

本研究では、TDに基づく手法を用いて、言語コマンドに条件付けされた価値関数を学習し、それを用いて与えられたコマンドが現在の状態から実行可能かどうかを判断します。特に、割引されない疎報酬の場合、エピソードの最後に成功した場合に報酬が1.0、それ以外は0.0を受け取るとき、RLを通じて訓練された価値関数は、特定の状態でスキルが可能かどうかを示すアフォーダンス関数[10]に対応します。この直感を私たちの設定で活用し、疎報酬タスクの価値関数を用いてアフォーダンスを表現します。

## 3 SayCan: Do As I Can, Not As I Say

## 3 SayCan:私ができることをやる、私が言うことをやるのではない

Problem Statement. Our system receives a user-provided natural language instruction \( i \) that describes a task that the robot should execute. The instruction can be long, abstract, or ambiguous. We also assume that we are given a set of skills \( \Pi \) , where each skill \( \pi  \in  \Pi \) performs a short task, such as picking up a particular object, and comes with a short language description \( {\ell }_{\pi } \) (e.g.,"find a sponge") and an affordance function \( p\left( {{c}_{\pi } \mid  s,{\ell }_{\pi }}\right) \) , which indicates the probability of \( c \) -ompleting the skill with description \( {\ell }_{\pi } \) successfully from state \( s \) . Intuitively, \( p\left( {{c}_{\pi } \mid  s,{\ell }_{\pi }}\right) \) means "if I ask the robot to do \( {\ell }_{\pi } \) , will it do it?". In RL terminology, \( p\left( {{c}_{\pi } \mid  s,{\ell }_{\pi }}\right) \) is the value function for the skill if we take the reward to be 1 for successful completion and 0 otherwise.

問題設定。私たちのシステムは、ユーザーから提供された自然言語の指示\( i \)を受け取り、それはロボットが実行すべきタスクを記述しています。指示は長く、抽象的または曖昧な場合があります。また、私たちは一連のスキル\( \Pi \)が与えられていると仮定し、各スキル\( \pi  \in  \Pi \)は特定の物体を拾うなどの短いタスクを実行し、短い言語記述\( {\ell }_{\pi } \)(例:「スポンジを見つける」)とアフォーダンス関数\( p\left( {{c}_{\pi } \mid  s,{\ell }_{\pi }}\right) \)を伴います。これは、状態\( s \)から記述\( {\ell }_{\pi } \)を成功裏に完了させる確率を示します。直感的には、\( p\left( {{c}_{\pi } \mid  s,{\ell }_{\pi }}\right) \)は「もしロボットに\( {\ell }_{\pi } \)をさせるように頼んだら、それをやるか？」という意味です。RLの用語では、\( p\left( {{c}_{\pi } \mid  s,{\ell }_{\pi }}\right) \)は、成功した場合に報酬が1、それ以外は0としたときのスキルの価値関数です。

As mentioned above, \( {\ell }_{\pi } \) denotes the textual label of skill \( \pi \) and \( p\left( {{c}_{\pi } \mid  s,{\ell }_{\pi }}\right) \) denotes the probability that skill \( \pi \) with textual label \( {\ell }_{\pi } \) successfully completes if executed from state \( s \) , where \( {c}_{\pi } \) is a Bernoulli random variable. The LLM provides us with \( p\left( {{\ell }_{\pi } \mid  i}\right) \) , the probability that a skill’s textual label is a valid next step for the user's instruction. However, what we are interested in is the probability that a given skill successfully makes progress toward actually completing the instruction, which we denote as \( p\left( {{c}_{i} \mid  i, s,{\ell }_{\pi }}\right) \) . Assuming that a skill that succeeds makes progress on \( i \) with probability \( p\left( {{\ell }_{\pi } \mid  i}\right) \) (i.e., its probability of being the right skill), and a skill that fails makes progress with probability zero, we can factorize this as \( p\left( {{c}_{i} \mid  i, s,{\ell }_{\pi }}\right)  \propto  p\left( {{c}_{\pi } \mid  s,{\ell }_{\pi }}\right) p\left( {{\ell }_{\pi } \mid  i}\right) \) . This corresponds to multiplying the probability of the language description of the skill given the instruction \( p\left( {{\ell }_{\pi } \mid  i}\right) \) , which we refer to as task-grounding, and the probability of the skill being possible in the current state of the world \( p\left( {{c}_{\pi } \mid  s,{\ell }_{\pi }}\right) \) , which we refer to as world-grounding.

前述の通り、\( {\ell }_{\pi } \)はスキル\( \pi \)のテキストラベルを示し、\( p\left( {{c}_{\pi } \mid  s,{\ell }_{\pi }}\right) \)は状態\( s \)から実行された場合にスキル\( \pi \)が成功裏に完了する確率を示し、\( {c}_{\pi } \)はベルヌーイ確率変数である。LLMは私たちに\( p\left( {{\ell }_{\pi } \mid  i}\right) \)を提供し、これはユーザーの指示に対してスキルのテキストラベルが次の有効なステップである確率を示す。しかしながら、私たちが関心を持つのは、特定のスキルが実際に指示を完了するために進展する確率であり、これを\( p\left( {{c}_{i} \mid  i, s,{\ell }_{\pi }}\right) \)と表す。スキルが成功した場合、それは確率\( p\left( {{\ell }_{\pi } \mid  i}\right) \)で進展し(すなわち、そのスキルが適切である確率)、失敗した場合は進展しないと仮定すると、これを\( p\left( {{c}_{i} \mid  i, s,{\ell }_{\pi }}\right)  \propto  p\left( {{c}_{\pi } \mid  s,{\ell }_{\pi }}\right) p\left( {{\ell }_{\pi } \mid  i}\right) \)として因数分解できる。これは、指示に基づくスキルの言語記述の確率\( p\left( {{\ell }_{\pi } \mid  i}\right) \)(タスクグラウンディングと呼ぶ)と、現在の世界状態においてスキルが可能である確率\( p\left( {{c}_{\pi } \mid  s,{\ell }_{\pi }}\right) \)(ワールドグラウンディングと呼ぶ)を掛け合わせたものである。

Connecting Large Language Models to Robots. While large language models can draw on a wealth of knowledge learned from copious amounts of text, they will not necessarily break down high-level commands into low-level instructions that are suitable for robotic execution. If a language model were asked "how would a robot bring me an apple", it may respond "a robot could go to a nearby store and purchase an apple for you". Though this response is a reasonable completion for the prompt, it is not necessarily actionable to an embodied agent, which may have a narrow and fixed set of abilities. Therefore, to adapt language models to our problem statement, we must somehow inform them that we specifically want the high-level instruction to be broken down into sequences of available low-level skills. One approach is careful prompt engineering [5, 11], a technique to coax a language model to a specific response structure. Prompt engineering provides examples in the context text ("prompt") for the model that specify the task and the response structure which the model will emulate; the prompt used in this work is shown in Appendix D. 3 along with experiments ablating it. However, this is not enough to fully constrain the output to admissible primitive skills for an embodied agent, and indeed at times it can produce inadmissible actions or language that is not formatted in a way that is easy to parse into individual steps.

大規模言語モデルをロボットに接続する。大規模言語モデルは膨大なテキストから学習した豊富な知識を活用できる一方で、高レベルの命令をロボットの実行に適した低レベルの指示に分解するとは限らない。もし「ロボットは私にリンゴを持ってきてくれるにはどうすればよいか」と尋ねた場合、モデルは「ロボットは近くの店に行き、リンゴを購入することができる」と答えるかもしれない。この回答はプロンプトに対して妥当な完結だが、具体的な能力が限定された実体のあるエージェントにとっては必ずしも実行可能ではない。そのため、言語モデルを我々の問題設定に適応させるには、特に高レベルの指示を利用可能な低レベルのスキルのシーケンスに分解する必要があることを明示する必要がある。一つの方法は、慎重なプロンプト設計[5, 11]であり、これは言語モデルに特定の応答構造を促す技術である。プロンプト設計は、タスクと応答構造を指定した例をコンテキストテキスト(「プロンプト」)としてモデルに提供し、モデルがそれを模倣するように促すものである。本研究で使用したプロンプトは付録D.3に示し、それに伴う実験も併記している。しかし、これは実体のあるエージェントにとって許容されるプリミティブスキルに出力を完全に制約するには不十分であり、時には不適切な行動や、個々のステップに分解しやすい形式でない言語を生成することもある。

Scoring language models open an avenue to constrained responses by outputting the probabilities assigned by a language model to fixed outputs. A language model represents a distribution over potential completions \( p\left( {{w}_{k} \mid  {w}_{ < k}}\right) \) , where \( {w}_{k} \) is a word that appears at a \( {k}^{\text{th }} \) position in a text. While typical generation applications (e.g., conversational agents) sample from this distribution or decode the maximum likelihood completion, we can also use the model to score a candidate completion selected from a set of options. Formally in SayCan, given a set of low-level skills II, their language descriptions \( {\ell }_{\Pi } \) and an instruction \( i \) , we compute the probability of a language description of a skill \( {\ell }_{\pi } \in  {\ell }_{\Pi } \) making progress towards executing the instruction \( i : p\left( {{\ell }_{\pi } \mid  i}\right) \) , which corresponds to querying the model over potential completions. The optimal skill according to the language model is computed via \( {\ell }_{\pi } = \arg \mathop{\max }\limits_{{{\ell }_{\pi } \in  {\ell }_{\Pi }}}p\left( {{\ell }_{\pi } \mid  i}\right) \) . Once selected, the process proceeds by iteratively selecting a skill and appending it to the instruction. Practically, in this work we structure the planning as a dialog between a user and a robot, in which a user provides the high level-instruction (e.g., "How would you bring me a coke can?") and the language model responds with an explicit sequence ("I would: 1. \( {\ell }_{\pi } \) ", e.g.,"I would: 1. find a coke can,2. pick up the coke can,3. bring it to you").

スコアリング言語モデルは、固定された出力に対して言語モデルが割り当てる確率を出力することにより、制約された応答への道を開きます。言語モデルは潜在的な補完の分布を表し、\( p\left( {{w}_{k} \mid  {w}_{ < k}}\right) \)、ここで\( {w}_{k} \)はテキスト内の\( {k}^{\text{th }} \)位置に現れる単語です。一般的な生成アプリケーション(例:会話エージェント)はこの分布からサンプリングしたり、最尤補完をデコードしたりしますが、候補補完のセットから選択された候補をスコアリングするためにもモデルを使用できます。正式には、SayCanでは、低レベルのスキルセットII、その言語記述\( {\ell }_{\Pi } \)と指示\( i \)が与えられたとき、スキルの言語記述\( {\ell }_{\pi } \in  {\ell }_{\Pi } \)が指示\( i : p\left( {{\ell }_{\pi } \mid  i}\right) \)の実行に向けて進展している確率を計算します。これは潜在的な補完に対してモデルに問い合わせることに相当します。言語モデルに従った最適なスキルは\( {\ell }_{\pi } = \arg \mathop{\max }\limits_{{{\ell }_{\pi } \in  {\ell }_{\Pi }}}p\left( {{\ell }_{\pi } \mid  i}\right) \)によって計算されます。選択後は、スキルを逐次選択し、それを指示に付加することで進行します。実際には、本研究では計画をユーザとロボットの対話として構築し、ユーザが高レベルの指示(例:「コーラ缶を持ってきてくれますか？」)を提供し、言語モデルが明示的なシーケンス(例:「私がやること:1. \( {\ell }_{\pi } \)」など、「私がやること:1. コーラ缶を見つける、2. それを拾う、3. あなたに持ってくる」)で応答します。

![bo_d3eb5nk601uc738ioai0_3_306_202_1183_239_0.jpg](images/bo_d3eb5nk601uc738ioai0_3_306_202_1183_239_0.jpg)

Figure 2: A value function module (a) is queried to form a value function space of action primitives based on the current observation. Visualizing "pick" value functions, in (b) "Pick up the red bull can" and "Pick up the apple" have high values because both objects are in the scene, while in (c) the robot is navigating an empty space, and thus none of the pick up actions receive high values.

図2:価値関数モジュール(a)は、現在の観測に基づいてアクションプリミティブの価値関数空間を形成するためにクエリされます。高い値を持つ「ピック」価値関数の可視化では、(b)「赤いブル缶を拾う」と「リンゴを拾う」が両方ともシーン内にあるため高い値を持ち、(c)ではロボットが空間をナビゲートしているため、どのピックアップアクションも高い値を受け取っていません。

This has the added benefit of interpretability, as the model not only outputs generative responses, but also gives a notion of likelihood across many possible responses. Figure 3 (and Appendix Figure 12 in more detail) shows this process of forcing the LLM into a language pattern, where the set of tasks are the skills the low-level policy is capable of and prompt engineering shows plan examples and dialog between the user and the robot. With this approach, we are able to effectively extract knowledge from the language model, but it leaves a major issue: while the decoding of the instruction obtained in this way always consists of skills that are available to the robot, these skills may not necessarily be appropriate for executing the desired high-level task in the specific situation that the robot is currently in. For example, if I ask a robot to "bring me an apple", the optimal set of skills changes if there is no apple in view or if it already has one in its hand.

これには解釈性という追加の利点もあり、モデルは生成応答を出力するだけでなく、多くの可能な応答の中での尤度の概念も示します。図3(および詳細な付録図12)は、LLMを言語パターンに強制するこの過程を示しており、タスクのセットは低レベルポリシーが実行可能なスキルであり、プロンプトエンジニアリングは計画例やユーザとロボット間の対話を示しています。このアプローチにより、言語モデルから知識を効果的に抽出できますが、重要な問題も残ります。それは、この方法で得られる指示のデコードは常にロボットが利用可能なスキルで構成されているものの、これらのスキルが特定の状況で望ましい高レベルタスクの実行に必ずしも適しているとは限らないということです。例えば、「リンゴを持ってきて」とロボットに頼むとき、視界にリンゴがない場合やすでに手に持っている場合では、最適なスキルセットが変わります。

SayCan. The key idea of SayCan is to ground large language models through value functions

SayCan。SayCanの重要なアイデアは、価値関数を通じて大規模な言語モデルを基盤化することです。

- affordance functions that capture the log likelihood that a particular skill will be able to succeed in the current state. Given a skill \( \pi  \in  \Pi \) , its language description \( {\ell }_{\pi } \) and its corresponding value function, which provides \( p\left( {{c}_{\pi } \mid  s,{\ell }_{\pi }}\right) \) , the probability of \( c \) -ompletion for the skill described by \( {\ell }_{\pi } \) in state \( s \) , we form an affordance space \( {\left\{  p\left( {c}_{\pi } \mid  s,{\ell }_{\pi }\right) \right\}  }_{\pi  \in  \Pi } \) . This value function space captures affordances across all skills [12] (see Figure 2). For each skill, the affordance function and the LLM probability are then multiplied together and ultimately the most probable skill is selected, i.e. \( \pi  = \arg \mathop{\max }\limits_{{\pi  \in  \Pi }}p\left( {{c}_{\pi } \mid  s,{\ell }_{\pi }}\right) p\left( {{\ell }_{\pi } \mid  i}\right) \) . Once the skill is selected, the corresponding policy is executed by the agent and the LLM query is amended to include \( {\ell }_{\pi } \) and the process is run again until a termination token (e.g., "done") is chosen. This process is shown in Figure 3 and described in Algorithm 1. These two mirrored processes together lead to a probabilistic interpretation of Say-Can, where the LLM provides probabilities of a skill being useful for the high-level instruction and the affordances provide probabilities of successfully executing each skill. Combining these two probabilities together provides a probability that this skill furthers the execution of the high-level instruction commanded by the user.

- 特定のスキルが現在の状態で成功する可能性を捉えるアフォーダンス関数。スキル \( \pi  \in  \Pi \) 、その言語記述 \( {\ell }_{\pi } \) 、および対応する価値関数を考慮し、\( p\left( {{c}_{\pi } \mid  s,{\ell }_{\pi }}\right) \) を提供し、\( c \) - 完了確率を示す。状態 \( s \) において、\( {\ell }_{\pi } \) で記述されたスキルの完了確率を示す \( c \) に基づき、アフォーダンス空間 \( {\left\{  p\left( {c}_{\pi } \mid  s,{\ell }_{\pi }\right) \right\}  }_{\pi  \in  \Pi } \) を形成する。この価値関数空間は、すべてのスキルにわたるアフォーダンスを捉える [12] (図2参照)。各スキルについて、アフォーダンス関数とLLMの確率を掛け合わせ、最も確率の高いスキルを選択する、すなわち \( \pi  = \arg \mathop{\max }\limits_{{\pi  \in  \Pi }}p\left( {{c}_{\pi } \mid  s,{\ell }_{\pi }}\right) p\left( {{\ell }_{\pi } \mid  i}\right) \) 。スキルが選択されると、対応する方針がエージェントによって実行され、LLMへのクエリは \( {\ell }_{\pi } \) を含むように修正され、終了トークン(例:「完了」)が選択されるまでこのプロセスは繰り返される。このプロセスは図3に示され、アルゴリズム1で説明されている。これら二つの鏡像のプロセスは、Say-Canの確率的解釈につながり、LLMは高レベルの指示に対してスキルが有用である確率を提供し、アフォーダンスは各スキルを成功裏に実行する確率を提供する。これら二つの確率を組み合わせることで、このスキルがユーザーの高レベル指示の実行を促進する確率が得られる。

## 4 Implementing SayCan in a Robotic System

## 4 ロボットシステムにおけるSayCanの実装

Language-Conditioned Robotic Control Policies. To instantiate SayCan, we must provide it with a set of skills, each of which has a policy, a value function, and a short language description (e.g., "pick up the can"). These skills, value functions, and descriptions can be obtained in a variety of different ways. In our implementation, we train the individual skills either with image-based behavioral cloning, following the BC-Z method [13], or reinforcement learning, following MT-Opt [14]. Regardless of how the skill's policy is obtained, we utilize value functions trained via TD backups as the affordance model for that skill. While we find that the BC policies achieve higher success rates at the current stage of our data collection process, the value functions provided by the RL policies are crucial as an abstraction to translate control capabilities to a semantic understanding of the scene. In order to amortize the cost of training many skills, we utilize multi-task BC and multitask RL, respectively, where instead of training a separate policy and value function per skill, we train multi-task policies and models that are conditioned on the language description. Note, however,

言語条件付きロボット制御方針。SayCanを実装するには、各スキルに対して方針、価値関数、および短い言語記述(例:「缶を拾う」)を提供する必要がある。これらのスキル、価値関数、記述はさまざまな方法で取得可能である。私たちの実装では、個々のスキルを画像ベースの行動模倣学習(BC-Z法 [13] に従う)または強化学習(MT-Opt [14] に従う)で訓練している。スキルの方針の取得方法に関わらず、TDバックアップを用いて訓練された価値関数をアフォーダンスモデルとして利用している。現在のデータ収集段階では、BCポリシーの成功率が高いとわかっているが、RLポリシーによる価値関数は、制御能力をシーンの意味理解に翻訳する抽象化として重要である。多くのスキルの訓練コストを削減するために、マルチタスクBCとマルチタスクRLをそれぞれ利用し、スキルごとに個別の方針と価値関数を訓練するのではなく、言語記述に条件付けされたマルチタスク方針とモデルを訓練している。ただし、

Algorithm 1 SayCan

アルゴリズム1 SayCan

---

Given: A high level instruction \( i \) , state \( {s}_{0} \) , and a set of skills \( \Pi \) and their language descriptions \( {\ell }_{\Pi } \)

高レベル指示 \( i \) 、状態 \( {s}_{0} \) 、およびスキルのセット \( \Pi \) とその言語記述 \( {\ell }_{\Pi } \) を与える

	\( n = 0,\pi  = \varnothing \)

	while \( {\ell }_{{\pi }_{n - 1}} \neq \) "done" do

	while \( {\ell }_{{\pi }_{n - 1}} \neq \) "完了" まで

		\( \mathcal{C} = \varnothing \)

		for \( \pi  \in  \Pi \) and \( {\ell }_{\pi } \in  {\ell }_{\Pi } \) do

		for \( \pi  \in  \Pi \) と \( {\ell }_{\pi } \in  {\ell }_{\Pi } \) について

			\( {p}_{\pi }^{\mathrm{{LLM}}} = p\left( {{\ell }_{\pi } \mid  i,{\ell }_{{\pi }_{n - 1}},\ldots ,{\ell }_{{\pi }_{0}}}\right) \) \( \vartriangleright \) Evaluate scoring of LLM

			\( {p}_{\pi }^{\mathrm{{LLM}}} = p\left( {{\ell }_{\pi } \mid  i,{\ell }_{{\pi }_{n - 1}},\ldots ,{\ell }_{{\pi }_{0}}}\right) \) \( \vartriangleright \) LLMのスコア評価

			\( {p}_{\pi }^{\text{affordance }} = p\left( {{c}_{\pi } \mid  {s}_{n},{\ell }_{\pi }}\right) \) \( \vartriangleright \) Evaluate affordance function

			\( {p}_{\pi }^{\text{affordance }} = p\left( {{c}_{\pi } \mid  {s}_{n},{\ell }_{\pi }}\right) \) \( \vartriangleright \) アフォーダンス関数の評価

			\( {p}_{\pi }^{\text{combined }} = {p}_{\pi }^{\text{affordance }}{p}_{\pi }^{\text{LLM }} \)

			\( \mathcal{C} = \mathcal{C} \cup  {p}_{\pi }^{\text{combined }} \)

		end for

		end for

		\( {\pi }_{n} = \arg \mathop{\max }\limits_{{\pi  \in  \Pi }}\mathcal{C} \)

		Execute \( {\pi }_{n}\left( {s}_{n}\right) \) in the environment, updating state \( {s}_{n + 1} \)

		環境内で \( {\pi }_{n}\left( {s}_{n}\right) \) を実行し、状態 \( {s}_{n + 1} \) を更新

		\( n = n + 1 \)

	end while

	end while

---

![bo_d3eb5nk601uc738ioai0_4_318_756_807_510_0.jpg](images/bo_d3eb5nk601uc738ioai0_4_318_756_807_510_0.jpg)

Figure 3: Given a high-level instruction, SayCan combines probabilities from a LLM (the probability that a skill is useful for the instruction) with the probabilities from a value function (the probability of successfully executing said skill) to select the skill to perform. This emits a skill that is both possible and useful. The process is repeated by appending the skill to the response and querying the models again, until the output step is to terminate. Appendix Figures 12 and 2 focus on the LLM and VFS components.

図3:高レベルの指示が与えられると、SayCanはLLM(指示に役立つスキルの確率)と値関数(そのスキルを成功裏に実行する確率)からの確率を組み合わせて、実行するスキルを選択します。これにより、可能でありかつ有用なスキルが出力されます。このプロセスは、スキルを応答に追加し、モデルに再問い合わせることで繰り返され、出力ステップが終了するまで続きます。付録の図12と図2は、LLMとVFSコンポーネントに焦点を当てています。

that this description only corresponds to low level skills - it is still the role of the LLM in SayCan to interpret the high-level instruction and break it up into individual low level skill descriptions.

この記述は低レベルのスキルにのみ対応していることに注意してください。SayCanにおいては、高レベルの指示を解釈し、それを個々の低レベルのスキルの記述に分解するのはLLMの役割です。

To condition the policies on language, we utilize a pre-trained large sentence encoder language model [15]. We freeze the language model parameters during training and use the embeddings generated by passing in text descriptions of each skill. These text embeddings are used as the input to the policy and value function that specify which skill should be performed (see the details of the architectures used in the Appendix C.1). Since the language model used to generate the text embeddings is not necessarily the same as the language model used for planning, SayCan is able to utilize different language models well suited for different abstraction levels - understanding planning with respect to many skills as opposed to expressing specific skills more granularly.

ポリシーを言語に条件付けるために、事前学習済みの大規模文章エンコーダ言語モデル[15]を利用します。トレーニング中は言語モデルのパラメータを固定し、各スキルのテキスト記述を通じて生成される埋め込みを使用します。これらのテキスト埋め込みは、実行すべきスキルを指定するポリシーと値関数の入力として使用されます(使用したアーキテクチャの詳細は付録C.1を参照)。テキスト埋め込みを生成するために使用される言語モデルは必ずしも計画に使用されるモデルと同じではないため、SayCanは異なる抽象レベルに適した異なる言語モデルを効果的に利用できます。多くのスキルに関する理解と計画に関して、より詳細なスキル表現を行うことが可能です。

Training the Low-Level Skills. We utilize both BC and RL policy training procedures to obtain the language-conditioned policies and value functions, respectively. To complete the description of the underlying MDP that we consider, we provide the reward function as well as the skill specification that is used by the policies and value functions. As mentioned previously, for skill specification we use a set of short, natural language descriptions that are represented as language model embeddings. We utilize sparse reward functions with reward values of 1.0 at the end of an episode if the language command was executed successfully, and 0.0 otherwise. The success of language command execution is rated by humans where the raters are given a video of the robot performing the skill, together with the given instruction. If two out of the three raters agree that the skill was accomplished successfully, the episode is labelled with a positive reward.

低レベルスキルのトレーニング。私たちは、BCとRLのポリシートレーニング手法の両方を用いて、言語条件付きのポリシーと値関数を取得します。基礎となるマルコフ決定過程(MDP)の記述を完了するために、報酬関数とポリシーおよび値関数が使用するスキルの仕様も提供します。前述のように、スキルの仕様には短く自然な言語記述のセットを用い、それらは言語モデルの埋め込みとして表現されます。疎な報酬関数を用い、エピソードの終了時に言語コマンドが成功裏に実行された場合は報酬値1.0、それ以外は0.0とします。言語コマンドの実行成功は人間による評価で判断され、評価者にはロボットがスキルを実行している映像と指示が提示されます。3人の評価者のうち2人が成功と認めた場合、そのエピソードには正の報酬が付与されます。

To learn language-conditioned BC policies at scale in the real world, we build on top of BC-Z [13] and use a similar policy-network architecture (shown in Fig. 10). To learn a language-conditioned RL policy, we use MT-Opt [14] in the Everyday Robots simulator using RetinaGAN sim-to-real transfer [16]. We bootstrap the performance of simulation policies by utilizing simulation demonstrations to provide initial successes, and then continuously improve the RL performance with online data collection. We use a network architecture similar to MT-Opt (shown in Fig. 9). The action space of our policies includes the six degrees of freedom of the end-effector pose as well as gripper open and close commands, x-y position and yaw orientation delta of the mobile base of the robot, and the terminate action. Additional details on data collection and training are in Appendix Section C.2.

実世界で大規模に言語条件付きBCポリシーを学習するために、私たちはBC-Z[13]を基盤とし、類似のポリシーネットワークアーキテクチャ(図10参照)を使用します。言語条件付きRLポリシーを学習するために、RetinaGANによるシミュレーションから実環境への転送[16]を用いたMT-Opt[14]をEveryday Robotsシミュレータで使用します。シミュレーションデモンストレーションを活用して初期成功を提供し、その後オンラインデータ収集によってRLの性能を継続的に向上させます。私たちのポリシーのアクション空間には、エンドエフェクターの6自由度の姿勢、グリッパーの開閉コマンド、ロボットの移動基底のx-y位置とヨー角の変化量、終了アクションが含まれます。データ収集とトレーニングの詳細は付録C.2に記載しています。

Robotic System and Skills. For the control policies, we study a diverse set of manipulation and navigation skills using a mobile manipulator robot. Inspired by common skills one might pose to a robot in a kitchen environment, we propose 551 skills that span seven skill families and 17 objects, which include picking, placing and rearranging objects, opening and closing drawers, navigating to various locations, and placing objects in a specific configurations. In this study we utilize the skills that are most amenable to more complex behaviors via composition and planning as well as those that have high performance at the current stage of data collection; for more details, see Appendix D.

ロボットシステムとスキル。制御ポリシーには、多様な操作とナビゲーションスキルを持つモバイルマニピュレータロボットを用います。キッチン環境でロボットに提示される一般的なスキルに着想を得て、7つのスキルファミリーと17の対象物にまたがる551のスキルを提案します。これらには、物のピックアップ、配置、再配置、引き出しの開閉、さまざまな場所へのナビゲーション、特定の配置への物の配置などが含まれます。本研究では、より複雑な動作に組み合わせや計画を通じて適用しやすいスキルと、現段階のデータ収集で高い性能を示すスキルを利用しています。詳細は付録Dを参照してください。

## 5 Experimental Evaluation

## 5 実験評価

![bo_d3eb5nk601uc738ioai0_5_309_689_1169_238_0.jpg](images/bo_d3eb5nk601uc738ioai0_5_309_689_1169_238_0.jpg)

Figure 4: The experiments were performed in an office kitchen and a mock kitchen mirroring this setup, with 5 locations and 15 objects. The robot is a mobile manipulator with policies trained from an RGB observation.

図4:実験はオフィスキッチンとその模擬環境で行われ、5つの場所と15の対象物を使用しました。ロボットはRGB観測から学習したポリシーを持つモバイルマニピュレータです。

Experimental Setup. We evaluate SayCan with a mobile manipulator and a set of object manipulation and navigation skills in two office kitchen environments. Figure 4 shows the environment setup and the robot. We use 15 objects commonly found in an office kitchen and 5 known locations with semantic meaning (two counters, a table, a trash can, and the user location). We test our method in two environments: a real office kitchen and a mock environment mirroring the kitchen, which is also the environment in which the robot's skills were trained. The robot used is a mobile manipulator from Everyday Robots \( {}^{2} \) with a 7 degree-of-freedom arm and a two-fingered gripper. The LLM used is 540B PaLM [9] unless stated otherwise for LLM ablations. We refer to SayCan with PaLM as PaLM-SayCan.

実験設定。私たちは、モバイルマニピュレータと一連の物体操作およびナビゲーションスキルを用いて、2つのオフィスキッチン環境でSayCanを評価します。図4は環境の設定とロボットを示しています。一般的にオフィスキッチンで見られる15の対象物と、セマンティックな意味を持つ5つの既知の場所(カウンター2つ、テーブル、ゴミ箱、ユーザの位置)を使用します。実験は、実際のオフィスキッチンと、その模擬環境の2つで行います。模擬環境は、ロボットのスキルが訓練された環境でもあります。使用したロボットは、Everyday Robotsのモバイルマニピュレータ[0]で、7自由度のアームと二指グリッパーを備えています。使用したLLMは540BのPaLM[9]で、特に記載のない限りLLMの比較実験に用います。PaLMを用いたSayCanはPaLM-SayCanと呼びます。

Instructions. To evaluate PaLM-SayCan, we test across 101 instructions from 7 instruction families, summarized in Table 1 and enumerated in Appendix E.1. These were developed to test various aspects of SayCan and were inspired by crowd sourcing via Amazon Mechanical Turk and in-person kitchen users, as well as benchmarks such as ALFRED [17] and BEHAVIOR [18]. The instructions span multiple axes of variation: time-horizon (from single primitives to 10+ in a row), language complexity (from structured language to fully crowd-sourced requests), and embodiment (variations over the robot and environment state). Table 1 details examples for each family.

指示。PaLM-SayCanの評価のために、7つの指示ファミリーから101の指示をテストし、表1に要約し、付録E.1に列挙しています。これらはSayCanのさまざまな側面をテストするために開発され、Amazon Mechanical Turkによるクラウドソーシングや対面のキッチンユーザー、さらにはALFRED [17]やBEHAVIOR [18]などのベンチマークから着想を得ています。指示は、時間軸(単一のプリミティブから10以上の連続まで)、言語の複雑さ(構造化された言語から完全にクラウドソースされたリクエストまで)、および具現化(ロボットと環境の状態のバリエーション)といった複数の軸にまたがっています。表1には各ファミリーの例が詳述されています。

<table><tr><td>Instruction Family</td><td/><td>Num Explanation</td><td>Example Instruction</td></tr><tr><td>NL Single Primitive</td><td>15</td><td>NL queries for a single primitive</td><td>Let go of the coke can</td></tr><tr><td>NL Nouns</td><td>15</td><td>NL queries focused on abstract nouns</td><td>Bring me a fruit</td></tr><tr><td>NL Verbs</td><td>15</td><td>NL queries focused on abstract verbs</td><td>Restock the rice chips on the far counter</td></tr><tr><td>Structured Language</td><td>15</td><td>Structured language queries, mirror NL Verbs</td><td>Move the rice chips to the far counter.</td></tr><tr><td>Embodiment</td><td>11</td><td>Queries to test SayCan's understanding of the current state of the environment and robot</td><td>Put the coke on the counter. (starting from different completion stages)</td></tr><tr><td>Crowd-Sourced</td><td>15</td><td>Queries in unstructured formats</td><td>My favorite drink is redbull, bring one</td></tr><tr><td>Long-Horizon</td><td>15</td><td>Long-horizon queries that require many steps of reasoning</td><td>I spilled my coke on the table, throw it away and bring me something to clean</td></tr></table>

<table><tbody><tr><td>指示ファミリー</td><td></td><td>Num説明</td><td>例示指示</td></tr><tr><td>NL単一プリミティブ</td><td>15</td><td>単一プリミティブに関するNLクエリ</td><td>コーラ缶を放す</td></tr><tr><td>NL名詞</td><td>15</td><td>抽象名詞に焦点を当てたNLクエリ</td><td>果物を持ってきて</td></tr><tr><td>NL動詞</td><td>15</td><td>抽象動詞に焦点を当てたNLクエリ</td><td>遠くのカウンターに米菓を補充してください</td></tr><tr><td>構造化言語</td><td>15</td><td>構造化言語クエリ、NL動詞を模倣</td><td>米菓を遠くのカウンターに移動させてください。</td></tr><tr><td>具現化</td><td>11</td><td>SayCanの環境とロボットの現在の状態理解をテストするクエリ</td><td>コーラをカウンターに置いてください。(異なる完了段階から開始)</td></tr><tr><td>クラウドソース</td><td>15</td><td>非構造化フォーマットのクエリ</td><td>私のお気に入りの飲み物はレッドブルです。1つ持ってきてください</td></tr><tr><td>長期展望</td><td>15</td><td>多くの推論ステップを必要とする長期展望のクエリ</td><td>コーラをテーブルにこぼしたので捨てて、掃除用のものを持ってきてください</td></tr></tbody></table>

Table 1: List of instruction family definitions: We evaluate the algorithm on 101 instructions. We group the instructions into different families, with each family focusing on testing one aspect of the proposed method.

表1:指示ファミリー定義の一覧:私たちは101の指示に対してアルゴリズムを評価します。指示を異なるファミリーに分類し、それぞれのファミリーは提案手法の特定の側面をテストすることに焦点を当てています。

---

2https://everydayrobots.com/

2https://everydayrobots.com/

---

Metrics. To understand the performance of the proposed method we measure two main metrics. The first is plan success rate, which measures whether the skills selected by the model are correct for the instruction, regardless of whether or not they actually successfully executed. We ask 3 human raters to indicate whether the plan generated by the model can achieve the instruction, and if 2 out of 3 raters agree that the plan is valid, it is marked a success. Note that for many instructions there may be multiple valid solutions. For example if the instruction is to "bring a sponge and throw away the soda can", the plan can choose to bring sponge first or throw away the soda can first.

評価指標。提案手法の性能を理解するために、2つの主要な指標を測定します。最初は計画成功率で、これはモデルが選択したスキルが指示に対して正しいかどうかを、実際に成功裏に実行されたかに関わらず評価します。3人の人間評価者に、モデルが生成した計画が指示を達成できるかどうかを示すよう依頼し、そのうち2人が計画を有効と認めれば成功とマークします。多くの指示には複数の有効な解決策が存在することに注意してください。例えば、「スポンジを持ってきてソーダ缶を捨てる」という指示の場合、計画は最初にスポンジを持ってくるか、先にソーダ缶を捨てるかを選択できます。

The second metric is execution success rate, which measures whether the full PaLM-SayCan system actually performs the desired instruction successfully. We ask 3 human raters to watch the robot execution. The raters are asked to answer the question "whether the robot achieves the task specified by the task string?" We mark an execution successful if 2 out of 3 raters agree that it is successful.

二つ目の指標は実行成功率で、これは完全なPaLM-SayCanシステムが実際に望ましい指示を成功裏に実行できるかどうかを測定します。3人の人間評価者にロボットの実行を観察させ、「ロボットがタスク文字列で指定された作業を達成したか？」という質問に答えてもらいます。3人中2人が成功と認めれば、実行は成功とマークします。

### 5.1 Results

### 5.1 結果

Table 2 shows the performance of PaLM-SayCan across 101 tasks. In the mock kitchen, PaLM-SayCan achieved a planning success rate of \( {84}\% \) and an execution rate of \( {74}\% \) . We also investigate PaLM-SayCan out of the lab setting and in the real kitchen to verify the performance of the policies and value functions in this setting. We find a reduction of planning performance by \( 3\% \) and execution by \( {14}\% \) , indicating PaLM-SayCan and the underlying policies generalize reasonably well to the full kitchen. The full task list and results can be found in the Appendix Table 5, and videos of experiment rollouts and the decision making process can be found on the project website: say-can.github. io.

表2は、101のタスクにおけるPaLM-SayCanの性能を示しています。模擬キッチンでは、PaLM-SayCanは計画成功率\( {84}\% \)、実行成功率\( {74}\% \)を達成しました。また、実験室外や実際のキッチンでの性能も調査し、ポリシーと価値関数の性能を検証しました。その結果、計画性能は\( 3\% \)、実行性能は\( {14}\% \)低下しましたが、これはPaLM-SayCanとその基盤となるポリシーがフルキッチンに十分に一般化できていることを示しています。完全なタスクリストと結果は付録の表5に掲載されており、実験のロールアウトや意思決定過程の動画はプロジェクトのウェブサイトsay-can.github.ioで閲覧可能です。

Figure 5 shows two long-horizon queries and the resulting rollouts. These tasks require PaLM-SayCan to plan many steps without error and for the robot to navigate and interact with a significant portion of the kitchen. Each query requires PaLM-SayCan to understand context implicit within the instruction. In Figure 5a, the algorithm must understand the operator has asked for something to "recover from a workout", i.e. something healthy, and thus it brings water and an apple rather than, e.g., a soda and chips. Furthermore, the algorithm must understand ordering and history, that it has already brought a drink and now must bring a snack before terminating. In Figure 5b, PaLM-SayCan must track which objects are the "them" that need to be disposed of and where the sponge should be brought.

図5は二つの長期的クエリとその結果のロールアウトを示しています。これらのタスクは、PaLM-SayCanが多くのステップを誤りなく計画し、ロボットがキッチンの大部分をナビゲートし、相互作用することを要求します。各クエリは、指示に含まれる文脈を理解する必要があります。図5aでは、アルゴリズムは「運動後の回復」を求められていると理解し、健康的なものを持ってくる必要があります。したがって、水とリンゴを持ってきます。さらに、順序や履歴も理解し、すでに飲み物を持ってきているため、終了前にスナックを持ってくる必要があります。図5bでは、PaLM-SayCanは「それら」(廃棄すべき物体)とスポンジを持ってくる場所を追跡しなければなりません。

![bo_d3eb5nk601uc738ioai0_6_308_1247_1180_431_0.jpg](images/bo_d3eb5nk601uc738ioai0_6_308_1247_1180_431_0.jpg)

Figure 5: Timelapse of rollouts to two long-horizon queries. The robot interacts with a large portion of the kitchen environment and successfully performs sequences of manipulation and navigation skills.

図5:二つの長期的クエリに対するロールアウトのタイムラプス。ロボットはキッチン環境の大部分と相互作用し、一連の操作とナビゲーションスキルを成功裏に実行します。

Figure 6 highlights PaLM-SayCan's decision making, along with its interpretability. The decision making process can be understood as it solves instructions by visualizing what the two sides of the algorithm output. This allows a user to understand what options PaLM-SayCan is considering as language completions and what it believes is possible. We find that sequence order is understood (approaching objects before picking them up and picking them up before bringing them). Figure 6 shows that though the query mentions a coke, PaLM-SayCan understands that the important object is something to clean and brings a sponge. Appendix E. 6 shows additional rollouts with complex decisions, embodiment grounding, and long-horizon tasks in Figures 14-17 as well as failures in Figure 16. We believe such real-time and clear interpretability opens avenues to more interactive operation.

図6は、PaLM-SayCanの意思決定過程とその解釈性を強調しています。意思決定過程は、アルゴリズムの両側の出力を視覚化することで理解できます。これにより、ユーザーはPaLM-SayCanが言語の補完として検討している選択肢や、何が可能だと考えているかを理解できます。シーケンスの順序も理解されていることがわかります(物体に近づく前にアプローチし、持ち上げた後に持ち運ぶ)。図6は、クエリにコーラが含まれていても、PaLM-SayCanは重要な対象は掃除用のものであり、スポンジを持ってくることを理解していることを示しています。付録E.6では、複雑な決定、具体化のグラウンディング、長期的タスクを含む追加のロールアウト(図14-17)や、失敗例(図16)も示しています。このようなリアルタイムで明確な解釈性は、よりインタラクティブな操作の道を開くと考えています。

![bo_d3eb5nk601uc738ioai0_7_310_205_1169_469_0.jpg](images/bo_d3eb5nk601uc738ioai0_7_310_205_1169_469_0.jpg)

Figure 6: Visualization of PaLM-SayCan's decision making, where the top combined score chooses the correct skill.

図6:PaLM-SayCanの意思決定の可視化。上部の結合スコアが正しいスキルを選択します。

When comparing the performance of different instruction families in Table 2 (see Table 1 for an explanation of families), we see that the natural language nouns performed worse than natural language verbs, due to the number of nouns possible ( 15 objects and 5 locations) versus number of verbs (6). The structured language tasks (created to ablate the performance loss of spelling out the solution versus understanding the query) were planned correctly \( {93}\% \) of the time, while their natural language verb counterparts were planned correctly \( {100}\% \) . This indicates the language model effectively parses the queries. The embodiment tasks were planned correctly \( {64}\% \) of the time, generally with failures as a result of affordance function misclassification. PaLM-SayCan planned and executed crowd-sourced natural queries with performance on par with other instruction families. PaLM-SayCan performed worst on the most challenging long-horizon tasks, where most failures were a result of early termination by the LLM (e.g., bringing one object but not the second). We also find that PaLM-SayCan struggles with negation (e.g., "bring me a snack that isn't an apple") and ambiguous references (e.g. asking for drinks with caffeine), which is a known issue inherited from underlying language models [19]. Overall, 65% of the errors were LLM failures and 35% were affordance failures.

表2の異なる指示ファミリーの性能比較(ファミリーの説明は表1を参照)において、自然言語の名詞は自然言語の動詞よりも性能が劣ることがわかる。これは、名詞の可能な数(15の物体と5つの場所)に対して、動詞の数(6)に起因している。構造化言語タスク(解決策を列挙することとクエリを理解することの性能低下を除去するために作成された)は、正しく計画された割合が\( {93}\% \)であり、一方で自然言語の動詞の対応タスクは正しく計画された割合が\( {100}\% \)であった。これは、言語モデルがクエリを効果的に解析していることを示している。具現化タスクは、一般的に失敗はアフォーダンス関数の誤分類によるもので、正しく計画された割合が\( {64}\% \)であった。PaLM-SayCanは、クラウドソースの自然言語クエリを計画・実行し、他の指示ファミリーと同等の性能を示した。最も難しい長期的タスクでは、PaLM-SayCanの性能は最も悪く、多くの失敗はLLMによる早期終了(例:一つの物体を持ってくるが二つ目は持ってこない)によるものであった。また、PaLM-SayCanは否定表現(例:「リンゴでないおやつを持ってきて」)や曖昧な参照(例:カフェイン入りの飲み物を求める)に苦労しており、これは基盤となる言語モデルからの既知の問題[19]である。全体として、エラーの65％はLLMの失敗であり、35％はアフォーダンスの失敗であった。

Returning to our initial example, "I spilled something, can you help?", an ungrounded language model would respond with statements like "I can call you a cleaner" or "I can vacuum that up for you", which given our robot are unreasonable. We have shown that PaLM-SayCan responds "I would: 1. find a sponge, 2. pick up the sponge, 3. bring it to you, 4. done" and is able execute this sequence on the robot in a real kitchen. This requires long-horizon reasoning over a required order, an abstract understanding of the instruction, and knowledge of both the environment and robot's capabilities.

最初の例、「何かこぼしたけど、手伝ってくれる？」に戻ると、未基盤の言語モデルは「掃除機を呼びます」や「それを吸い取ります」といった回答を返すが、私たちのロボットには不合理であることがわかる。私たちは、PaLM-SayCanが「1.スポンジを見つける、2.スポンジを拾う、3.あなたに持っていく、4.完了」と応答し、このシーケンスを実際のキッチンで実行できることを示した。これは、必要な順序に関する長期的推論、指示の抽象的理解、環境とロボットの能力に関する知識を必要とする。

Ablating Language. To study the importance of the LLM, we conduct two ablation experiments using the language-conditioned policy (see Sections 4-4). In \( {BCNL} \) we feed the full instruction \( i \) into the policy - this approach is representative of standard RL or BC-based instruction following methods \( \left\lbrack  {{13},{20},{21},{22}}\right\rbrack \) . In \( {BCUSE} \) we project the high-level instruction into the set of known language commands via the Universal Sentence Encoder (USE) embeddings [15] by embedding the instruction, all the tasks, and the combinatorial set of sequences tasks (i.e., we consider "pick coke can" as well as "1. find coke can, 2. pick coke can" and so on), and selecting the highest cosine similarity instruction. The results in Table 2 illustrate the necessity of the language grounding where \( {BCNL} \) achieves \( 0\% \) in all tasks and \( {BCUSE} \) achieves \( {60}\% \) for single primitives, but \( 0\% \) otherwise.

言語のアブレーション。LLMの重要性を研究するために、言語条件付きポリシーを用いた二つのアブレーション実験を行う(セクション4-4参照)。\( {BCNL} \)では、完全な指示をポリシーに入力する—このアプローチは標準的なRLやBCに基づく指示追従方法を代表している\( i \)。\( {BCUSE} \)では、Universal Sentence Encoder(USE)埋め込み[15]を用いて、指示、すべてのタスク、および組み合わせたシーケンスタスクの集合(例:「コーラ缶を取る」および「1.コーラ缶を見つける、2.コーラ缶を取る」など)を埋め込み、最高コサイン類似度の指示を選択する。表2の結果は、言語のグラウンディングの必要性を示しており、\( {BCNL} \)はすべてのタスクで\( 0\% \)を達成し、\( {BCUSE} \)は単一のプリミティブに対して\( {60}\% \)を達成しているが、それ以外は\( 0\% \)である。

Ablating Value Functions. Table 2 illustrates the necessity of the affordance grounding. We compare PaLM-SayCan to (1) No VF, which removes the value function grounding (i.e., choosing the maximum language score skill) and to (2) Generative, which uses the generative output of the LLM and then projects each planned skill to its maximal cosine similarity skill via USE embeddings. The latter in effect compares to [23], which loses the explicit option probabilities, and thus is less interpretable and cannot be combined with affordance probabilities. For Generative we also tried BERT embeddings [3], but found poor performance. The No VF and Generative approaches performed similarly, achieving \( {67}\% \) and \( {74}\% \) planning success rate respectively, and worse than PaLM-SayCan's 84%.

価値関数のアブレーション。表2はアフォーダンスのグラウンディングの必要性を示している。私たちは、PaLM-SayCanを(1)価値関数のグラウンディングを除去したNo VFと比較し(すなわち、最大の言語スコアを持つスキルを選択)、(2)生成モデルを用いたGenerativeと比較した。後者は、LLMの生成出力を用いて、計画された各スキルをUSE埋め込みによる最大コサイン類似度のスキルに投影するものである。これは実質的に[23]と比較され、明示的なオプション確率を失い、解釈性が低下し、アフォーダンス確率と組み合わせることができない。Generativeでは、BERT埋め込み[3]も試したが、性能は良くなかった。No VFとGenerativeのアプローチは類似した性能を示し、それぞれ\( {67}\% \)と\( {74}\% \)の計画成功率を達成し、PaLM-SayCanの84％には及ばなかった。

<table><tr><td/><td/><td colspan="2">Mock Kitchen</td><td colspan="2">Kitchen</td><td colspan="2">No Affordance</td><td colspan="2">No LLM</td></tr><tr><td/><td/><td>\( \mathbf{{PaLM} - } \) SayCan</td><td>\( \mathbf{{PaLM} - } \) SayCan</td><td>\( \mathbf{{PaLM} - } \) SayCan</td><td>\( \mathbf{{PaLM} - } \) SayCan</td><td>\( \mathbf{{NoVF}} \)</td><td>\( \mathbf{{Gen}.} \)</td><td>BC NL</td><td>BC USE</td></tr><tr><td>Family</td><td>\( \mathbf{{Num}} \)</td><td>Plan</td><td>Execute</td><td>Plan</td><td>Execute</td><td>Plan</td><td>Plan</td><td>Execute</td><td>Execute</td></tr><tr><td>NL Single</td><td>15</td><td>100%</td><td>100%</td><td>93%</td><td>87%</td><td>73%</td><td>87%</td><td>0%</td><td>60%</td></tr><tr><td>NL Nouns</td><td>15</td><td>67%</td><td>47%</td><td>60%</td><td>40%</td><td>53%</td><td>53%</td><td>0%</td><td>0%</td></tr><tr><td>NL Verbs</td><td>15</td><td>100%</td><td>93%</td><td>93%</td><td>73%</td><td>87%</td><td>93%</td><td>0%</td><td>0%</td></tr><tr><td>Structured</td><td>15</td><td>93%</td><td>87%</td><td>93%</td><td>47%</td><td>93%</td><td>100%</td><td>0%</td><td>0%</td></tr><tr><td>Embodiment</td><td>11</td><td>64%</td><td>55%</td><td>64%</td><td>55%</td><td>18%</td><td>36%</td><td>0%</td><td>0%</td></tr><tr><td>Crowd Sourced</td><td>15</td><td>87%</td><td>87%</td><td>73%</td><td>60%</td><td>67%</td><td>80%</td><td>0%</td><td>0%</td></tr><tr><td>Long-Horizon</td><td>15</td><td>73%</td><td>47%</td><td>73%</td><td>47%</td><td>67%</td><td>60%</td><td>0%</td><td>0%</td></tr><tr><td>Total</td><td>101</td><td>84%</td><td>74%</td><td>81%</td><td>60%</td><td>67%</td><td>74%</td><td>0%</td><td>9%</td></tr></table>

<table><tbody><tr><td></td><td></td><td colspan="2">模擬キッチン</td><td colspan="2">キッチン</td><td colspan="2">適合性なし</td><td colspan="2">LLMなし</td></tr><tr><td></td><td></td><td>\( \mathbf{{PaLM} - } \) SayCan</td><td>\( \mathbf{{PaLM} - } \) SayCan</td><td>\( \mathbf{{PaLM} - } \) SayCan</td><td>\( \mathbf{{PaLM} - } \) SayCan</td><td>\( \mathbf{{NoVF}} \)</td><td>\( \mathbf{{Gen}.} \)</td><td>BC NL</td><td>BC USE</td></tr><tr><td>家族</td><td>\( \mathbf{{Num}} \)</td><td>計画</td><td>実行</td><td>計画</td><td>実行</td><td>計画</td><td>計画</td><td>実行</td><td>実行</td></tr><tr><td>NL単一</td><td>15</td><td>100%</td><td>100%</td><td>93%</td><td>87%</td><td>73%</td><td>87%</td><td>0%</td><td>60%</td></tr><tr><td>NL名詞</td><td>15</td><td>67%</td><td>47%</td><td>60%</td><td>40%</td><td>53%</td><td>53%</td><td>0%</td><td>0%</td></tr><tr><td>NL動詞</td><td>15</td><td>100%</td><td>93%</td><td>93%</td><td>73%</td><td>87%</td><td>93%</td><td>0%</td><td>0%</td></tr><tr><td>構造化</td><td>15</td><td>93%</td><td>87%</td><td>93%</td><td>47%</td><td>93%</td><td>100%</td><td>0%</td><td>0%</td></tr><tr><td>具現化</td><td>11</td><td>64%</td><td>55%</td><td>64%</td><td>55%</td><td>18%</td><td>36%</td><td>0%</td><td>0%</td></tr><tr><td>クラウドソース</td><td>15</td><td>87%</td><td>87%</td><td>73%</td><td>60%</td><td>67%</td><td>80%</td><td>0%</td><td>0%</td></tr><tr><td>長期展望</td><td>15</td><td>73%</td><td>47%</td><td>73%</td><td>47%</td><td>67%</td><td>60%</td><td>0%</td><td>0%</td></tr><tr><td>合計</td><td>101</td><td>84%</td><td>74%</td><td>81%</td><td>60%</td><td>67%</td><td>74%</td><td>0%</td><td>9%</td></tr></tbody></table>

Table 2: Success rates of instructions by family. PaLM-SayCan achieves a planning success rate of \( {84}\% \) and execution success rate of \( {74}\% \) in the training environment and 81% planning and \( {60}\% \) execution in a real kitchen. No VF uses the maximum score skill from the LLM, Generative (Gen.) uses a generative LLM and then projects to the nearest skill via USE embeddings, \( {BCNL} \) uses the policy with the natural language instruction, and BC USE uses the policy with the natural language instruction projected to the nearest skill via USE embeddings.

表2:家族別の指示成功率。PaLM-SayCanは訓練環境で計画成功率\( {84}\% \)、実行成功率\( {74}\% \)を達成し、実際のキッチンでは計画81%、実行\( {60}\% \)を達成している。VFは最大スコアのスキルを使用しない。Generative(Gen.)は生成型LLMを使用し、その後USE埋め込みを介して最も近いスキルに投影する。\( {BCNL} \)は自然言語指示を用いたポリシーを使用し、BC USEは自然言語指示を用いたポリシーをUSE埋め込みを介して最も近いスキルに投影している。

Ablating the Language Model. SayCan is able to improve with improved language models. The LLM used herein was PaLM [9], a 540B parameter model. In this section we ablate over 8B, 62B, and 540B parameter models as well as the 137B parameter FLAN model [8] which is finetuned on a "instruction answering" dataset. Appendix Table 6 shows each model on a set of generative problems, where we find that generally larger models perform better, though the difference between the 62B and 540B model is small. Results in other works, such as Chain of Thought Prompting [24], indicate this difference may be more pronounced on more challenging problems - this is shown in Section 5.2. We also find that PaLM outperforms FLAN. Though FLAN was fine-tuned on instruction answering, the broader and improved dataset for PaLM may make up for this difference in training.

言語モデルのアブレーション。SayCanは、より高度な言語モデルによって改善可能である。ここで使用したLLMはPaLM [9]で、540Bパラメータのモデルである。本節では、8B、62B、540Bパラメータのモデルと、「指示応答」データセットでファインチューニングされた137BパラメータのFLANモデル [8]を比較する。付録表6は、生成問題のセットにおける各モデルの性能を示しており、一般的に大きいモデルほど性能が良いことがわかるが、62Bと540Bのモデル間の差は小さい。Chain of Thought Prompting [24]など他の研究結果も、この差がより難しい問題では顕著になる可能性を示しており、これはセクション5.2で示されている。さらに、PaLMはFLANよりも優れていることもわかる。FLANは指示応答に特化してファインチューニングされているが、より広範で改善されたデータセットを持つPaLMの方がこの差を埋める可能性がある。

While it is expected that the generative performance of the language model will improve with better language models, it is unclear how the LLM size influences the final robotics success rate. Table 3 shows PaLM 540B and FLAN on robot running the full SayCan algorithm. The results show that the system using PaLM with affordance grounding (PaLM-SayCan) chooses the correct sequence of skills 84% of the time and executes them successfully 74% of the time, reducing errors by half compared to FLAN. This is particularly exciting because it represents the first time we can see how an improvement in language models translates to a similar improvement in robotics. This result indicates a potential future where the fields of language processing and robotics can collaboratively improve each other and scale together.

より良い言語モデルによって言語生成の性能は向上すると予想されるが、LLMのサイズが最終的なロボットの成功率にどのように影響するかは不明である。表3は、PaLM 540BとFLANを用いたロボットが全てのSayCanアルゴリズムを実行した結果を示している。結果は、アフォーダンスのグラウンディングを行ったPaLM(PaLM-SayCan)を使用したシステムが正しいスキルのシーケンスを84%、成功裏に実行できたのが74%であり、FLANと比較して誤りを半減させていることを示している。これは、言語モデルの改善がロボティクスの性能向上にどのように直結するかを初めて示すものであり、言語処理とロボティクスの分野が協力して相互に進化できる未来を示唆している。

<table><tr><td/><td/><td colspan="2">PaLM-SayCan</td><td colspan="2">FLAN-SayCan</td></tr><tr><td>Family</td><td>\( \mathbf{{Num}} \)</td><td>Plan</td><td>Execute</td><td>Plan</td><td>Execute</td></tr><tr><td>NL Single</td><td>15</td><td>100%</td><td>100%</td><td>67%</td><td>67%</td></tr><tr><td>NL Nouns</td><td>15</td><td>67%</td><td>47%</td><td>60%</td><td>53%</td></tr><tr><td>NL Verbs</td><td>15</td><td>100%</td><td>93%</td><td>80%</td><td>67%</td></tr><tr><td>Structured</td><td>15</td><td>93%</td><td>87%</td><td>100%</td><td>87%</td></tr><tr><td>Embodiment</td><td>11</td><td>64%</td><td>55%</td><td>64%</td><td>55%</td></tr><tr><td>Crowd Sourced</td><td>15</td><td>87%</td><td>87%</td><td>73%</td><td>67%</td></tr><tr><td>Long-Horizon</td><td>15</td><td>73%</td><td>47%</td><td>47%</td><td>33%</td></tr><tr><td>Total</td><td>101</td><td>84%</td><td>74%</td><td>70%</td><td>61%</td></tr></table>

<table><tbody><tr><td></td><td></td><td colspan="2">PaLM-SayCan</td><td colspan="2">FLAN-SayCan</td></tr><tr><td>家族</td><td>\( \mathbf{{Num}} \)</td><td>計画</td><td>実行</td><td>計画</td><td>実行</td></tr><tr><td>NLシングル</td><td>15</td><td>100%</td><td>100%</td><td>67%</td><td>67%</td></tr><tr><td>NL名詞</td><td>15</td><td>67%</td><td>47%</td><td>60%</td><td>53%</td></tr><tr><td>NL動詞</td><td>15</td><td>100%</td><td>93%</td><td>80%</td><td>67%</td></tr><tr><td>構造化</td><td>15</td><td>93%</td><td>87%</td><td>100%</td><td>87%</td></tr><tr><td>具現化</td><td>11</td><td>64%</td><td>55%</td><td>64%</td><td>55%</td></tr><tr><td>クラウドソース</td><td>15</td><td>87%</td><td>87%</td><td>73%</td><td>67%</td></tr><tr><td>長期展望</td><td>15</td><td>73%</td><td>47%</td><td>47%</td><td>33%</td></tr><tr><td>合計</td><td>101</td><td>84%</td><td>74%</td><td>70%</td><td>61%</td></tr></tbody></table>

Table 3: Success rates of instructions by family. SayCan achieves a planning success rate of 84% and execution success rate of 74% with PaLM and FLAN achieves 70% planning and 61% success. SayCan scales and improves with improved LLMs.

表3:家族別の指示成功率。SayCanは計画成功率84%、実行成功率74%を達成し、PaLMとFLANはそれぞれ計画70%、成功61%を達成しています。SayCanはスケールアップと改善を続けています。

### 5.2 Case Studies of New Capabilities of PaLM-SayCan

### 5.2 PaLM-SayCanの新しい能力の事例研究

PaLM-SayCan enables new capabilities. First, we show that it is very easy to incorporate new skills into the system, and use drawer manipulation as an example. Second, we show by leveraging chain of thought reasoning, we are able to solve complex tasks that require reasoning. Finally we show the system can work with multilingual queries, without explicitly being designed to.

PaLM-SayCanは新しい能力を可能にします。まず、システムに新しいスキルを組み込むのが非常に簡単であることを示し、引き出し操作を例として挙げます。次に、思考の連鎖を活用することで、推論を必要とする複雑なタスクを解決できることを示します。最後に、システムは明示的に設計されていなくても、多言語のクエリに対応できることを示します。

Adding Skills: Drawer Manipulation (Appendix E.3). SayCan is capable of integrating new skills by simply adding the new skills as options for the LLM and providing accompanying value

スキルの追加:引き出し操作(付録E.3)。SayCanは、新しいスキルを単にLLMの選択肢として追加し、それに付随する値関数を提供することで統合可能です。

functions and add an example in the prompt with that skill. For example, with the skills open, close, and go to the drawer, SayCan is capable of solving tasks such as "restock the coke and pepsi into the drawer". Over 21 queries we found a planning rate of \( {100}\% \) and an execution rate of \( {33}\% \) (due to failures of the chained manipulation policy), with no loss in performance for other instructions.

例として、そのスキルをプロンプトに追加します。例えば、「開ける」「閉じる」「引き出しに行く」のスキルを持つ場合、「コーラとペプシを引き出しに補充する」といったタスクを解決できます。21以上のクエリで、計画率は\( {100}\% \)、実行率は\( {33}\% \)(連鎖操作ポリシーの失敗による)となり、他の指示に対して性能の低下はありませんでした。

![bo_d3eb5nk601uc738ioai0_9_311_376_1173_406_0.jpg](images/bo_d3eb5nk601uc738ioai0_9_311_376_1173_406_0.jpg)

Figure 7: A sequence of the robot taking rice chips from the drawers. Note the robot only has one arm, so it needs to plan a long sequence to first take rice chips out of drawer and place on the counter, and then pick it up again after closing the drawer.

図7:ロボットが引き出しから米チップを取り出す一連の動作。ロボットは片腕のみのため、最初に引き出しから米チップを取り出してカウンターに置き、引き出しを閉じた後に再び拾い上げる長いシーケンスを計画する必要があります。

Chain-of-thought planning rollout with PalM-SayCan.

PalM-SayCanによる思考の連鎖計画の展開。

---

		Human: Can you bring a fruit-flavored drink without caffeine?

			人間:カフェインの入っていないフルーツ風味の飲み物を持ってきてくれる？

	Explanation: The user has asked for a drink that is fruit-flavored and does not have caffeine, I will bring the

	説明:ユーザーはフルーツ風味でカフェインの入っていない飲み物を求めているので、私は

lime soda.

ライムソーダを持ってきます。

		Robot: 1. find a lime soda, 2. pick up the lime soda, 3. bring it to you, 4. put down the lime soda, 5. done

			ロボット:1. ライムソーダを見つける、2. ライムソーダを拾う、3. あなたに持っていく、4. ライムソーダを置く、5. 完了

Human: Bring me the spicy chips.

人間:辛いチップスを持ってきてください。

	Explanation: The user has asked for chips that are spicy, I will bring the Jalapeno chips.

	説明:ユーザーは辛いチップスを求めているので、ハラペーニョチップスを持ってきます。

	Robot: 1. find the jalapeno chips, 2. pick up the jalapeno chips, 3. bring it to you, 4. put down the jalapeno

	ロボット:1. ハラペーニョチップスを見つける、2. ハラペーニョチップスを拾う、3. あなたに持っていく、4. ハラペーニョチップスを置く、5. 完了

chips, 5.done

chips、5.完了

Human: The snack is too small, bring me something more filling.

人間:お菓子が小さすぎるので、もっと満腹感のあるものを持ってきてください。

Explanation: The user has asked for a snack that is more filling, I will bring the multigrain chips.

説明:ユーザーはより満腹感のあるおやつを求めているため、マルチグレインチップスを持ってきます。

Robot: 1. find the multigrain chips, 2. pick up the multigrain chips, 3. bring it to you, 4. put down the

ロボット:1. マルチグレインチップスを見つける、2. マルチグレインチップスを拾う、3. それをあなたに持ってくる、4. 置く

multigrain chips, 5 . done

マルチグレインチップスを、5. 完了

---

Table 4: Chain-of-thought planning rollout with PaLM-SayCan. The highlighted part is the chain of thought generated by PaLM-SayCan.

表4:PaLM-SayCanを用いた思考の連鎖計画展開。ハイライトされた部分は、PaLM-SayCanによって生成された思考の連鎖です。

Chain of Thought Reasoning. SayCan can be integrated with recent work improving LLM reasoning, such as Chain of Thought [24]. One limitation of vanilla SayCan is that it doesn't handle tasks that involves negation. This is inherited from underline language models, and studied in the NLP community [19]. However, we found by using chain-of-thought prompting [24] we can improve SayCan on this front.

思考の連鎖推論。SayCanは、Chain of Thought [24]のような最近のLLM推論改善の研究と統合可能です。従来のSayCanの制限の一つは、否定を含むタスクを処理できないことです。これは基盤となる言語モデルに由来し、NLPコミュニティで研究されています [19]。しかし、私たちは思考の連鎖プロンプト [24]を使用することで、この点でSayCanの性能を向上させることができると発見しました。

For chain-of-thought prompting-based SayCan, we need to modify the prompt to include a part called "Explanation". We also slightly change how we use the language model. Instead of directly using the scoring interface to rank possible options, we first use the generative decoding of LLM to create an explanation, and then use the scoring mode, by including the explanation into the prompt. The full prompt is shown in Appendix E. 4 Listing 3.

思考の連鎖プロンプトに基づくSayCanでは、「説明」という部分を含めるようにプロンプトを修正する必要があります。また、言語モデルの使用方法も少し変更します。可能な選択肢をランク付けするためにスコアリングインターフェースを直接使用する代わりに、LLMの生成デコードを用いて説明を作成し、その後スコアリングモードを使用し、説明をプロンプトに含めます。完全なプロンプトは付録E.4リスト3に示されています。

A few successful rollouts of the model at evaluation time is shown in Table 4. As we can see, with chain of thought prompting, the model can handle negations and tasks that require reasoning.

評価時のモデルの成功例のいくつかは表4に示されています。思考の連鎖プロンプトを用いることで、モデルは否定や推論を必要とするタスクを処理できることがわかります。

Multilingual Queries (Appendix E.5). While not explicitly designed to work with multilingual queries, PaLM-SayCan is able to handle them. The LLM was trained on multilingual corpora and thus SayCan can handle multilingual queries other than English. The results of SayCan on multilingual queries are summarized in Table. 8, and there is almost no performance drop in planning success rate when changing the queries from English to Chinese, French and Spanish.

多言語クエリ(付録E.5)。多言語クエリに特化して設計されているわけではありませんが、PaLM-SayCanは対応可能です。LLMは多言語コーパスで訓練されており、SayCanは英語以外の多言語クエリも処理できます。多言語クエリに対するSayCanの結果は表8にまとめられており、英語から中国語、フランス語、スペイン語に変更しても計画成功率にほとんど性能低下はありません。

Closed-Loop Planning. As presented herein, SayCan only receives environmental feedback through value functions at the current decision step, meaning if a skill fails or the environment changes, the necessary feedback may not be available. Owing to the extendibility and the natural language interface, Huang et al. [25] builds upon SayCan to enable closed-loop planning by leveraging environment feedback (from e.g., success detectors, scene descriptors, or even human feedback) through an inner monologue.

クローズドループ計画。ここで示すように、SayCanは現在の意思決定ステップでの価値関数を通じて環境からのフィードバックのみを受け取ります。つまり、スキルが失敗したり環境が変化した場合、必要なフィードバックが得られないことがあります。拡張性と自然言語インターフェースのおかげで、Huangら [25]は、環境からのフィードバック(成功検出器、シーン記述、または人間のフィードバックなど)を内部モノローグを通じて活用し、閉ループ計画を可能にしています。

## 6 Open Source Environment

## 6 オープンソース環境

We have open-sourced an implementation of SayCan in a Google Colab notebook at say-can. github.io/#open-source. The environment is shown in Figure 8 and is a tabletop with a UR5 robot and randomly generated sets of colored blocks and bowls. The low-level policy is implemented with CLIPort [26], which is trained to output a pick and place location. Due to the lack of a value function for this policy, the affordances are implemented with a ViLD object detector [27]. GPT-3 is used as the open source language model [5]. Steps are output in the form "pick up the object and place it in location", leveraging the ability of LLMs to output code structures.

私たちは、SayCanの実装をGoogle Colabノートブックでオープンソース化しました。詳細はsay-can.github.io/#open-sourceをご覧ください。環境は図8に示されており、UR5ロボットとランダムに生成された色付きブロックとボウルのセットを備えたテーブルトップです。低レベルのポリシーはCLIPort [26]を用いて実装されており、ピックと配置の位置を出力します。このポリシーには価値関数がないため、アフォーダンスはViLDオブジェクト検出器 [27]を用いて実装しています。GPT-3はオープンソースの言語モデル [5]として使用されています。ステップは「物体を拾い、所定の場所に置く」という形式で出力され、LLMのコード出力能力を活用しています。

Task: move all the blocks into

タスク:すべてのブロックを

![bo_d3eb5nk601uc738ioai0_10_707_769_778_269_0.jpg](images/bo_d3eb5nk601uc738ioai0_10_707_769_778_269_0.jpg)

their matching colored bowls. Step 1. pick up the blue block and place it in the blue bowl Step 2. pick up the green block and place it in the green bowl Step 3. pick up the yellow block and place it in the yellow bowl

対応する色のボウルに移動させる。ステップ1:青いブロックを拾い、青いボウルに置く。ステップ2:緑のブロックを拾い、緑のボウルに置く。ステップ3:黄色のブロックを拾い、黄色のボウルに置く。

Figure 8: We have open sourced a Colab with a tabletop environment, a UR5 robot, and CLIPort-based policy.

図8:テーブルトップ環境、UR5ロボット、CLIPortベースのポリシーを備えたColabをオープンソース化しました。

## 7 Related Work

## 7 関連研究

Grounding Language Models. A significant body of work has focused on grounding language [28, 29]. Recent works have studied how to ground modern language models, by training them to accept additional environment inputs \( \left\lbrack  {{30},{31},{32},{33},{34}}\right\rbrack \) or to directly output actions \( \left\lbrack  {{35},{36},{37}}\right\rbrack \) . Others grounded language in an environment through prompt engineering [24]. Concurrently with SayCan, Huang et al. [23] use prompt engineering to extract temporally extended plans, but without any additional mechanism to ensure grounding, roughly corresponding to the "Generative" baseline in our experiments. The above methods are all trained without interaction with a physical environment, thus limiting their ability to reason over embodied interactions. One approach to grounding language models in interaction is by learning downstream networks with pre-trained LLM representations [38, \( {22},{21},{39},{40},{41},{42},{43}\rbrack \) . Another approach finetunes language models with interactive data, such as rewards or ranking feedback of the interaction \( \left\lbrack  {{11},{44},{45}}\right\rbrack \) . In our work, SayCan is able to ground language models in the given environment through previously-trained value functions, enabling general, long-horizon behaviors in a zero-shot manner, i.e., without additional training.

言語モデルのグラウンディング。多くの研究が言語のグラウンディングに焦点を当ててきた[28, 29]。最近の研究では、環境の追加入力を受け入れるように訓練したり\( \left\lbrack  {{30},{31},{32},{33},{34}}\right\rbrack \)直接行動を出力したり\( \left\lbrack  {{35},{36},{37}}\right\rbrack \)することで、現代の言語モデルをグラウンディングする方法が研究されている。他には、プロンプトエンジニアリングを通じて環境に言語をグラウンディングする方法もある[24]。SayCanと並行して、Huangら[23]はプロンプトエンジニアリングを用いて時間的に拡張された計画を抽出しているが、グラウンディングを保証する追加の仕組みはなく、我々の実験における「生成」ベースラインに概ね対応している。これらの方法はすべて物理的環境との相互作用なしに訓練されているため、身体化された相互作用を考慮した推論能力は制限されている。言語モデルを相互作用にグラウンディングする一つのアプローチは、事前訓練されたLLMの表現を用いて下流のネットワークを学習することである[38, \( {22},{21},{39},{40},{41},{42},{43}\rbrack \)]。もう一つは、報酬やランキングフィードバックなどのインタラクティブなデータを用いて言語モデルをファインチューニングする方法である\( \left\lbrack  {{11},{44},{45}}\right\rbrack \)。我々の研究では、SayCanは事前に訓練された価値関数を通じて与えられた環境に言語モデルをグラウンディングでき、追加の訓練なしに長期的な一般的行動をゼロショットで実現できる。

Learning Language-Conditioned Behavior. There is a long history of research studying how to connect language and behavior [46, 47, 48, 49, 50]. A large number of prior works have learned language-conditioned behavior via imitation learning [51, 22, 20, 13, 26, 37] or reinforcement learning [52, 53, 49, 54, 55, 56, 21, 41]. Most of these prior works focus on following low-level instructions, such as for pick-and-place tasks and other robotic manipulation primitives \( \left\lbrack  {{20},{22},{56},{21},{13},{26}}\right\rbrack \) , though some methods address long-horizon, compound tasks in simulated domains \( \left\lbrack  {{57},{58},{54}}\right\rbrack \) . Like these latter works, we focus on completing temporally extended tasks. However, a central aspect of our work is to solve such tasks by extracting and leveraging the knowledge in large language models. While prior works have studied how pre-trained language embeddings can improve generalization to new instructions [38, 22, 21] and to new low-level tasks [13], we extract much more substantial knowledge from LLMs by grounding them within the robot's affordances. This allows robots to use language models for planning.

言語条件付行動の学習。言語と行動を結びつける研究には長い歴史がある[46, 47, 48, 49, 50]。多くの先行研究は、模倣学習[51, 22, 20, 13, 26, 37]や強化学習[52, 53, 49, 54, 55, 56, 21, 41]を通じて、言語条件付行動を学習してきた。これらの多くは、ピックアンドプレースタスクやその他のロボット操作プリミティブ\( \left\lbrack  {{20},{22},{56},{21},{13},{26}}\right\rbrack \)のような低レベルの指示に従うことに焦点を当てているが、一部の方法はシミュレーションドメインで長期的かつ複合的なタスクに取り組んでいる\( \left\lbrack  {{57},{58},{54}}\right\rbrack \)。これらの後者の研究と同様に、我々も時間的に拡張されたタスクの完遂に焦点を当てている。ただし、我々の研究の中心的な側面は、大規模な言語モデル内の知識を抽出し、それを活用してこれらのタスクを解決することである。先行研究では、事前訓練された言語埋め込みが新しい指示[38, 22, 21]や新しい低レベルのタスク[13]への一般化を向上させる方法が研究されてきたが、我々はLLMからより実質的な知識を抽出し、それをロボットのアフォーダンス内にグラウンディングすることで、ロボットが計画に言語モデルを利用できるようにしている。

Task Planning and Motion Planning. Task and motion planning [59, 60] is a problem of sequencing tasks to solve a high-level problem, while ensuring the feasibility given an embodiment (task planning [61, 62, 63]; motion planning [64]). Classically, this problem has been solved through symbolic planning [61, 63] or optimization [65, 66], but these require explicit primitives and constraints. Machine learning has recently been applied to enable abstract task specification, allow general primitives, or relax constraints [67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78]. Others learn to hierarchically solve such long-horizon problems [79, 80, 12, 81, 54]. SayCan leverages an LLM’s semantic knowledge about the world for interpreting instructions and understanding how to execute them. The use of LLMs and generality of learned low-level policies enables long-horizon, abstract tasks that scale effectively to the real world, as demonstrated in our robot experiments.

タスク計画と動作計画。タスクおよび動作計画[59, 60]は、高レベルの問題を解決するためのタスクのシーケンスを決定しつつ、身体性を考慮して実現可能性を確保する問題である(タスク計画[61, 62, 63]；動作計画[64])。従来は、この問題は記号的計画[61, 63]や最適化[65, 66]を通じて解決されてきたが、これらは明示的なプリミティブや制約を必要とする。近年、機械学習は抽象的なタスク仕様を可能にし、一般的なプリミティブを許容し、制約を緩和するために応用されている[67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78]。また、階層的に長期的な問題を解決する方法も学習されている[79, 80, 12, 81, 54]。SayCanは、指示の解釈や実行方法の理解にLLMの世界に関する意味的知識を活用している。LLMの利用と学習された低レベルポリシーの一般性により、長期的かつ抽象的なタスクが効果的にスケールし、実世界に適用可能であることをロボット実験で示している。

## 8 Conclusions, Limitations and Future Work

## 8 結論、制限事項および今後の課題

We presented SayCan, a method that enables leveraging and grounding the rich knowledge in large language models to complete embodied tasks. For real-world grounding, we leverage pre-trained skills, which are then used to condition the model to choose natural language actions that are both feasible and contextually appropriate. More specifically, we use reinforcement learning as a way to learn value functions for the individual skills that provide affordances of what is possible in the world, and then use textual labels for these skills as potential responses that are scored by a language model. This combination results in a symbiotic relationship where the skills and their value functions can act as the language model's "hands and eyes," while the language model supplies high-level semantic knowledge about how to complete a task. We evaluated the proposed approach on a number of real-world robotic tasks that involve a mobile manipulator robot accomplishing a large set of long-horizon natural language instructions in a real kitchen. We also demonstrated an exciting property of our method where a robot's performance can be improved simply by enhancing the underlying language model.

私たちは、SayCanと呼ばれる方法を提案しました。これは、大規模言語モデルに蓄積された豊富な知識を活用し、具体的なタスクを完遂するための基盤を提供するものです。実世界でのグラウンディングには、事前に訓練されたスキルを利用し、それを条件付けて自然言語による行動を選択させることで、実行可能かつ文脈に適した行動を促します。具体的には、強化学習を用いて、世界で何が可能かを示す価値関数を学習し、これらのスキルに対して言語ラベルを潜在的な応答として使用し、言語モデルによってスコア付けします。この組み合わせにより、スキルとその価値関数は言語モデルの「手と目」として機能し、一方で言語モデルはタスクを完遂するための高レベルの意味的知識を提供します。提案手法は、実際のキッチンで長期的な自然言語指示を多数達成する移動式マニピュレータロボットを用いた複数の実世界ロボットタスクで評価しました。また、基盤となる言語モデルを強化するだけでロボットの性能が向上するという、我々の手法の魅力的な特性も示しました。

While SayCan presents a viable way to ground language models in agents' affordances, it has a number of limitations. First, we expect this method to inherit the limitations and biases of LLMs [82, 83], including the dependence on the training data. Secondly, we observe that even though SayCan allows the users to interact with the agents using natural language commands, the primary bottleneck of the system is in the range and capabilities of the underlying skills. To illustrate this, we present representative failure cases in Appendix E. Future work that extends the repertoire of skills and improves their robustness would mitigate this limitation. In addition, at the current stage, the system is not easily able to react to situations where individual skills fail despite reporting a high value, though this could potentially be addressed by appropriate prompting of the language model for a correction.

SayCanは、言語モデルをエージェントのアフォーダンスに基づいてグラウンディングする有効な方法を提示していますが、いくつかの制限も存在します。まず、この方法はLLMの制約や偏り(例えば訓練データへの依存)を引き継ぐと予想されます。次に、SayCanは自然言語コマンドを用いたインタラクションを可能にしますが、システムの主なボトルネックは基盤となるスキルの範囲と能力にあります。これを示す代表的な失敗例を付録Eに掲載しています。スキルのレパートリーを拡大し、その堅牢性を向上させる将来の研究は、この制限を緩和するでしょう。また、現段階では、個々のスキルが高い価値を報告しても失敗する状況に対して、システムが容易に反応できない点も課題です。ただし、適切なプロンプトを用いて言語モデルに修正を促すことで対処可能かもしれません。

There are many other potential avenues for future work. A natural question that this work raises is how the information gained through grounding the LLM via real-world robotic experience can be leveraged to improve the language model itself, both in terms of its factuality and its ability to perform common-sense reasoning about real-world environments and physics. Furthermore, since our method uses generic value functions to score affordances, it is intriguing to consider what other sources of grounding could be incorporated in the same manner, such as non-robotic contexts.

今後の研究には多くの可能性があります。本研究が提起する自然な疑問は、実世界のロボット経験を通じて得られた情報を、事実性や常識的推論能力の向上にどのように活用できるかという点です。さらに、我々の手法は汎用的な価値関数を用いてアフォーダンスを評価していますが、同じ方法で非ロボットの文脈など、他のグラウンディングの源泉を取り入れることも興味深い課題です。

In the future, it is also interesting to examine whether natural language is the right ontology to use to program robots: natural language naturally incorporates contextual and semantic cues from the environment, and provides a level of abstraction which enables robots do decide on how to execute a strategy based on its own perception and affordances. At the same time, as opposed to, e.g., hindsight goal images [84], it requires supervision and it might not be the most descriptive medium for certain tasks.

将来的には、自然言語がロボットのプログラミングに適したオントロジーかどうかを検討することも重要です。自然言語は環境からの文脈や意味的手がかりを自然に取り込み、ロボットが自身の知覚やアフォーダンスに基づいて戦略の実行方法を決定できる抽象レベルを提供します。一方で、例えば後知恵的なゴール画像[84]とは異なり、監督が必要であり、特定のタスクにとって最も記述的な媒体ではない可能性もあります。

Lastly, SayCan presents a particular way of connecting and factorizing the challenges of language understanding and robotics, and many further extensions can be proposed. Ideas such as combining robot planning and language [85], using language models as a pre-training mechanism for policies [44] and many other ways of combining language and interaction [21, 22, 38, 86] are exciting avenues for future research.

最後に、SayCanは言語理解とロボティクスの課題を結びつけ、分解する一つの方法を示しています。今後は、ロボット計画と自然言語の統合[85]、ポリシーの事前学習に言語モデルを用いる[44]、および言語とインタラクションを組み合わせる多様なアプローチ[21, 22, 38, 86]など、多くの拡張が提案可能です。

## Acknowledgments

## 謝辞

The authors would like to thank Fred Alcober, Yunfei Bai, Matt Bennice, Maarten Bosma, Justin Boyd, Bill Byrne, Kendra Byrne, Noah Constant, Pete Florence, Laura Graesser, Rico Jon-schkowski, Daniel Kappler, Hugo Larochelle, Benjamin Lee, Adrian Li, Maysam Moussalem, Suraj Nair, Jane Park, Evan Rapoport, Krista Reymann, Jeff Seto, Dhruv Shah, Ian Storz, Razvan Surd-ulescu, Tom Small, and Vincent Zhao for their help and support in various aspects of the project. References

本研究において、Fred Alcober、Yunfei Bai、Matt Bennice、Maarten Bosma、Justin Boyd、Bill Byrne、Kendra Byrne、Noah Constant、Pete Florence、Laura Graesser、Rico Jon-schkowski、Daniel Kappler、Hugo Larochelle、Benjamin Lee、Adrian Li、Maysam Moussalem、Suraj Nair、Jane Park、Evan Rapoport、Krista Reymann、Jeff Seto、Dhruv Shah、Ian Storz、Razvan Surd-ulescu、Tom Small、Vincent Zhaoなど、多くの方々の支援と協力に感謝します。参考文献

[1] E. M. Bender and A. Koller. Climbing towards nlu: On meaning, form, and understanding in the age of data. In Proceedings of the 58th Annual Meeting of the Association for Computational Linguistics, 2020.

[1] E. M. BenderとA. Koller。自然言語理解に向けての階段:意味、形式、理解の時代において。第58回計算言語学会年次大会の議事録、2020年。

[2] A. Vaswani, N. Shazeer, N. Parmar, J. Uszkoreit, L. Jones, A. N. Gomez, Ł. Kaiser, and I. Polo-sukhin. Attention is all you need. Advances in neural information processing systems, 30, 2017.

[2] A. Vaswani、N. Shazeer、N. Parmar、J. Uszkoreit、L. Jones、A. N. Gomez、Ł. Kaiser、I. Polo-sukhin。注意機構はすべてである。ニューラル情報処理システムの進歩、30巻、2017年。

[3] J. Devlin, M.-W. Chang, K. Lee, and K. Toutanova. Bert: Pre-training of deep bidirectional transformers for language understanding. arXiv preprint arXiv:1810.04805, 2018.

[3] J. Devlin、M.-W. Chang、K. Lee、K. Toutanova。BERT:言語理解のための深い双方向トランスフォーマーの事前学習。arXivプレプリントarXiv:1810.04805、2018年。

[4] C. Raffel, N. Shazeer, A. Roberts, K. Lee, S. Narang, M. Matena, Y. Zhou, W. Li, and P. J. Liu. Exploring the limits of transfer learning with a unified text-to-text transformer. Journal of Machine Learning Research, pages 1-67, 2019.

[4] C. Raffel、N. Shazeer、A. Roberts、K. Lee、S. Narang、M. Matena、Y. Zhou、W. Li、P. J. Liuによる、統一されたテキスト・ツー・テキストトランスフォーマーを用いた転移学習の限界の探求。機械学習研究ジャーナル、ページ1-67、2019年。

[5] T. Brown, B. Mann, N. Ryder, M. Subbiah, J. D. Kaplan, P. Dhariwal, A. Neelakantan, P. Shyam, G. Sastry, A. Askell, et al. Language models are few-shot learners. Advances in neural information processing systems, 33:1877-1901, 2020.

[5] T. Brown、B. Mann、N. Ryder、M. Subbiah、J. D. Kaplan、P. Dhariwal、A. Neelakantan、P. Shyam、G. Sastry、A. Askellらによる、言語モデルは少数ショット学習者である。ニューラル情報処理システムの進歩、33巻:1877-1901、2020年。

[6] J. W. Rae, S. Borgeaud, T. Cai, K. Millican, J. Hoffmann, F. Song, J. Aslanides, S. Henderson, R. Ring, S. Young, et al. Scaling language models: Methods, analysis & insights from training gopher. arXiv preprint arXiv:2112.11446, 2021.

[6] J. W. Rae、S. Borgeaud、T. Cai、K. Millican、J. Hoffmann、F. Song、J. Aslanides、S. Henderson、R. Ring、S. Youngらによる、言語モデルのスケーリング:方法、分析、ゴーファーの訓練から得られた洞察。arXivプレプリント arXiv:2112.11446、2021年。

[7] R. Thoppilan, D. De Freitas, J. Hall, N. Shazeer, A. Kulshreshtha, H.-T. Cheng, A. Jin, T. Bos, L. Baker, Y. Du, et al. Lamda: Language models for dialog applications. arXiv preprint arXiv:2201.08239, 2022.

[7] R. Thoppilan、D. De Freitas、J. Hall、N. Shazeer、A. Kulshreshtha、H.-T. Cheng、A. Jin、T. Bos、L. Baker、Y. Duらによる、ダイアログアプリケーション向けの言語モデル:Lamda。arXivプレプリント arXiv:2201.08239、2022年。

[8] J. Wei, M. Bosma, V. Y. Zhao, K. Guu, A. W. Yu, B. Lester, N. Du, A. M. Dai, and Q. V. Le. Finetuned language models are zero-shot learners. arXiv preprint arXiv:2109.01652, 2021.

[8] J. Wei、M. Bosma、V. Y. Zhao、K. Guu、A. W. Yu、B. Lester、N. Du、A. M. Dai、Q. V. Leによる、ファインチューニングされた言語モデルはゼロショット学習者である。arXivプレプリント arXiv:2109.01652、2021年。

[9] A. Chowdhery, S. Narang, J. Devlin, et al. Palm: Scaling language modeling with pathways. 2022. URL https://storage.googleapis.com/pathways-language-model/ PaLM-paper.pdf.

[9] A. Chowdhery、S. Narang、J. Devlinらによる、Palm:パスウェイを用いた言語モデリングのスケーリング。2022年。URL https://storage.googleapis.com/pathways-language-model/ PaLM-paper.pdf。

[10] J. J. Gibson. The theory of affordances. The Ecological Approach to Visual Perception, 1977.

[10] J. J. Gibsonによる、アフォーダンスの理論。『視覚知覚の生態学的アプローチ』、1977年。

[11] L. Ouyang, J. Wu, X. Jiang, D. Almeida, C. L. Wainwright, P. Mishkin, C. Zhang, S. Agarwal, K. Slama, A. Ray, et al. Training language models to follow instructions with human feedback. Preprint, 2022.

[11] L. Ouyang、J. Wu、X. Jiang、D. Almeida、C. L. Wainwright、P. Mishkin、C. Zhang、S. Agarwal、K. Slama、A. Rayらによる、人間のフィードバックを用いた指示に従う言語モデルの訓練。プレプリント、2022年。

[12] D. Shah, P. Xu, Y. Lu, T. Xiao, A. Toshev, S. Levine, and B. Ichter. Value function spaces: Skill-centric state abstractions for long-horizon reasoning. ICLR, 2022. URL https://arxiv.org/pdf/2111.03189.pdf.

[12] D. Shah、P. Xu、Y. Lu、T. Xiao、A. Toshev、S. Levine、B. Ichterによる、価値関数空間:長期的推論のためのスキル中心の状態抽象化。ICLR、2022年。URL https://arxiv.org/pdf/2111.03189.pdf。

[13] E. Jang, A. Irpan, M. Khansari, D. Kappler, F. Ebert, C. Lynch, S. Levine, and C. Finn. Bc-z: Zero-shot task generalization with robotic imitation learning. In Conference on Robot Learning, pages 991-1002. PMLR, 2021.

[13] E. Jang、A. Irpan、M. Khansari、D. Kappler、F. Ebert、C. Lynch、S. Levine、C. Finnによる、Bc-z:ロボット模倣学習によるゼロショットタスク一般化。ロボット学習会議、ページ991-1002。PMLR、2021年。

[14] D. Kalashnikov, J. Varley, Y. Chebotar, B. Swanson, R. Jonschkowski, C. Finn, S. Levine, and K. Hausman. Mt-opt: Continuous multi-task robotic reinforcement learning at scale. arXiv, 2021.

[14] D. Kalashnikov、J. Varley、Y. Chebotar、B. Swanson、R. Jonschkowski、C. Finn、S. Levine、K. Hausmanによる、Mt-opt:大規模な連続多タスクロボット強化学習。arXiv、2021年。

[15] D. Cer, Y. Yang, S.-y. Kong, N. Hua, N. Limtiaco, R. S. John, N. Constant, M. Guajardo-Cespedes, S. Yuan, C. Tar, et al. Universal sentence encoder. arXiv preprint arXiv:1803.11175, 2018.

[15] D. Cer、Y. Yang、S.-y. Kong、N. Hua、N. Limtiaco、R. S. John、N. Constant、M. Guajardo-Cespedes、S. Yuan、C. Tarらによる、ユニバーサル文エンコーダー。arXivプレプリント arXiv:1803.11175、2018年。

[16] D. Ho, K. Rao, Z. Xu, E. Jang, M. Khansari, and Y. Bai. Retinagan: An object-aware approach to sim-to-real transfer. 2021 IEEE International Conference on Robotics and Automation (ICRA), pages 10920-10926, 2021.

[16] D. Ho、K. Rao、Z. Xu、E. Jang、M. Khansari、Y. Baiによる、Retinagan:オブジェクト認識を考慮したシム・リアル転送のアプローチ。2021 IEEE国際ロボット・自動化会議(ICRA)、ページ10920-10926、2021年。

[17] M. Shridhar, J. Thomason, D. Gordon, Y. Bisk, W. Han, R. Mottaghi, L. Zettlemoyer, and D. Fox. Alfred: A benchmark for interpreting grounded instructions for everyday tasks. In Proceedings of the IEEE/CVF conference on computer vision and pattern recognition, pages 10740-10749, 2020.

[17] M. Shridhar、J. Thomason、D. Gordon、Y. Bisk、W. Han、R. Mottaghi、L. Zettlemoyer、D. Foxによる、Alfred:日常タスクのための grounded instructions の解釈のためのベンチマーク。IEEE/CVFコンピュータビジョンとパターン認識会議の proceedings、ページ10740-10749、2020年。

[18] S. Srivastava, C. Li, M. Lingelbach, R. Martín-Martín, F. Xia, K. E. Vainio, Z. Lian, C. Gok-men, S. Buch, K. Liu, et al. Behavior: Benchmark for everyday household activities in virtual, interactive, and ecological environments. In Conference on Robot Learning, pages 477-490. PMLR, 2022.

[18] S. Srivastava, C. Li, M. Lingelbach, R. Martín-Martín, F. Xia, K. E. Vainio, Z. Lian, C. Gok-men, S. Buch, K. Liu, et al. 行動:仮想、インタラクティブ、エコロジカル環境における日常家庭活動のベンチマーク。ロボット学習会議、ページ477-490。PMLR、2022年。

[19] A. Hosseini, S. Reddy, D. Bahdanau, R. D. Hjelm, A. Sordoni, and A. Courville. Understanding by understanding not: Modeling negation in language models. arXiv preprint arXiv:2105.03519, 2021.

[19] A. Hosseini, S. Reddy, D. Bahdanau, R. D. Hjelm, A. Sordoni, and A. Courville. 理解しないことによる理解:言語モデルにおける否定のモデリング。arXivプレプリントarXiv:2105.03519、2021年。

[20] S. Stepputtis, J. Campbell, M. Phielipp, S. Lee, C. Baral, and H. B. Amor. Language-conditioned imitation learning for robot manipulation tasks. ArXiv, abs/2010.12083, 2020.

[20] S. Stepputtis, J. Campbell, M. Phielipp, S. Lee, C. Baral, and H. B. Amor. 言語条件付き模倣学習によるロボット操作タスク。ArXiv、abs/2010.12083、2020年。

[21] S. Nair, E. Mitchell, K. Chen, B. Ichter, S. Savarese, and C. Finn. Learning language-conditioned robot behavior from offline data and crowd-sourced annotation. In Conference on Robot Learning, pages 1303-1315. PMLR, 2021.

[21] S. Nair, E. Mitchell, K. Chen, B. Ichter, S. Savarese, and C. Finn. オフラインデータとクラウドソースの注釈から学習する言語条件付きロボット行動。ロボット学習会議、ページ1303-1315。PMLR、2021年。

[22] C. Lynch and P. Sermanet. Grounding language in play. 2020.

[22] C. Lynch and P. Sermanet. 遊びの中で言語を基盤づける。2020年。

[23] W. Huang, P. Abbeel, D. Pathak, and I. Mordatch. Language models as zero-shot planners: Extracting actionable knowledge for embodied agents. arXiv preprint arXiv:2201.07207, 2022.

[23] W. Huang, P. Abbeel, D. Pathak, and I. Mordatch. ゼロショットプランナーとしての言語モデル:具現化されたエージェントのための実行可能な知識の抽出。arXivプレプリントarXiv:2201.07207、2022年。

[24] J. Wei, X. Wang, D. Schuurmans, M. Bosma, E. Chi, Q. Le, and D. Zhou. Chain of thought prompting elicits reasoning in large language models. arXiv preprint arXiv:2201.11903, 2022.

[24] J. Wei, X. Wang, D. Schuurmans, M. Bosma, E. Chi, Q. Le, and D. Zhou. 思考の連鎖促進による大規模言語モデルの推論誘発。arXivプレプリントarXiv:2201.11903、2022年。

[25] W. Huang, F. Xia, T. Xiao, H. Chan, J. Liang, P. Florence, A. Zeng, J. Tompson, I. Mordatch, Y. Chebotar, et al. Inner monologue: Embodied reasoning through planning with language models. arXiv preprint arXiv:2207.05608, 2022.

[25] W. Huang, F. Xia, T. Xiao, H. Chan, J. Liang, P. Florence, A. Zeng, J. Tompson, I. Mordatch, Y. Chebotar, et al. 内なる独白:言語モデルによる計画を通じた具現化された推論。arXivプレプリントarXiv:2207.05608、2022年。

[26] M. Shridhar, L. Manuelli, and D. Fox. Cliport: What and where pathways for robotic manipulation. In Conference on Robot Learning, 2022.

[26] M. Shridhar, L. Manuelli, and D. Fox. Cliport:ロボット操作のための何とどこパスウェイ。ロボット学習会議、2022年。

[27] X. Gu, T.-Y. Lin, W. Kuo, and Y. Cui. Open-vocabulary object detection via vision and language knowledge distillation. arXiv preprint arXiv:2104.13921, 2021.

[27] X. Gu, T.-Y. Lin, W. Kuo, and Y. Cui. 視覚と言語の知識蒸留によるオープンボキャブラリーの物体検出。arXivプレプリントarXiv:2104.13921、2021年。

[28] J. M. Siskind. Grounding language in perception. Artificial Intelligence Review, 1994.

[28] J. M. Siskind. 言語を知覚に基づかせる。人工知能レビュー、1994年。

[29] T. Winograd. Understanding natural language. Cognitive psychology, 1972.

[29] T. Winograd. 自然言語の理解。認知心理学、1972年。

[30] C. Sun, A. Myers, C. Vondrick, K. Murphy, and C. Schmid. Videobert: A joint model for video and language representation learning. In Proceedings of the IEEE/CVF International Conference on Computer Vision, 2019.

[30] C. Sun, A. Myers, C. Vondrick, K. Murphy, and C. Schmid. VideoBERT:動画と言語表現学習のための共同モデル。IEEE/CVF国際会議の proceedings、2019年。

[31] L. H. Li, M. Yatskar, D. Yin, C.-J. Hsieh, and K.-W. Chang. Visualbert: A simple and performant baseline for vision and language. arXiv preprint arXiv:1908.03557, 2019.

[31] L. H. Li, M. Yatskar, D. Yin, C.-J. Hsieh, and K.-W. Chang. VisualBERT:視覚と言語のためのシンプルで高性能なベースライン。arXivプレプリントarXiv:1908.03557、2019年。

[32] J. Lu, D. Batra, D. Parikh, and S. Lee. Vilbert: Pretraining task-agnostic visiolinguistic representations for vision-and-language tasks. Advances in neural information processing systems, 2019.

[32] J. Lu, D. Batra, D. Parikh, and S. Lee. VilBERT:視覚と言語のタスクに対する事前学習されたタスク非依存の視覚言語表現。ニューラル情報処理システムの進歩、2019年。

[33] R. Zellers, X. Lu, J. Hessel, Y. Yu, J. S. Park, J. Cao, A. Farhadi, and Y. Choi. Merlot: Multimodal neural script knowledge models. Advances in Neural Information Processing Systems, 2021.

[33] R. Zellers, X. Lu, J. Hessel, Y. Yu, J. S. Park, J. Cao, A. Farhadi, and Y. Choi. Merlot:マルチモーダルニューラルスクリプト知識モデル。ニューラル情報処理システムの進歩、2021年。

[34] A. Radford, J. W. Kim, C. Hallacy, A. Ramesh, G. Goh, S. Agarwal, G. Sastry, A. Askell, P. Mishkin, J. Clark, et al. Learning transferable visual models from natural language supervision. In International Conference on Machine Learning, 2021.

[34] A. Radford, J. W. Kim, C. Hallacy, A. Ramesh, G. Goh, S. Agarwal, G. Sastry, A. Askell, P. Mishkin, J. Clark, et al. 自然言語監督からの転送可能な視覚モデルの学習。国際機械学習会議2021年版。

[35] A. Suglia, Q. Gao, J. Thomason, G. Thattai, and G. Sukhatme. Embodied bert: A transformer model for embodied, language-guided visual task completion. arXiv preprint arXiv:2108.04927, 2021.

[35] A. Suglia, Q. Gao, J. Thomason, G. Thattai, G. Sukhatme. embodied bert: 身体化された、言語誘導型視覚タスク完了のためのトランスフォーマーモデル。arXivプレプリント arXiv:2108.04927, 2021年。

[36] A. Pashevich, C. Schmid, and C. Sun. Episodic transformer for vision-and-language navigation. In Proceedings of the IEEE/CVF International Conference on Computer Vision, 2021.

[36] A. Pashevich, C. Schmid, C. Sun. 視覚と言語ナビゲーションのためのエピソディックトランスフォーマー。IEEE/CVF国際コンピュータビジョン会議の proceedings, 2021年。

[37] P. Sharma, A. Torralba, and J. Andreas. Skill induction and planning with latent language. arXiv preprint arXiv:2110.01517, 2021.

[37] P. Sharma, A. Torralba, J. Andreas. 潜在言語によるスキル誘導と計画。arXivプレプリント arXiv:2110.01517, 2021年。

[38] F. Hill, S. Mokra, N. Wong, and T. Harley. Human instruction-following with deep reinforcement learning via transfer-learning from text. arXiv preprint arXiv:2005.09382, 2020.

[38] F. Hill, S. Mokra, N. Wong, T. Harley. テキストからの転移学習を用いた深層強化学習による人間の指示追従。arXivプレプリント arXiv:2005.09382, 2020年。

[39] V. Blukis, C. Paxton, D. Fox, A. Garg, and Y. Artzi. A persistent spatial semantic representation for high-level natural language instruction execution. In Conference on Robot Learning, 2022.

[39] V. Blukis, C. Paxton, D. Fox, A. Garg, Y. Artzi. 高レベルの自然言語指示実行のための持続的空間意味表現。ロボット学習会議2022年。

[40] S. Nair, A. Rajeswaran, V. Kumar, C. Finn, and A. Gupta. R3m: A universal visual representation for robot manipulation. arXiv preprint arXiv:2203.12601, 2022.

[40] S. Nair, A. Rajeswaran, V. Kumar, C. Finn, A. Gupta. R3m: ロボット操作のための普遍的視覚表現。arXivプレプリント arXiv:2203.12601, 2022年。

[41] A. Akakzia, C. Colas, P.-Y. Oudeyer, M. Chetouani, and O. Sigaud. Grounding language to autonomously-acquired skills via goal generation. arXiv preprint arXiv:2006.07185, 2020.

[41] A. Akakzia, C. Colas, P.-Y. Oudeyer, M. Chetouani, O. Sigaud. 目標生成を通じた自律的獲得スキルへの言語の基盤付け。arXivプレプリント arXiv:2006.07185, 2020年。

[42] R. Zellers, A. Holtzman, M. Peters, R. Mottaghi, A. Kembhavi, A. Farhadi, and Y. Choi. Piglet: Language grounding through neuro-symbolic interaction in a 3d world. arXiv preprint arXiv:2106.00188, 2021.

[42] R. Zellers, A. Holtzman, M. Peters, R. Mottaghi, A. Kembhavi, A. Farhadi, Y. Choi. Piglet: 3D世界における神経記号的相互作用による言語基盤付け。arXivプレプリント arXiv:2106.00188, 2021年。

[43] P. C. Humphreys, D. Raposo, T. Pohlen, G. Thornton, R. Chhaparia, A. Muldal, J. Abramson, P. Georgiev, A. Goldin, A. Santoro, et al. A data-driven approach for learning to control computers. arXiv preprint arXiv:2202.08137, 2022.

[43] P. C. Humphreys, D. Raposo, T. Pohlen, G. Thornton, R. Chhaparia, A. Muldal, J. Abramson, P. Georgiev, A. Goldin, A. Santoro, et al. コンピュータ制御学習のためのデータ駆動型アプローチ。arXivプレプリント arXiv:2202.08137, 2022年。

[44] M. Reid, Y. Yamada, and S. S. Gu. Can wikipedia help offline reinforcement learning. arXiv preprint arXiv:2201.12122, 2022.

[44] M. Reid, Y. Yamada, S. S. Gu. Wikipediaはオフライン強化学習に役立つか。arXivプレプリント arXiv:2201.12122, 2022年。

[45] S. Li, X. Puig, Y. Du, C. Wang, E. Akyurek, A. Torralba, J. Andreas, and I. Mordatch. Pre-trained language models for interactive decision-making. arXiv preprint arXiv:2202.01771, 2022.

[45] S. Li, X. Puig, Y. Du, C. Wang, E. Akyurek, A. Torralba, J. Andreas, I. Mordatch. 対話型意思決定のための事前学習済み言語モデル。arXivプレプリント arXiv:2202.01771, 2022年。

[46] M. MacMahon, B. Stankiewicz, and B. Kuipers. Walk the talk: Connecting language, knowledge, and action in route instructions. 012006.

[46] M. MacMahon, B. Stankiewicz, B. Kuipers. 言語、知識、行動をつなぐ:ルート指示のための歩行と話すこと。012006。

[47] T. Kollar, S. Tellex, D. Roy, and N. Roy. Toward understanding natural language directions. In HRI 2010, 2010.

[47] T. Kollar, S. Tellex, D. Roy, N. Roy. 自然言語指示の理解に向けて。HRI 2010。

[48] S. Tellex, T. Kollar, S. Dickerson, M. Walter, A. Banerjee, S. Teller, and N. Roy. Understanding natural language commands for robotic navigation and mobile manipulation. volume 2,01 2011.

[48] S. Tellex, T. Kollar, S. Dickerson, M. Walter, A. Banerjee, S. Teller, N. Roy. ロボットナビゲーションと移動操作のための自然言語コマンドの理解。第2巻、2011年1月。

[49] J. Luketina, N. Nardelli, G. Farquhar, J. N. Foerster, J. Andreas, E. Grefenstette, S. Whiteson, and T. Rocktäschel. A survey of reinforcement learning informed by natural language. In IJCAI, 2019.

[49] J. Luketina, N. Nardelli, G. Farquhar, J. N. Foerster, J. Andreas, E. Grefenstette, S. Whiteson, T. Rocktäschel. 自然言語に基づく強化学習の調査。IJCAI 2019年。

[50] S. Tellex, N. Gopalan, H. Kress-Gazit, and C. Matuszek. Robots that use language. Annual Review of Control, Robotics, and Autonomous Systems, 2020.

[50] S. Tellex、N. Gopalan、H. Kress-Gazit、C. Matuszekによる言語を使用するロボット。制御、ロボティクス、自律システムの年次レビュー、2020年。

[51] H. Mei, M. Bansal, and M. R. Walter. Listen, attend, and walk: Neural mapping of navigational instructions to action sequences. In \( {AAAI},{2016} \) .

[51] H. Mei、M. Bansal、M. R. Walterによる聞く、注目する、歩く:ナビゲーション指示を行動シーケンスにニューラルマッピングする。\( {AAAI},{2016} \)にて。

[52] D. K. Misra, J. Langford, and Y. Artzi. Mapping instructions and visual observations to actions with reinforcement learning. In EMNLP, 2017.

[52] D. K. Misra、J. Langford、Y. Artziによる指示と視覚観察を強化学習で行動にマッピング。EMNLP、2017年。

[53] K. Hermann, F. Hill, S. Green, F. Wang, R. Faulkner, H. Soyer, D. Szepesvari, W. Czarnecki, M. Jaderberg, D. Teplyashin, M. Wainwright, C. Apps, D. Hassabis, and P. Blunsom. Grounded language learning in a simulated 3d world. ArXiv, abs/1706.06551, 2017.

[53] K. Hermann、F. Hill、S. Green、F. Wang、R. Faulkner、H. Soyer、D. Szepesvari、W. Czarnecki、M. Jaderberg、D. Teplyashin、M. Wainwright、C. Apps、D. Hassabis、P. Blunsomによるシミュレートされた3D世界における grounded language learning。ArXiv、abs/1706.06551、2017年。

[54] Y. Jiang, S. Gu, K. Murphy, and C. Finn. Language as an abstraction for hierarchical deep reinforcement learning. In NeurIPS, 2019.

[54] Y. Jiang、S. Gu、K. Murphy、C. Finnによる階層的深層強化学習の抽象化としての言語。NeurIPS、2019年。

[55] G. Cideron, M. Seurin, F. Strub, and O. Pietquin. Self-educated language agent with hindsight experience replay for instruction following. ArXiv, abs/1910.09451, 2019.

[55] G. Cideron、M. Seurin、F. Strub、O. Pietquin。指示に従うための自己教育型言語エージェントと後知恵経験リプレイ。ArXiv、abs/1910.09451、2019年。

[56] P. Goyal, S. Niekum, and R. Mooney. Pixl2r: Guiding reinforcement learning using natural language by mapping pixels to rewards. ArXiv, abs/2007.15543, 2020.

[56] P. Goyal、S. Niekum、R. Mooney。Pixl2r:ピクセルを報酬にマッピングして自然言語を用いた強化学習の誘導。ArXiv、abs/2007.15543、2020年。

[57] J. Oh, S. Singh, H. Lee, and P. Kohli. Zero-shot task generalization with multi-task deep reinforcement learning. ArXiv, abs/1706.05064, 2017.

[57] J. Oh、S. Singh、H. Lee、P. Kohli。マルチタスク深層強化学習によるゼロショットタスク一般化。ArXiv、abs/1706.05064、2017年。

[58] J. Andreas, D. Klein, and S. Levine. Modular multitask reinforcement learning with policy sketches. ArXiv, abs/1611.01796, 2017.

[58] J. Andreas、D. Klein、S. Levine。ポリシースケッチを用いたモジュール式マルチタスク強化学習。ArXiv、abs/1611.01796、2017年。

[59] L. P. Kaelbling and T. Lozano-Pérez. Hierarchical planning in the now. In Workshops at the Twenty-Fourth AAAI Conference on Artificial Intelligence, 2010.

[59] L. P. Kaelbling、T. Lozano-Pérez。今この瞬間の階層的計画。第24回人工知能会議ワークショップ、2010年。

[60] S. Srivastava, E. Fang, L. Riano, R. Chitnis, S. Russell, and P. Abbeel. Combined task and motion planning through an extensible planner-independent interface layer. In 2014 IEEE international conference on robotics and automation (ICRA), 2014.

[60] S. Srivastava、E. Fang、L. Riano、R. Chitnis、S. Russell、P. Abbeel。拡張可能なプランナー非依存インターフェース層を通じたタスクと動作計画の統合。2014 IEEE国際ロボット・自動化会議(ICRA)、2014年。

[61] R. E. Fikes and N. J. Nilsson. Strips: A new approach to the application of theorem proving to problem solving. Artificial intelligence, 1971.

[61] R. E. Fikes、N. J. Nilsson。Strips:定理証明の応用による問題解決への新しいアプローチ。人工知能、1971年。

[62] E. D. Sacerdoti. A structure for plans and behavior. Technical report, SRI International, Menlo Park California Artificial Intelligence Center, 1975.

[62] E. D. Sacerdoti。計画と行動の構造。技術報告書、SRIインターナショナル、メンロパークカリフォルニア人工知能センター、1975年。

[63] D. Nau, Y. Cao, A. Lotem, and H. Munoz-Avila. Shop: Simple hierarchical ordered planner. 1999.

[63] D. Nau、Y. Cao、A. Lotem、H. Munoz-Avila。Shop:シンプルな階層型順序プランナー。1999年。

[64] S. M. LaValle. Planning algorithms. 2006.

[64] S. M. LaValle。計画アルゴリズム。2006年。

[65] M. Toussaint. Logic-geometric programming: An optimization-based approach to combined task and motion planning. In Twenty-Fourth International Joint Conference on Artificial Intelligence, 2015.

[65] M. Toussaint。論理幾何プログラミング:タスクと動作計画の最適化に基づくアプローチ。第24回国際人工知能会議、2015年。

[66] M. A. Toussaint, K. R. Allen, K. A. Smith, and J. B. Tenenbaum. Differentiable physics and stable modes for tool-use and manipulation planning. 2018.

[66] M. A. Toussaint、K. R. Allen、K. A. Smith、J. B. Tenenbaum。ツール使用と操作計画のための微分可能な物理学と安定モード。2018年。

[67] D. Xu, S. Nair, Y. Zhu, J. Gao, A. Garg, L. Fei-Fei, and S. Savarese. Neural task programming: Learning to generalize across hierarchical tasks. In 2018 IEEE International Conference on Robotics and Automation (ICRA), 2018.

[67] D. Xu、S. Nair、Y. Zhu、J. Gao、A. Garg、L. Fei-Fei、S. Savarese。ニューラルタスクプログラミング:階層的タスク間の一般化を学習。2018 IEEE国際ロボット・自動化会議(ICRA)、2018年。

[68] D. Xu, R. Martín-Martín, D.-A. Huang, Y. Zhu, S. Savarese, and L. F. Fei-Fei. Regression planning networks. Advances in Neural Information Processing Systems, 32, 2019.

[68] D. Xu、R. Martín-Martín、D.-A. Huang、Y. Zhu、S. Savarese、L. F. Fei-Fei。回帰計画ネットワーク。Neural Information Processing Systemsの進歩、32、2019年。

[69] D.-A. Huang, S. Nair, D. Xu, Y. Zhu, A. Garg, L. Fei-Fei, S. Savarese, and J. C. Niebles. Neural task graphs: Generalizing to unseen tasks from a single video demonstration. In Proceedings of the IEEE/CVF Conference on Computer Vision and Pattern Recognition, 2019.

[69] D.-A. Huang、S. Nair、D. Xu、Y. Zhu、A. Garg、L. Fei-Fei、S. Savarese、J. C. Niebles。ニューラルタスクグラフ:単一のビデオデモから未見のタスクへの一般化。IEEE/CVFコンピュータビジョンとパターン認識会議の論文集、2019年。

[70] B. Eysenbach, R. R. Salakhutdinov, and S. Levine. Search on the replay buffer: Bridging planning and reinforcement learning. Advances in Neural Information Processing Systems, 2019.

[70] B. Eysenbach、R. R. Salakhutdinov、S. Levine。リプレイバッファ上の探索:計画と強化学習の橋渡し。Neural Information Processing Systemsの進歩、2019年。

[71] N. Savinov, A. Dosovitskiy, and V. Koltun. Semi-parametric topological memory for navigation. arXiv preprint arXiv:1803.00653, 2018.

[71] N. Savinov、A. Dosovitskiy、V. Koltun。ナビゲーションのための半パラメトリックトポロジカルメモリ。arXivプレプリント arXiv:1803.00653、2018年。

[72] B. Ichter, P. Sermanet, and C. Lynch. Broadly-exploring, local-policy trees for long-horizon task planning. Conference on Robot Learning (CoRL), 2021.

[72] B. Ichter、P. Sermanet、C. Lynch。長期目標計画のための広範囲探索、局所ポリシーツリー。ロボット学習会議(CoRL)、2021年。

[73] C. Matuszek, N. FitzGerald, L. Zettlemoyer, L. Bo, and D. Fox. A joint model of language and perception for grounded attribute learning. arXiv preprint arXiv:1206.6423, 2012.

[73] C. Matuszek、N. FitzGerald、L. Zettlemoyer、L. Bo、D. Fox。 grounded attribute learningのための言語と知覚の共同モデル。arXivプレプリント arXiv:1206.6423、2012年。

[74] T. Silver, R. Chitnis, N. Kumar, W. McClinton, T. Lozano-Perez, L. P. Kaelbling, and J. Tenenbaum. Inventing relational state and action abstractions for effective and efficient bilevel planning. arXiv preprint arXiv:2203.09634, 2022.

[74] T. Silver、R. Chitnis、N. Kumar、W. McClinton、T. Lozano-Perez、L. P. Kaelbling、J. Tenenbaum。効果的かつ効率的な二層計画のための関係状態とアクション抽象化の発明。arXivプレプリント arXiv:2203.09634、2022年。

[75] C. R. Garrett, C. Paxton, T. Lozano-Pérez, L. P. Kaelbling, and D. Fox. Online replanning in belief space for partially observable task and motion problems. In 2020 IEEE International Conference on Robotics and Automation (ICRA), 2020.

[75] C. R. Garrett、C. Paxton、T. Lozano-Pérez、L. P. Kaelbling、D. Fox。部分観測可能なタスクと動作問題における信念空間でのオンライン再計画。2020年IEEEロボット・自動化国際会議(ICRA)にて。

[76] Y. Zhu, D. Gordon, E. Kolve, D. Fox, L. Fei-Fei, A. Gupta, R. Mottaghi, and A. Farhadi. Visual semantic planning using deep successor representations. In Proceedings of the IEEE international conference on computer vision, 2017.

[76] Y. Zhu、D. Gordon、E. Kolve、D. Fox、L. Fei-Fei、A. Gupta、R. Mottaghi、A. Farhadi。深層後継表現を用いた視覚意味論計画。IEEE国際会議の proceedings、2017年。

[77] D. K. Misra, J. Sung, K. Lee, and A. Saxena. Tell me dave: Context-sensitive grounding of natural language to manipulation instructions. The International Journal of Robotics Research, 2016.

[77] D. K. Misra、J. Sung、K. Lee、A. Saxena。Tell me dave:操作指示への自然言語のコンテキスト感知的グラウンディング。国際ロボット研究ジャーナル、2016年。

[78] B. Wu, S. Nair, L. Fei-Fei, and C. Finn. Example-driven model-based reinforcement learning for solving long-horizon visuomotor tasks. In 5th Annual Conference on Robot Learning, 2021.

[78] B. Wu、S. Nair、L. Fei-Fei、C. Finn。長期視覚運動タスク解決のための例駆動型モデルベース強化学習。第5回ロボット学習年次会議、2021年。

[79] S. Nair and C. Finn. Hierarchical foresight: Self-supervised learning of long-horizon tasks via visual subgoal generation. ArXiv, abs/1909.05829, 2020.

[79] S. Nair、C. Finn。階層的先見:視覚的サブゴール生成による長期タスクの自己教師あり学習。ArXiv、abs/1909.05829、2020年。

[80] F. Xia, C. Li, R. Martín-Martín, O. Litany, A. Toshev, and S. Savarese. Relmogen: Integrating motion generation in reinforcement learning for mobile manipulation. In 2021 IEEE International Conference on Robotics and Automation (ICRA), 2021.

[80] F. Xia、C. Li、R. Martín-Martín、O. Litany、A. Toshev、S. Savarese。Relmogen:移動操作のための強化学習における動作生成の統合。2021 IEEEロボット・自動化国際会議(ICRA)、2021年。

[81] C. Li, F. Xia, R. Martin-Martin, and S. Savarese. Hrl4in: Hierarchical reinforcement learning for interactive navigation with mobile manipulators. In Conference on Robot Learning, 2020.

[81] C. Li、F. Xia、R. Martin-Martin、S. Savarese。Hrl4in:移動操作ロボットによるインタラクティブナビゲーションのための階層的強化学習。ロボット学習会議、2020年。

[82] E. M. Bender, T. Gebru, A. McMillan-Major, and S. Shmitchell. On the dangers of stochastic parrots: Can language models be too big? In Proceedings of the 2021 ACM Conference on Fairness, Accountability, and Transparency, pages 610-623, 2021.

[82] E. M. Bender、T. Gebru、A. McMillan-Major、S. Shmitchell。確率的オウムの危険性について:言語モデルは大きすぎることができるか？2021年ACM公正性・説明責任・透明性会議の proceedings、ページ610-623、2021年。

[83] R. Bommasani, D. A. Hudson, E. Adeli, R. Altman, S. Arora, S. von Arx, M. S. Bernstein, J. Bohg, A. Bosselut, E. Brunskill, et al. On the opportunities and risks of foundation models. arXiv preprint arXiv:2108.07258, 2021.

[83] R. Bommasani、D. A. Hudson、E. Adeli、R. Altman、S. Arora、S. von Arx、M. S. Bernstein、J. Bohg、A. Bosselut、E. Brunskill、他。基盤モデルの機会とリスクについて。arXivプレプリント arXiv:2108.07258、2021年。

[84] Y. Chebotar, K. Hausman, Y. Lu, T. Xiao, D. Kalashnikov, J. Varley, A. Irpan, B. Eysenbach, R. C. Julian, C. Finn, and S. Levine. Actionable models: Unsupervised offline reinforcement learning of robotic skills. ArXiv, abs/2104.07749, 2021.

[84] Y. Chebotar、K. Hausman、Y. Lu、T. Xiao、D. Kalashnikov、J. Varley、A. Irpan、B. Eysenbach、R. C. Julian、C. Finn、S. Levine。実用的なモデル:ロボットスキルの教師なしオフライン強化学習。ArXiv、abs/2104.07749、2021年。

[85] S. Tellex, R. Knepper, A. Li, D. Rus, and N. Roy. Asking for help using inverse semantics. 2014.

[85] S. Tellex、R. Knepper、A. Li、D. Rus、N. Roy。逆意味論を用いた助けを求める方法。2014年。

[86] S. I. Wang, P. Liang, and C. D. Manning. Learning language games through interaction. arXiv preprint arXiv:1606.02447, 2016.

[86] S. I. Wang、P. Liang、C. D. Manning。インタラクションを通じて言語ゲームを学習する。arXivプレプリント arXiv:1606.02447、2016年。

[87] T. Xiao, E. Jang, D. Kalashnikov, S. Levine, J. Ibarz, K. Hausman, and A. Herzog. Thinking while moving: Deep reinforcement learning with concurrent control. In International Conference on Learning Representations, 2019.

[87] T. Xiao, E. Jang, D. Kalashnikov, S. Levine, J. Ibarz, K. Hausman, and A. Herzog. Thinking while moving: Deep reinforcement learning with concurrent control. In International Conference on Learning Representations, 2019.

[88] T. Schaul, J. Quan, I. Antonoglou, and D. Silver. Prioritized experience replay. In ICLR, 2016.

[88] T. Schaul, J. Quan, I. Antonoglou, and D. Silver. Prioritized experience replay. In ICLR, 2016.

## A Version Control

## バージョン管理

\( \mathrm{v}1 \rightarrow  \mathrm{v}2 \) : Added PaLM results. Added study about new capabilities (drawer manipulation, chain of thought prompting, multilingual instructions). Added an ablation study of language model size. Added an open-source version of SayCan on a simulated tabletop environment. Improved readability.

\( \mathrm{v}1 \rightarrow  \mathrm{v}2 \) : PaLMの結果を追加。新しい機能(引き出し操作、思考の連鎖促進、多言語指示)に関する研究を追加。言語モデルのサイズに関するアブレーション研究を追加。シミュレーテッドテーブルトップ環境でのSayCanのオープンソース版を追加。可読性を向上させた。

## B Contributions

## B 貢献

### B.1 By Type

### B.1 種類別

- Designed and built distributed robot learning infrastructure: Michael Ahn, Anthony Brohan, Noah Brown, Yevgen Chebotar, Byron David, Chuyuan Fu, Keerthana Gopalakr-ishnan, Karol Hausman, Alex Herzog, Daniel Ho, Jasmine Hsu, Julian Ibarz, Alex Irpan, Eric Jang, Nikhil J Joshi, Ryan Julian, Dmitry Kalashnikov, Yuheng Kuang, Yao Lu, Peter Pastor, Kanishka Rao, Nicolas Sievers, Fei Xia, Ted Xiao, Peng Xu, Sichun Xu, and Mengyuan Yan.

- 分散型ロボット学習インフラストラクチャの設計と構築:Michael Ahn、Anthony Brohan、Noah Brown、Yevgen Chebotar、Byron David、Chuyuan Fu、Keerthana Gopalakr-ishnan、Karol Hausman、Alex Herzog、Daniel Ho、Jasmine Hsu、Julian Ibarz、Alex Irpan、Eric Jang、Nikhil J Joshi、Ryan Julian、Dmitry Kalashnikov、Yuheng Kuang、Yao Lu、Peter Pastor、Kanishka Rao、Nicolas Sievers、Fei Xia、Ted Xiao、Peng Xu、Sichun Xu、Mengyuan Yan。

- Designed, implemented, or trained the underlying manipulation policies: Yevgen Chebotar, Keerthana Gopalakrishnan, Karol Hausman, Julian Ibarz, Alex Irpan, Eric Jang, Nikhil Joshi, Ryan Julian, Kuang-Huei Lee, Yao Lu, Kanishka Rao, and Ted Xiao.

- 操作ポリシーの設計、実装、または訓練:Yevgen Chebotar、Keerthana Gopalakrishnan、Karol Hausman、Julian Ibarz、Alex Irpan、Eric Jang、Nikhil Joshi、Ryan Julian、Kuang-Huei Lee、Yao Lu、Kanishka Rao、Ted Xiao。

- Designed or implemented the data generation and curation or collected data: Noah Brown, Omar Cortes, Jasmine Hsu, Alex Irpan, Eric Jang, Rosario Jauregui Ruano, Kyle Jeffrey, Linda Luu, Jornell Quiambao, Kanishka Rao, Jarek Rettinghouse, Diego Reyes, Pierre Sermanet, Clayton Tan, and Sichun Xu.

- データ生成、キュレーション、または収集の設計または実装:Noah Brown、Omar Cortes、Jasmine Hsu、Alex Irpan、Eric Jang、Rosario Jauregui Ruano、Kyle Jeffrey、Linda Luu、Jornell Quiambao、Kanishka Rao、Jarek Rettinghouse、Diego Reyes、Pierre Sermanet、Clayton Tan、Sichun Xu。

- Designed or implemented SayCan: Karol Hausman, Brian Ichter, Sergey Levine, Alexander Toshev, and Fei Xia.

- SayCanの設計または実装:Karol Hausman、Brian Ichter、Sergey Levine、Alexander Toshev、Fei Xia。

- Managed or advised on the project: Chelsea Finn, Karol Hausman, Eric Jang, Sally Jesmonth, Sergey Levine, Yao Lu, Carolina Parada, Kanishka Rao, Alexander Toshev, and Vincent Vanhoucke.

- プロジェクトの管理または助言:Chelsea Finn、Karol Hausman、Eric Jang、Sally Jesmonth、Sergey Levine、Yao Lu、Carolina Parada、Kanishka Rao、Alexander Toshev、Vincent Vanhoucke。

- Ran evaluations or experiments: Noah Brown, Omar Cortes, Brian Ichter, Rosario Jau-regui Ruano, Kyle Jeffrey, Linda Luu, Jornell Quiambao, Jarek Rettinghouse, Diego Reyes, Clayton Tan, and Fei Xia.

- 評価や実験の実施:Noah Brown、Omar Cortes、Brian Ichter、Rosario Jau-regui Ruano、Kyle Jeffrey、Linda Luu、Jornell Quiambao、Jarek Rettinghouse、Diego Reyes、Clayton Tan、Fei Xia。

- Scaled simulation infrastructure: Nikhil J Joshi, Yao Lu, Kanishka Rao, and Ted Xiao.

- シミュレーションインフラの拡張:Nikhil J Joshi、Yao Lu、Kanishka Rao、Ted Xiao。

- Wrote the paper: Chelsea Finn, Karol Hausman, Brian Ichter, Alex Irpan, Sergey Levine, Fei Xia, and Ted Xiao.

- 論文執筆:Chelsea Finn、Karol Hausman、Brian Ichter、Alex Irpan、Sergey Levine、Fei Xia、Ted Xiao。

- Created open-source environment: Brian Ichter, Andy Zeng.

- オープンソース環境の作成:Brian Ichter、Andy Zeng。

### B.2 By Person

### B.2 人別

Michael Ahn developed the deployment system that enabled the ability to scale up data collection on real robots.

マイケル・アンは、実ロボット上でのデータ収集を拡張可能にするデプロイメントシステムを開発した。

Anthony Brohan implemented the logging system for the project and designed and implemented the data labeling pipelines.

アンソニー・ブロハンは、プロジェクトのロギングシステムを実装し、データラベリングパイプラインの設計と実装を行った。

Noah Brown led and coordinated the real-robot operations including data collection with teleoper-ators, evaluations and the real-world setup.

ノア・ブラウンは、遠隔操作によるデータ収集、評価、実世界のセットアップを含む実ロボットの運用を指導・調整した。

Yevgen Chebotar designed and implemented multiple offline RL methods allowing the manipulation policies to process data coming from different sources.

イェフゲン・チェボタルは、異なるソースからのデータを処理できる複数のオフライン強化学習(RL)手法を設計・実装した。

Omar Cortes collected data on the robots and ran and supervised real-world evaluations.

オマール・コルテスは、ロボットのデータ収集と実世界評価の実行・監督を行った。

Byron David developed simulation assets and performed system identification.

バイロン・デイビッドは、シミュレーション資産の開発とシステム識別を行った。

Chelsea Finn advised on the project, helped set the research direction and wrote parts of the paper. Chuyuan Fu developed deformable objects and experimented with sim-to-real techniques.

チェルシー・フィンは、プロジェクトの助言を行い、研究の方向性設定や論文の一部執筆を支援した。チュユアン・フーは、変形可能な物体の開発とシミュレーションから実世界への技術の実験を行った。

Keerthana Gopalakrishnan provided multiple infrastructure contributions that allowed for scalable learning of manipulation policies.

キールタナ・ゴパラクシュナンは、操作ポリシーのスケーラブルな学習を可能にする複数のインフラストラクチャの貢献を行った。

Karol Hausman co-led the project as well as developed SayCan, helped set the research direction, trained the underlying manipulation policies, and wrote the paper.

カロル・ハウスマンは、プロジェクトの共同リーダーとして、SayCanの開発、研究の方向性設定、基盤となる操作ポリシーの訓練、論文の執筆を行った。

Alex Herzog developed the teleoperation tools and implemented multiple infrastructure tools that allowed for continuous robot operation.

アレックス・ハーゾッグは、遠隔操作ツールの開発と、継続的なロボット運用を可能にする複数のインフラツールの実装を行った。

Daniel Ho helped develop sim-to-real pipelines for manipulation policies.

ダニエル・ホーは、操作ポリシーのシミュレーションから実世界へのパイプラインの開発を支援した。

Jasmine Hsu provided logging and monitoring infrastructure tools as well as data labeling pipelines. Julian Ibarz provided multiple contributions that enabled scaling learning algorithms for manipulation policies, and helped set the research direction.

ジャスミン・スーは、ロギングとモニタリングのインフラツールおよびデータラベリングパイプラインを提供した。ジュリアン・イバルズは、操作ポリシーの学習スケーリングを可能にする複数の貢献を行い、研究の方向性設定を支援した。

Brian Ichter initiated and led the SayCan algorithm, combined the manipulation and navigation skills, ran experiments for the paper, created the open-sourced SayCan Colab, and wrote the paper.

ブライアン・イフターは、SayCanアルゴリズムを開始・主導し、操作とナビゲーションのスキルを統合、論文の実験を実施し、オープンソースのSayCan Colabを作成し、論文を執筆した。

Alex Irpan set up and led the autonomous data collection effort as well as verified the data collected by the robots, and wrote parts of the paper.

アレックス・アープランは、自律的なデータ収集の取り組みを設定・主導し、ロボットによるデータの検証を行い、論文の一部を執筆した。

Eric Jang helped set the research and team direction, managed the data for learning, developed the behavioral cloning manipulation policies, and wrote parts of the paper.

エリック・ジャンは、研究とチームの方向性設定を支援し、学習用データの管理、行動模倣操作ポリシーの開発、論文の一部執筆を行った。

Rosario Jauregui Ruano collected data on the robots and ran and supervised real-world evaluations. Kyle Jeffrey collected data on the robots and ran and supervised real-world evaluations.

ロザリオ・ハウレギ・ルアノは、ロボットのデータ収集と実世界評価の実行・監督を行った。カイル・ジェフリーもロボットのデータ収集と実世界評価を行った。

Sally Jesmonth was the program manager for the project.

Sally Jesmonthはこのプロジェクトのプログラムマネージャーでした。

Nikhil J Joshi developed a number of simulation and infrastructure tools that allowed to scale up simulation training.

Nikhil J Joshiはシミュレーショントレーニングを拡張するためのシミュレーションおよびインフラストラクチャツールを開発しました。

Ryan Julian developed multi-modal network architectures and trained manipulation policies.

Ryan Julianはマルチモーダルネットワークアーキテクチャを開発し、操作ポリシーの訓練を行いました。

Dmitry Kalashnikov contributed infrastructure pieces that enabled training from logged data.

Dmitry Kalashnikovは、記録されたデータからの訓練を可能にするインフラストラクチャの一部に貢献しました。

Yuheng Kuang implemented the logging system for the project and designed and implemented the data labeling pipelines

Yuheng Kuangはプロジェクトのロギングシステムを実装し、データラベリングパイプラインを設計・実装しました。

Kuang-Huei Lee made improvements to training algorithms for manipulation policies.

Kuang-Huei Leeは操作ポリシーの訓練アルゴリズムの改善を行いました。

Sergey Levine advised on the project, helped set the research direction, developed SayCan, and wrote parts of the paper.

Sergey Levineはプロジェクトに助言を行い、研究の方向性を設定し、SayCanを開発し、論文の一部を執筆しました。

Yao Lu led and designed the robot learning infrastructure for the project providing most of the tools and improving manipulation policies.

Yao Luはロボット学習インフラストラクチャを主導・設計し、多くのツールを提供し、操作ポリシーの改善に貢献しました。

Linda Luu ran multiple evaluations, collected data and helped establish real-robot operations.

Linda Luuは複数の評価を実施し、データを収集し、実ロボット運用の確立を支援しました。

Carolina Parada advised on the project, managed the team, helped write the paper, and helped set the research direction.

Carolina Paradaはプロジェクトに助言を行い、チームを管理し、論文の執筆を支援し、研究の方向性を設定しました。

Peter Pastor provided infrastructure tools that allowed for continuous robot operations.

Peter Pastorは継続的なロボット運用を可能にするインフラストラクチャツールを提供しました。

Jornell Quiambao collected data on the robots and ran and supervised real-world evaluations.

Jornell Quiambaoはロボットのデータを収集し、実世界の評価を実行・監督しました。

Kanishka Rao co-led the project, managed the team, helped set the research direction and contributed to training manipulation policies.

Kanishka Raoはプロジェクトを共同リードし、チームを管理し、研究の方向性を設定し、操作ポリシーの訓練に貢献しました。

Jarek Rettinghouse collected data on the robots and ran and supervised real-world evaluations.

Jarek Rettinghouseはロボットのデータを収集し、実世界の評価を実行・監督しました。

Diego Reyes collected data on the robots and ran and supervised real-world evaluations.

Diego Reyesはロボットのデータを収集し、実世界の評価を実行・監督しました。

Pierre Sermanet set up the crowd compute rating pipeline.

Pierre Sermanetはクラウドコンピューティング評価パイプラインを設定しました。

Nicolas Sievers provided simulation assets and environments used for simulation training.

ニコラス・シーバースは、シミュレーショントレーニングに使用されるシミュレーション資産と環境を提供しました。

Clayton Tan collected data on the robots and ran and supervised real-world evaluations and helped establish real-robot operations.

クレイトン・タンはロボットに関するデータを収集し、実世界の評価を実行・監督し、実ロボット運用の確立を支援しました。

Alexander Toshev advised on the project, developed SayCan, helped write the paper, and helped set research direction.

アレクサンダー・トセフはプロジェクトに助言を行い、SayCanを開発し、論文の執筆を支援し、研究の方向性設定に貢献しました。

Vincent Vanhoucke advised on the project, managed the team, and helped write the paper.

ヴァンサン・ヴァンフックはプロジェクトに助言を行い、チームを管理し、論文の執筆を支援しました。

Fei Xia developed, implemented, and led on-robot SayCan, ran the experiments for the paper, created the demos, and wrote the paper.

フェイ・シャは、オンロボットのSayCanを開発・実装・リードし、論文の実験を行い、デモを作成し、論文を執筆しました。

Ted Xiao led the scaling of manipulation skills, designed and developed learning from simulation for manipulation skills, and developed multi-modal network architectures.

テッド・シャオは操作スキルの拡張をリードし、操作スキルのためのシミュレーション学習を設計・開発し、多モーダルネットワークアーキテクチャを構築しました。

Peng Xu was the engineering lead for integrating manipulation and navigation and developed the underlying infrastructure for SayCan.

ペン・シュは操作とナビゲーションの統合のエンジニアリングリードを務め、SayCanの基盤インフラを開発しました。

Sichun Xu developed remote teleoperation tools that allowed scaling up data collection in simulation.

シチュン・シュは、シミュレーションでのデータ収集を拡大するためのリモート遠隔操作ツールを開発しました。

Mengyuan Yan implemented infrastructure and learning tools that allowed for learning manipulation policies from different data sources.

メンユアン・ヤンは、異なるデータソースから操作ポリシーを学習できるインフラと学習ツールを実装しました。

Andy Zeng provided codebase and simulation assets for the open-source SayCan Colab.

アンディ・ゼンは、オープンソースのSayCan Colabのコードベースとシミュレーション資産を提供しました。

### B.3 Corresponding Emails:

### B.3 対応メール:

\{ichter, xiafei, karolhausman\}@google.com

\{ichter, xiafei, karolhausman\}@google.com

## C RL and BC Policies

## C RLとBCポリシー

### C.1 RL and BC Policy Architecture

### C.1 RLとBCポリシーのアーキテクチャ

The RL models use an architecture similar to MT-Opt [14], with slight changes to support natural language inputs (see Fig. 9 for the network diagram). The camera image is first processed by 7 convolutional layers. The language instruction is embedded by the LLM, then concatenated with the robot action and non-image parts of the state, such as the gripper height. To support asynchronous control, inference occurs while the robot is still moving from the previous action. The model is given how much of the previous action is left to execute [87]. The conditioning input goes through FC layers, then tiled spatially and added to the conv. volume, before going through 11 more convolutional layers. The output is gated through a sigmoid, so the Q-value is always in \( \left\lbrack  {0,1}\right\rbrack \) .

RLモデルはMT-Opt [14]に似たアーキテクチャを使用し、自然言語入力をサポートするためにわずかな変更を加えています(ネットワーク図は図9を参照)。カメラ画像は最初に7層の畳み込み層で処理されます。言語指示はLLMによって埋め込まれ、その後ロボットの動作やグリッパーの高さなどの非画像部分と連結されます。非同期制御をサポートするために、推論は前の動作からロボットが動いている間に行われます。モデルには前の動作の残りの実行量が与えられます[87]。条件付け入力は全結合層を通り、その後空間的にタイル状にされて畳み込みボリュームに加えられ、その後11層の畳み込み層を通ります。出力はシグモイドを通じてゲートされており、Q値は常に\( \left\lbrack  {0,1}\right\rbrack \)の範囲内です。

The BC models use an architecture similar to BC-Z [13] (see Fig. 10 for the network diagram). The language instruction is embedded by a universal sentence encoder [15], then used to FiLM condition a Resnet-18 based architecture. Unlike the RL model, we do not provide the previous action or gripper height, since this was not necessary to learn the policy. Multiple FC layers are applied to the final visual features, to output each action component (arm position, arm orientation, gripper, and the termination action).

BCモデルはBC-Z [13]に似たアーキテクチャを使用し(ネットワーク図は図10を参照)、言語指示はユニバーサルセンテンスエンコーダ [15]によって埋め込まれ、その後Resnet-18ベースのアーキテクチャをFiLM条件付けに使用します。RLモデルとは異なり、前の動作やグリッパーの高さは提供しません。これはポリシー学習に必要なかったためです。最終的な視覚特徴に複数の全結合層を適用し、各動作成分(アームの位置、アームの向き、グリッパー、終了動作)を出力します。

![bo_d3eb5nk601uc738ioai0_19_337_665_1126_709_0.jpg](images/bo_d3eb5nk601uc738ioai0_19_337_665_1126_709_0.jpg)

Figure 9: Network architecture in RL policy

図9:RLポリシーのネットワークアーキテクチャ

### C.2 RL and BC Policy Training

### C.2 RLとBCポリシーのトレーニング

RL training. In addition to using demonstrations in the BC setup, we also learn language-conditioned value functions with RL. For this purpose, we complement our real robot fleet with a simulated version of the skills and environment. To reduce the simulation-to-real gap we transform robot images via RetinaGAN [16] to look more realistic while preserving genera object structure. In order to learn a language-conditioned RL policy, we utilize MT-Opt [14] in the Everyday Robots simulator using said simulation-to-real transfer. We bootstrap the performance of simulation policies by utilizing simulation demonstrations to provide initial successes, and then continuously improve the RL performance with online data collection in simulation. Standard image augmentations (random brightness and contrast) as well as random cropping were applied. The \( {640} \times  {512} \) input image was padded by 100 pixels left-right and 40 pixels top-down, then cropped back down to a \( {640} \times  {512} \) image, so as to allow for random spatial shifts without limiting the field of view. We use a network architecture similar to MT-Opt (shown in Fig. 9).

RLトレーニング。BC設定でのデモンストレーションの使用に加え、言語条件付きの価値関数もRLで学習します。この目的のために、実ロボットのフリートに加えて、スキルと環境のシミュレーション版を補完します。シミュレーションから実環境へのギャップを縮めるために、ロボットの画像をRetinaGAN [16]を用いてより現実的に見えるよう変換し、一般的な物体構造を保持します。言語条件付きRLポリシーを学習するために、MT-Opt [14]を用いて、上記のシミュレーションから実環境への転送を行い、Everyday Robotsシミュレーター内で学習します。シミュレーションのデモンストレーションを利用して初期成功を提供し、その後、シミュレーション内でのオンラインデータ収集によりRLの性能を継続的に向上させます。標準的な画像拡張(ランダムな明るさとコントラスト調整)やランダムクロッピングを適用しました。\( {640} \times  {512} \)入力画像は左右に100ピクセル、上下に40ピクセルパディングし、その後、視野を制限せずにランダムな空間シフトを可能にするために再クロップされました。ネットワークアーキテクチャは、図9に示すMT-Optに類似しています。

The RL model is trained using 16 TPUv3 chips and for about 100 hours, as well as a pool of 3000 CPU workers to collect episodes and another 3000 CPU workers to compute target Q-values. Computing target Q-values outside the TPU allows the TPU to be used solely for computing gradient updates. Episode rewards are sparse and always 0 or 1 , so the Q-function is updated using a log loss. Models were trained using prioritized experience replay [88], where episode priority was tuned to encourage replay buffer training data for each skill to be close to \( {50}\% \) success. Episodes were rate of episodes in the replay buffer.

RLモデルは、16 TPUv3チップを用いて約100時間訓練され、エピソードを収集するための3000のCPUワーカーと、ターゲットQ値を計算するためのもう一つの3000のCPUワーカーのプールを使用します。TPU外でターゲットQ値を計算することで、TPUは勾配更新の計算に専念できます。エピソードの報酬はまばらで常に0または1であり、Q関数は対数損失を用いて更新されます。モデルは、優先経験リプレイ [88]を用いて訓練され、エピソードの優先度は、各スキルのリプレイバッファ内の訓練データが\( {50}\% \)成功に近いように調整されました。エピソードはリプレイバッファ内のエピソードの割合に比例してサンプリングされます。

![bo_d3eb5nk601uc738ioai0_20_320_220_1151_593_0.jpg](images/bo_d3eb5nk601uc738ioai0_20_320_220_1151_593_0.jpg)

Figure 10: Network architecture in BC policy

図10:BCポリシーのネットワークアーキテクチャ

sampled proportionally to their priority, defined as \( 1 + {10} \cdot  \left| {p - {0.5}}\right| \) , where \( p \) is the average success

優先度に比例してサンプリングされ、定義は\( 1 + {10} \cdot  \left| {p - {0.5}}\right| \)、\( p \)は平均成功率です

BC training. We use 68000 teleoperated demonstrations that were collected over the course of 11 months using a fleet of 10 robots. The operators use VR headset controllers to track the motion of their hand, which is then mapped onto the robot's end-effector pose. The operators can also use a joystick to move the robot's base. We expand the demonstration dataset with 276000 autonomous episodes of learned policies which are later success-filtered and included in BC training, resulting in an additional 12000 successful episodes. To additionally process the data, we also ask the raters to mark the episodes as unsafe (i.e., if the robot collided with the environment), undesirable (i.e., if the robot perturbed objects that were not relevant to the skill) or infeasible (i.e., if the skill cannot be done or is already accomplished). If any of these conditions are met, the episode is excluded from training.

BCトレーニング。11か月にわたり10台のロボットを用いて収集した68,000の遠隔操作デモンストレーションを使用します。オペレーターはVRヘッドセットコントローラーを使って手の動きを追跡し、それをロボットのエンドエフェクターの姿勢にマッピングします。オペレーターはジョイスティックを使ってロボットのベースを動かすこともできます。デモンストレーションデータセットは、後に成功フィルタリングされた276,000の自律エピソードの学習ポリシーで拡張され、さらに12,000の成功エピソードが追加されます。データの追加処理として、評価者にエピソードを安全でない(例:ロボットが環境と衝突した場合)、望ましくない(例:ロボットがスキルに関係のない物体を動かした場合)、または実行不可能(例:スキルができない、または既に完了している場合)としてマークさせることもあります。これらの条件のいずれかに該当する場合、そのエピソードは訓練から除外されます。

To learn language-conditioned BC policies at scale in the real world, we build on top of BC-Z [13] and use a similar policy-network architecture (shown in Fig. 10). It is trained with an MSE loss for the continuous action components, and a cross-entropy loss for the discrete action components. Each action component was weighted evenly. Standard image augmentations (random brightness and contrast) as well as random cropping were used. The \( {640} \times  {512} \) input image was padded by 100 pixels left-right and 40 pixels top-down, then cropped back down to a \( {640} \times  {512} \) image, so as to allow for random spatial shifts without limiting the field of view. For faster iteration speeds with negligible training performance reduction, image inputs were down sampled to half-size (256 x 320 images). Affordance value functions were trained with full-size images, since half-size images did not work as well when learning \( Q\left( {s, a,{\ell }_{\pi }}\right) \) . The BC model is trained using 16 TPUv3 chips and trained for about 27 hours.

実世界で言語条件付きBCポリシーを大規模に学習するために、BC-Z [13]を基盤とし、類似のポリシーネットワークアーキテクチャ(図10に示す)を使用します。連続アクション成分にはMSE損失を、離散アクション成分にはクロスエントロピー損失を用いて訓練します。各アクション成分は均等に重み付けされます。標準的な画像拡張(ランダムな明るさとコントラスト調整)やランダムクロッピングを使用しました。\( {640} \times  {512} \)入力画像は左右に100ピクセル、上下に40ピクセルパディングし、その後、視野を制限せずに再クロップされます。より高速な反復速度を実現し、訓練性能の低下を最小限に抑えるために、画像入力は半分のサイズ(256×320画像)にダウンサンプリングされました。アフォーダンス値関数はフルサイズの画像で訓練されましたが、半分サイズの画像では\( Q\left( {s, a,{\ell }_{\pi }}\right) \)の学習にあまり効果がありませんでした。BCモデルは、16 TPUv3チップを用いて約27時間訓練されました。

### C.3 RL and BC Policy Evaluations

### C.3 RLとBCポリシーの評価

In order to obtain the best possible manipulation capabilities for use in SayCan, we use a separate evaluation protocol for iterating on the RL and BC policies in the Mock Office Kitchen stations. Evaluations are divided by skill (pick up, knock over, place upright, open/close drawers, move object close to another one), and within each skill, 18-48 skills are sampled from a predetermined set of three objects. Object positions are randomized on each episode, with one or two objects serving as a distractor.

SayCanでの最良の操作能力を得るために、模擬オフィスキッチンステーションでRLとBCポリシーの反復評価を行うための別の評価プロトコルを使用します。評価はスキル(拾う、倒す、立てる、引き出しを開閉、物体を別の物体に近づける)ごとに分けられ、各スキル内では、あらかじめ決められた3つの物体から18〜48のスキルがサンプルされます。物体の位置は各エピソードごとにランダム化され、一つまたは二つの物体が邪魔者として機能します。

The episode ends when 50 actions have been taken or the policy samples a terminate action. A human operator supervises multiple robots performing evaluation and performs scene resets as needed, and records each episode as a success or failure. Models whose per-skill performance outperforms prior models are "graduated" to the same evaluation protocol in the real kitchen, and then integrated into SayCan. We found that despite the domain shift from Mock Office Kitchen stations to the actual kitchen counter and drawers, higher success rates on mock stations usually corresponded to higher success rates in the real kitchen setting.

エピソードは50回のアクションが行われるか、ポリシーが終了アクションをサンプルした時点で終了します。人間のオペレーターが複数のロボットを監督し、評価を行い、必要に応じてシーンのリセットを行い、各エピソードを成功または失敗として記録します。各スキルのパフォーマンスが以前のモデルを上回るモデルは、「卒業」して実際のキッチンで同じ評価プロトコルに移行し、その後SayCanに統合されます。Mock Office Kitchenのステーションから実際のキッチンのカウンターや引き出しへのドメインシフトにもかかわらず、Mockステーションでの成功率の向上は通常、実際のキッチン環境での成功率の向上と対応していることがわかりました。

Figure 11 shows the development of the manipulation skills over time. It reports the per-skill success rate, the average success rate across all skills, and the number of instructions the policy was trained on. Over the course of the project, we increased the number of skills evaluated, from 1 instruction in April 2021 to hundreds of instructions at time of publication over the course of 366 real-world model evaluations.

図11は、操作スキルの時間経過に伴う発展を示しています。各スキルの成功率、すべてのスキルの平均成功率、およびポリシーが訓練された指示の数を報告しています。プロジェクトの進行に伴い、評価されたスキルの数を2021年4月の1つの指示から、公開時点で数百の指示に増やし、366回の実世界モデル評価を通じて行いました。

![bo_d3eb5nk601uc738ioai0_21_326_480_1144_501_0.jpg](images/bo_d3eb5nk601uc738ioai0_21_326_480_1144_501_0.jpg)

Figure 11: Per-skill evaluation performance of the best policies and number of skills over the duration of the project. The performance as well as the number of skills that the robots are able to handle grow over time due to the continuous data collection efforts as well as improving the policy training algorithms.

図11:プロジェクト期間中の最良のポリシーの各スキル評価性能とスキル数の推移。パフォーマンスとロボットが扱えるスキルの数は、継続的なデータ収集努力とポリシー訓練アルゴリズムの改善により、時間とともに向上しています。

## D SayCan Details and Parameters

## D SayCanの詳細とパラメータ

### D.1 SayCan Details

### D.1 SayCanの詳細

Figure 12 shows scoring approach used and prompt engineering for the LLM side of SayCan. Figure 2 shows how robotic affordances are computed with value functions and real value function computations at different states. These two components are combined to form SayCan, as detailed in Algorithm 1 and in Figure 13.

図12は、SayCanのLLM側で使用されるスコアリングアプローチとプロンプトエンジニアリングを示しています。図2は、ロボットのアフォーダンスが価値関数と異なる状態での実価値関数計算によってどのように算出されるかを示しています。これら二つのコンポーネントは、アルゴリズム1および図13で詳述されているように、SayCanを形成するために結合されます。

![bo_d3eb5nk601uc738ioai0_21_323_1410_1140_353_0.jpg](images/bo_d3eb5nk601uc738ioai0_21_323_1410_1140_353_0.jpg)

Figure 12: A scoring language model is queried with a prompt-engineered context of examples and the high-level instruction to execute and outputs the probability of each skill being selected. To iteratively plan the next steps, the selected skill is added to the natural language query and the language model is queried again.

図12:スコアリング言語モデルは、例のプロンプトエンジニアリングされたコンテキストと実行すべき高レベルの指示を用いてクエリされ、各スキルが選択される確率を出力します。次のステップを反復的に計画するために、選択されたスキルを自然言語のクエリに追加し、再びモデルに問い合わせます。

### D.2 Policies and Affordance Functions

### D.2 ポリシーとアフォーダンス関数

We also note a few practical considerations for setting up our affordance functions and policies. The flexibility of our approach allows us to mix and match policies and affordances from different methods. For the pick manipulation skills we use a single multi-task, language-conditioned policy, for the place manipulation skills we use a scripted policy with an affordance based on the gripper state, and for navigation policies we use a planning-based approach which is aware of the locations where specific objects can be found and a distance measure. In order to avoid a situation where a skill is chosen but has already been performed or will have no effect, we set a cap for the affordances indicating that the skill has been completed and the reward received.

また、アフォーダンス関数とポリシーの設定に関するいくつかの実用的な考慮事項も述べておきます。私たちのアプローチの柔軟性により、異なる方法からのポリシーとアフォーダンスを組み合わせて使用することが可能です。ピック操作スキルには単一のマルチタスク、言語条件付きポリシーを使用し、配置操作スキルにはグリッパーの状態に基づくアフォーダンスを持つスクリプト化されたポリシーを使用し、ナビゲーションポリシーには特定の物体が見つかる場所を認識し距離測定を行う計画ベースのアプローチを採用しています。スキルが既に実行済みまたは効果がない場合に選択されるのを防ぐために、スキルが完了し報酬を受け取ったことを示すアフォーダンスの上限を設定しています。

![bo_d3eb5nk601uc738ioai0_22_319_193_1142_730_0.jpg](images/bo_d3eb5nk601uc738ioai0_22_319_193_1142_730_0.jpg)

Figure 13: (A copy of Figure 3 here for clarity) Given a high-level instruction, SayCan combines probabilities from a language model (representing the probability that a skill is useful for the instruction) with the probabilities from a value function (representing the probability of successfully executing said skill) to select the skill to perform. This emits a skill that is both possible and useful. The process is repeated by appending the selected skill to the robot response and querying the models again, until the output step is to terminate.

図13:(図3のコピーをここに示し、明確さのために)高レベルの指示に基づき、SayCanは言語モデルの確率(指示に役立つスキルの確率)と価値関数の確率(そのスキルを成功裏に実行する確率)を組み合わせて、実行すべきスキルを選択します。これにより、可能でかつ有用なスキルが出力されます。このプロセスは、選択されたスキルをロボットの応答に追加し、モデルに再問い合わせることで繰り返され、出力ステップが終了するまで続きます。

SayCan is capable of incorporating many different policies and affordance functions through its probability interface. Though in principle each type of skill has been trained with the pipeline described in Appendix C, to the success rates seen in Figure 11, we wish to show the generality of SayCan to different policies and affordance functions as well as the robustness of other functions (e.g. distance for navigation). Furthermore, some skills (such as the manipulation skill "move object near object" and "knock object over") are not naturally part of long-horizon tasks and thus we do not utilize them. Other skills, such as drawer opening, were not consistent enough for long-horizon planning and thus unused. However, we note that as skills become performant or as new skills are learned, it is straightforward to incorporate these skills by adding them as options for LLM scoring and as examples in the prompt. We use the following for each skill family:

SayCanは、その確率インターフェースを通じて多くの異なるポリシーとアフォーダンス関数を取り込むことが可能です。原則として、各スキルタイプは付録Cで説明されたパイプラインで訓練されていますが、図11で示される成功率を達成しており、SayCanの多様性や他の関数(例:ナビゲーションの距離測定)の堅牢性を示すために、異なるポリシーやアフォーダンス関数の一般性と堅牢性を示したいと考えています。さらに、一部のスキル(例:物体を近くに移動させる操作「move object near object」や「knock object over」)は長期的なタスクには自然に含まれず、使用していません。その他のスキル(例:引き出しを開ける)は長期的な計画には一貫性がなかったため使用していません。ただし、スキルの性能向上や新しいスキルの習得に伴い、これらのスキルをLLMのスコアリングのオプションやプロンプトの例として追加することは容易です。各スキルファミリーについては以下を使用します:

- Pick. For pick we use the learned policies in Appendix C and Section 4 with actions from \( \mathrm{{BC}} \) and value functions from \( \mathrm{{RL}} \) trained on the same skill. In natural language these are specified as "pick up the object".

- ピック。ピックには、付録Cおよびセクション4で訓練された学習済みポリシーと、\( \mathrm{{BC}} \)からのアクション、\( \mathrm{{RL}} \)からの価値関数を使用します。自然言語では「物体を拾う」と指定します。

- Go to. Since the focus of this work is mainly on planning, we assume the location of objects are known. Thus any navigation skill maps to the coordinate of the object with a classical planning-based navigation stack. In natural language these are specified as "go to location" and "find object".

- 行く。主に計画に焦点を当てているため、物体の位置は既知と仮定します。したがって、任意のナビゲーションスキルは、古典的な計画ベースのナビゲーションスタックを用いて物体の座標にマッピングされます。自然言語では「場所に行く」や「物体を見つける」と指定します。

- Place. Though our manipulation policies have a "place upright" skill, this skill only applies to objects that have a canonical upright direction, e.g., a water bottle but not a bag of chips. One could also train a universal "place" command, but our current policies are trained in a setup-free environment and thus are not amenable to an initial pick. Thus to have a consistent place policy across all objects we use a classical motion planning policy. We use Cartesian space motion planning to plan a path from pre-grasp pose shown in Figure 4 to a gripper release pose. The robot executes that path until the gripper is in contact with a supporting surface, and then the gripper opens and releases the object. In natural language these are specified as "put down the object". Recall that we wish to find the affordance function \( p\left( {{c}_{\pi } \mid  s,{\ell }_{\pi }}\right) \) , which indicates the probability of \( c \) -ompleting the skill with description \( {\ell }_{\pi } \) successfully from state \( s \) . Our learned policies produce a Q-function, \( {Q}^{\pi }\left( {s, a}\right) \) . Given \( {Q}^{\pi }\left( {s, a}\right) \) with action \( a \) and state \( s \) , value \( v\left( s\right)  = \mathop{\max }\limits_{a}{Q}^{\pi }\left( {s, a}\right) \) is found through optimization via the cross entropy method, similar to MT-Opt. For brevity below we refer to the value functions by their skill-text description \( {\ell }_{\pi } \) as \( {v}^{{\ell }_{\pi }} \) and the affordance function as \( {p}_{{\ell }_{\pi }}^{\text{affordance }} \) . Due to artifacts of training and each implementation, the value functions require calibration to be directly applied as a probability. The parameters used for calibration are determined empirically. Furthermore, SayCan enforces logic that if a skill that has already been completed and the reward received (e.g., navigating to the table the robot is already in front of) then it should not be performed.

- 場所。私たちの操作ポリシーには「場所を直立させる」スキルがありますが、このスキルは標準的な直立方向を持つ物体にのみ適用されます。例えば、水のボトルは対象ですが、ポテトチップスの袋は対象外です。ユニバーサルな「場所」コマンドを訓練することも可能ですが、現在のポリシーはセットアップ不要の環境で訓練されており、初期のピックには適していません。そのため、すべての物体に一貫した場所ポリシーを適用するために、古典的な動作計画ポリシーを使用します。直交空間の動作計画を用いて、図4に示すプリグラス位置からグリッパー解放位置までの経路を計画します。ロボットはその経路を実行し、グリッパーが支持面に接触したら、グリッパーを開いて物体を放します。自然言語ではこれを「物体を置く」と指定します。私たちは、\( p\left( {{c}_{\pi } \mid  s,{\ell }_{\pi }}\right) \)というアフォーダンス関数を見つけたいと考えています。これは、状態\( s \)からスキル\( {\ell }_{\pi } \)を成功裏に完了させる確率を示します。学習済みのポリシーはQ関数\( {Q}^{\pi }\left( {s, a}\right) \)を生成します。\( {Q}^{\pi }\left( {s, a}\right) \)と行動\( a \)、状態\( s \)に対して、値\( v\left( s\right)  = \mathop{\max }\limits_{a}{Q}^{\pi }\left( {s, a}\right) \)はクロスエントロピーメソッドによる最適化を通じて求められます。これはMT-Optに似ています。簡潔に言えば、以下では値関数をスキルの説明\( {\ell }_{\pi } \)に基づいて\( {v}^{{\ell }_{\pi }} \)と呼び、アフォーダンス関数を\( {p}_{{\ell }_{\pi }}^{\text{affordance }} \)と呼びます。訓練のアーティファクトや各実装の違いにより、値関数は確率として直接適用できるように較正が必要です。較正に用いるパラメータは経験的に決定されます。さらに、SayCanは、すでに完了し報酬を受け取ったスキル(例:ロボットがすでに前にいるテーブルにナビゲートした場合)については、それを再度実行しないように論理を強制します。

- Pick. We find the trained value functions generally have a minimum value for when a skill is not possible and a maximum when the skill is successful and thus we normalize the value function to get a affordance function with

- ピック。私たちは、訓練された値関数は一般にスキルが不可能なときに最小値を取り、成功したときに最大値を取ることを確認しており、そのため値関数を正規化してアフォーダンス関数を得ています。

\[
{p}_{\text{pick }}^{\text{affordance }} = \operatorname{clamp}\left( {\frac{{v}^{\text{pick }} - {v}_{\min }^{\text{pick }}}{{v}_{\max }^{\text{pick }} - {v}_{\min }^{\text{pick }}},0,1}\right) \text{, where }{v}_{\max }^{\text{pick }} = {0.5},{v}_{\min }^{\text{pick }} = {0.2}\text{. }
\]

- Go to. The affordance function of go to skills are based on the distance \( d \) (in meters) to the location. We use

- ゴー・トゥ。ゴー・トゥスキルのアフォーダンス関数は、位置までの距離\( d \)(メートル単位)に基づいています。私たちは

\[
{p}_{\text{goto }}^{\text{affordance }} = \operatorname{clamp}\left( {\frac{{d}_{\max }^{\text{goto }} - {d}^{\text{goto }}}{{d}_{\max }^{\text{goto }} - {d}_{\min }^{\text{goto }}},0,1}\right) \text{, where }{d}_{\max }^{\text{goto }} = {100},{d}_{\min }^{\text{goto }} = 0\text{. }
\]

- Place. We assume place is always possible, \( {p}_{\text{place }}^{\text{affordance }} = {1.0} \) , since we find language is sufficient to understand place is only possible after a pick. In the future work having an affordance function module for place could further improve the performance of SayCan.

- プレース。プレースは常に可能と仮定しています、\( {p}_{\text{place }}^{\text{affordance }} = {1.0} \)、なぜなら言語だけでプレースはピック後にのみ可能であると理解できるからです。将来的には、プレース用のアフォーダンス関数モジュールを導入することで、SayCanの性能をさらに向上させることができるでしょう。

- Terminate. We give terminate a small affordance value, to make sure the planning process terminates when there is no feasible skills to choose from. \( {p}_{\text{terminate }}^{\text{affordance }} = {0.1} \) .

- 終了。終了には小さなアフォーダンス値を与え、実行可能なスキルがなくなったときに計画プロセスが終了するようにします。\( {p}_{\text{terminate }}^{\text{affordance }} = {0.1} \)。

### D.3 LLM Prompt

### D.3 LLMプロンプト

The LLM uses prompt engineering and a strict response structure to score skills. But, as SayCan as a whole requires affordances from a world embodiment, it is not straightforward to optimize this structure and tune parameters quickly. Thus we built a language-based simulator which, given a query and a solution sequence of skills, outputs affordances consistent with the query and solution. It also generates consistent distractor affordances to ensure robustness. The simulator then verifies that SayCan recovers the correct solution and tests how confident SayCan is in the correct solutions. In Table 5 we test the effect of the number of examples in the prompt on the planning success rate in the language-based simulator (over 50 demonstrative instructions). We show a success rate with and without requiring the plan to terminate; without examples we found the LLM was unlikely to issue a "done" phase. With no examples SayCan is able to successfully plan 54% without the done condition, but only 10% with the done condition. Though it makes mistakes, clearly some information is already imbued within the language model. It is able to correctly solve "Can I have a redbull please?" and "Move the chips bag from the table to the counter.". With only one example the LLM quickly improves in both planning rates, though still fails to terminate the plan occasionally. After only four examples the LLM is performant, planning 82% of the queries correctly, though the remaining errors are largely within a single instruction family: Long-Horizon. Finally, the prompt used in this work, Listing 1, involved 17 examples and recovered 88% of the solutions correctly.

LLMはプロンプトエンジニアリングと厳格な応答構造を用いてスキルを評価します。しかし、SayCan全体が世界の具現化からのアフォーダンスを必要とするため、この構造を最適化しパラメータを迅速に調整することは容易ではありません。そこで、クエリとスキルの解決策シーケンスを与えると、そのクエリと解決策に一貫したアフォーダンスを出力する言語ベースのシミュレータを構築しました。また、堅牢性を確保するために一貫した妨害アフォーダンスも生成します。次に、シミュレータはSayCanが正しい解決策を復元できるかを検証し、SayCanが正解にどれだけ自信を持っているかをテストします。表5では、プロンプト内の例の数が言語ベースのシミュレータにおける計画成功率に与える影響(50のデモンストレーション指示を超えて)をテストしています。計画の終了を要求しない場合と比較して、例がないとLLMは「完了」フェーズを発行しにくいことがわかりました。例がない場合、SayCanは成功率54％で計画を立てることができましたが、「完了」条件を付けるとわずか10％に低下しました。誤りはありますが、言語モデルにすでに一部情報が内在していることは明らかです。例えば、「レッドブルをください」と「テーブルからチップスの袋をカウンターに移動してください」という問題を正しく解決できます。例が1つだけでも、LLMは両方の計画率を迅速に向上させ、成功率は82％に達しましたが、依然として計画の終了に失敗することもあります。わずか4つの例だけで、LLMは82％のクエリを正しく計画できる高性能を示しましたが、残りの誤りは主に長期的な指示群に集中しています。最後に、本研究で使用したプロンプト(リスト1)は17の例を含み、88％の解決策を正しく復元しました。

We note here briefly a few lessons learned in prompt engineering and structuring the final prompt. Providing explicit numbers between steps (e.g., 1., 2., instead of combining skills with "and then" or other phrases) improved performance, as did breaking each step into a separate line (e.g. adding a "\\n" between steps). Examples which overly include objects used in the actual planning tend to bias results to those objects (e.g., if every example is about apples then the apple scoring will be off in planning). Phrasing of the natural language names of skills and objects is important due to the auto-regressive nature of the LLM scoring - skills and objects should be naturally named and errors such as misspellings or mismatches in "a" vs "an" can be problematic. Notably, since user generated instructions are taken as given such fragility is not issues for the input, allowing a robustness to user queries. For our language model, PaLM [9], structuring the interaction as dialog (How would you

ここでは、プロンプトエンジニアリングと最終的なプロンプトの構造化において得られたいくつかの教訓を簡潔に述べます。ステップ間に明示的な番号(例:1.、2.など)を付けることや、「そして」などのフレーズでスキルを結合するのではなく、各ステップを別々の行に分けること(例:ステップ間に"\n"を追加すること)は、パフォーマンスの向上につながります。実際の計画に使用されるオブジェクトを過度に含む例は、そのオブジェクトに偏った結果をもたらす傾向があります(例:すべての例がリンゴに関するものであれば、計画時のリンゴのスコアリングがずれる)。スキルやオブジェクトの自然言語名の表現は、LLMの自己回帰的なスコアリングの性質上重要です。スキルやオブジェクトは自然な名前付けを行い、「a」と「an」の誤用やスペルミスなどの誤りは問題となる可能性があります。特に、ユーザ生成の指示はそのまま受け入れられるため、こうした脆弱性は入力には影響しません。これにより、ユーザのクエリに対する堅牢性が保たれます。私たちの言語モデル(PaLM [9])では、対話形式(例:How would you

- I would) was both more natural and performant. Although dialog is used as prompt, the model generalized to imperative sentences at deployment time.

- I would)での構造化は、より自然でパフォーマンスも向上しました。対話をプロンプトとして使用しているにもかかわらず、モデルは展開時に命令文にも一般化しました。

<table><tr><td>Num Examples</td><td>Require Termination</td><td>No Termination Required</td></tr><tr><td>0</td><td>10%</td><td>52%</td></tr><tr><td>1</td><td>64%</td><td>74%</td></tr><tr><td>2</td><td>68%</td><td>76%</td></tr><tr><td>4</td><td>82%</td><td>84%</td></tr><tr><td>8</td><td>80%</td><td>80%</td></tr><tr><td>Full Prompt (17)</td><td>88%</td><td>88%</td></tr></table>

<table><tbody><tr><td>例の数</td><td>終了を必要とする</td><td>終了は不要</td></tr><tr><td>0</td><td>10%</td><td>52%</td></tr><tr><td>1</td><td>64%</td><td>74%</td></tr><tr><td>2</td><td>68%</td><td>76%</td></tr><tr><td>4</td><td>82%</td><td>84%</td></tr><tr><td>8</td><td>80%</td><td>80%</td></tr><tr><td>完全なプロンプト(17)</td><td>88%</td><td>88%</td></tr></tbody></table>

Table 5: Number of prompt engineering examples versus planning rate (when requiring the plan to know when to terminate, e.g., issue a "done" command, or not).

表5:プロンプトエンジニアリングの例の数と計画率(終了時に計画を知る必要がある場合、例: "完了" コマンドを発行する場合など)。

Listing 1: Prompt in SayCan.

リスト1:SayCanのプロンプト。

Robot: Hi there, I'm a robot operating in an office kitchen.

ロボット:こんにちは、私はオフィスのキッチンで動作しているロボットです。

Robot: You can ask me to do various tasks and I'll tell you the sequence of actions I would do to accomplish your task.

ロボット:さまざまなタスクを依頼できます。私が行う一連の動作をお伝えしますので、それに従ってください。

Human: How would you hold the snickers?

人間:スニッカーズはどう持ちますか？

Robot: 1. pick up the snickers, 2. done.

ロボット:1. スニッカーズをつかむ、2. 完了。

Human: How would you put the trailmix here?

人間:トレイルミックスをここに置くにはどうしますか？

Robot: 1. put down the trailmix, 2. done.

ロボット:1. トレイルミックスを置く、2. 完了。

Human: How would you put a water bottle and an oatmeal next to the microwave?

人間:電子レンジの横に水のボトルとオートミールを置くにはどうしますか？

Robot: 1. find a water bottle, 2. pick up the water bottle, 3. go to microwave, 4. put down the water bottle, 5. find an oatmeal, 6. pick up the oatmeal, 7. go to the microwave, 8. put down the oatmeal, 9. done.

ロボット:1. 水のボトルを見つける、2. 水のボトルをつかむ、3. 電子レンジに行く、4. 水のボトルを置く、5. オートミールを見つける、6. オートミールをつかむ、7. 電子レンジに行く、8. オートミールを置く、9. 完了。

Human: How would you put a grapefruit from the table into the bowl?

人間:テーブルのグレープフルーツをボウルに入れるにはどうしますか？

Robot: 1. find a grapefruit, 2. pick up the grapefruit, 3. go to the bowl, 4. put down the grapefruit, 5. done.

ロボット:1. グレープフルーツを見つける、2. グレープフルーツをつかむ、3. ボウルに行く、4. グレープフルーツを置く、5. 完了。

Human: How would you get a sponge from the counter and put it in the sink?

人間:カウンターからスポンジを取り出してシンクに入れるにはどうしますか？

Robot: 1. find a sponge, 2. pick up the sponge, 3. go to the sink, 4. put down the sponge, 5. done.

ロボット:1. スポンジを見つける、2. スポンジをつかむ、3. シンクに行く、4. スポンジを置く、5. 完了。

Human: How would you move the water bottle from the table to the counter?

人間:水のボトルをテーブルからカウンターに移動させるにはどうしますか？

Robot: 1. find a water bottle, 2. pick up the water bottle, 3. go to the counter, 4. put down the water bottle, 5. done.

ロボット:1. 水のボトルを見つける、2. 水のボトルをつかむ、3. カウンターに行く、4. 水のボトルを置く、5. 完了。

Human: How would you bring me some snacks?

人間:おやつを持ってきてくれますか？

Robot: 1. find a twix, 2. pick up the twix, 3. bring it to you, 4. put down the twix, 5. find an dried fruit, 6. pick up the dried fruit, 7. bring it to you, 8. put down the dried fruit, 9. done.

ロボット:1. ツイックスを見つける、2. ツイックスを拾う、3. 持ってくる、4. 置く、5. ドライフルーツを見つける、6. ドライフルーツを拾う、7. 持ってくる、8. 置く、9. 完了。

Human: How would you bring me an orange?

人間:オレンジを持ってきてくれますか？

Robot: 1. find an orange, 2. pick up the orange, 3. bring it to you, 4. put down the orange, 5. done. Human: How would you deliver a can of coke to me?

ロボット:1. オレンジを見つける、2. オレンジを拾う、3. 持ってくる、4. 置く、5. 完了。人間:コーラの缶を持ってきてくれますか？

Robot: 1. find a coke can, 2. pick up the coke can, 3. bring it to you, 4. put down the coke can, 5. done.

ロボット:1. コーラの缶を見つける、2. コーラの缶を拾う、3. 持ってくる、4. 置く、5. 完了。

Human: I finished my drink, can you throw it away and bring me a mountain dew?

人間:飲み物を飲み終えたので、捨てて、マウンテンデューを持ってきてください。

Robot: 1. find a sprite can, 2. pick up the sprite can, 3. go to the trash can, 4. put down the sprite can , 5. find a mountain dew can, 6. pick up the mountain dew can, 7. bring it to you, 8. put down the mountain dew can, 9. done.

ロボット:1. スプライトの缶を見つける、2. スプライトの缶を拾う、3. ゴミ箱に行く、4. スプライトの缶を置く、5. マウンテンデューの缶を見つける、6. マウンテンデューの缶を拾う、7. 持ってくる、8. 置く、9. 完了。

Human: How would you let go of the banana?

人間:バナナをどうやって手放しますか？

Robot: 1. put down the banana, 2. done.

ロボット:1. バナナを置く、2. 完了。

Human: How would you put the grapes in the bowl and then move the cheese to the table?

人間:ぶどうをボウルに入れて、その後チーズをテーブルに移動させてください。

lobot: 1. find the grapes, 2. pick up the grapes, 3. go to the bowl, 4. put down the grapes, 5. pick up the cheese, 6. go to the table, 7. put down the cheese, 8. tell you I'm done.

ロボット:1. ぶどうを見つける、2. ぶどうを拾う、3. ボウルに行く、4. ぶどうを置く、5. チーズを拾う、6. テーブルに行く、7. チーズを置く、8. 完了を伝える。

Human: How would you pick up the peanuts?

人間:ピーナッツをどうやって拾いますか？

Robot: 1. pick up the peanuts, 2. done.

ロボット:1. ピーナッツを拾う、2. 完了。

Human: How would you bring me the peanuts?

人間:ピーナッツを持ってきてくれますか？

Robot: 1. pick up the peanuts, 2. bring it to you, 3. put down the peanuts, 4. done.

ロボット:1. ピーナッツを拾う、2. 持ってくる、3. ピーナッツを置く、4. 完了。

Human: How would you throw away a coffee cup?

人間:コーヒーカップを捨ててください。

Robot: 1. find a coffee cup, 2. pick up the coffee cup, 3. go to trash can, 4. put down the coffee cup, 5. done.

ロボット:1.コーヒーカップを見つける、2.コーヒーカップを持ち上げる、3.ゴミ箱に行く、4.コーヒーカップを置く、5.完了。

Human: How would you place a knife and a banana to the table?

人間:ナイフとバナナをテーブルにどう置きますか？

Robot: 1. find a knife, 2. pick up the knife, 3. go to the table, 4. put down the knife, 5. find a banana, 6. pick up the banana, 7. go to the table, 8. put down the banana, 9. done.

ロボット:1.ナイフを見つける、2.ナイフを持ち上げる、3.テーブルに行く、4.ナイフを置く、5.バナナを見つける、6.バナナを持ち上げる、7.テーブルに行く、8.バナナを置く、9.完了。

## E Experiments

## E 実験

### E.1 Tasks

### E.1 タスク

Below we include every instruction run, which environment it was run in, and its planning and execution success rate. Table 5 shows all instructions as broken down by instruction family, listed below and initially defined in Section 5 Table 1.

以下にすべての指示実行、実行された環境、計画と実行の成功率を含めます。表5は、指示の種類ごとに分解されたすべての指示を示しており、以下にリストされているもので、最初はセクション5表1で定義されています。

- Natural Language (NL) Single Primitive. Given a natural language command corresponding to performing a single primitive, can SayCan recover that primitive skill and terminate?

- 自然言語(NL)単一プリミティブ。単一のプリミティブを実行する自然言語コマンドが与えられた場合、SayCanはそのプリミティブスキルを回復し、終了できますか？

- NL Noun. Given a natural language query that replaces a noun (typically an object or location) with a synonym, can SayCan execute the appropriate sequence?

- NL名詞。名詞(通常は物体や場所)を同義語に置き換えた自然言語クエリが与えられた場合、SayCanは適切なシーケンスを実行できますか？

- NL Verbs. Given a natural language query that replaces a verb (typically an action) with a synonym, can SayCan execute an appropriate sequence?

- NL動詞。動詞(通常は動作)を同義語に置き換えた自然言語クエリが与えられた場合、SayCanは適切なシーケンスを実行できますか？

- Structured Language. Given a structure language query that mirrors the NL Verbs and spells out the sequence of commands, how well can SayCan plan compared to NL Verbs? This acts as an ablation to see the performance loss of understanding a natural language query over an explicit solution.

- 構造化言語。NL動詞を模倣し、コマンドのシーケンスを明示した構造化言語クエリが与えられた場合、SayCanはNL動詞と比べてどれだけ計画できるか？これは、自然言語クエリを理解することによるパフォーマンスの低下を確認するためのアブレーションです。

- Embodiment. Given a query with different environment and robot states, can SayCan still execute at a high rate? This tests the performance of SayCan's affordance model and the LLM's ability to reason within it.

- 実体化。異なる環境とロボットの状態を持つクエリが与えられた場合でも、SayCanは高い割合で実行できますか？これは、SayCanのアフォーダンスモデルの性能と、それ内で推論するLLMの能力をテストします。

- Crowd-Sourced. These queries were crowd sourced from Mechanical Turk by giving humans a description of what occurred (e.g., an apple was moved in front of you) and asking them what they would ask the robot to do. They were also crowd sourced by asking humans in a real office kitchen to command the robot to perform tasks (given knowledge of the robot's abilities). This tests SayCan's performance with natural requests.

- クラウドソース。これらのクエリは、Mechanical Turkからクラウドソースされ、人間に何が起こったか(例:リンゴがあなたの前に動かされた)を説明し、ロボットに何をさせるかを尋ねるものでした。また、実際のオフィスキッチンで人間にロボットにタスクを実行させるように命令させることでクラウドソースされました(ロボットの能力についての知識を持って)。これは、自然なリクエストに対するSayCanのパフォーマンスをテストします。

- Long-Horizon. These challenging queries require SayCan to reason over temporally extended instructions to investigate how well it scales to such regimes.

長期的な指示。これらの難しいクエリは、時間的に拡張された指示を推論させ、そうしたレジームにどれだけスケールできるかを調査します。

### E.2 Ablating Over Language Model Size

### E.2 言語モデルのサイズに対するアブレーション

To test how SayCan scales with LLM size, we ablate over varying PaLM [9] sizes (8B, 62B, and 540B parameter models) as well as the 137B parameter FLAN model[8]. The results are discussed in Section 5.1 and shown in Table 6.

SayCanがLLMのサイズにどのようにスケールするかをテストするために、異なるPaLM [9] サイズ(8B、62B、540Bパラメータモデル)と137BパラメータのFLANモデル[8]をアブレーションします。結果はセクション5.1で議論され、表6に示されています。

### E.3 Adding Skills: Drawer Manipulation

### E.3 スキルの追加:引き出しの操作

In order to support drawer manipulation we added another category of skills in SayCan.

引き出しの操作をサポートするために、SayCanに新たなスキルカテゴリを追加しました。

- Drawer Manipulation. For drawer manipulation we use the learned policies in Appendix C and Section 4 with actions from BC and value functions from heuristics (If the robot is next to the drawer, all drawer tasks are possible). In natural language these are specified as "open the drawer", "close the drawer", "put the object in the drawer", "take the object out of the drawer". (b) NL Verb

- 引き出し操作。引き出し操作には、付録Cおよびセクション4で学習されたポリシーを使用し、BCからのアクションとヒューリスティクスからの価値関数を用います(ロボットが引き出しの隣にいる場合、すべての引き出しタスクが可能です)。自然言語では、「引き出しを開ける」「引き出しを閉める」「物を引き出しに入れる」「物を引き出しから取り出す」と指定されます。(b)NL動詞

A few drawer-specific prompts also need to be added to teach the robot how to chain the drawer skills together. The prompts are shown in Listing 2.

いくつかの引き出し特有のプロンプトも追加して、ロボットに引き出しスキルを連携させる方法を教える必要があります。これらのプロンプトはリスト2に示されています。

<table><tr><td>Instruction</td></tr><tr><td>How would you pick up the coke can</td></tr><tr><td>How would you put the coke can in the your gripper</td></tr><tr><td>How would you grasp the coke can</td></tr><tr><td>How would you hold onto the coke can</td></tr><tr><td>How would you lift and hold the coke can up</td></tr><tr><td>How would you put the coke can down</td></tr><tr><td>How would you place the coke can on the table</td></tr><tr><td>How would you let go of the coke can</td></tr><tr><td>How would you release the coke can</td></tr><tr><td>How would you place the coke can</td></tr><tr><td>How would you move to the table</td></tr><tr><td>How would you go to the table</td></tr><tr><td>How would you park at the table</td></tr><tr><td>How would you come to the table</td></tr><tr><td>How would you navigate to the table</td></tr></table>

<table><tbody><tr><td>指示</td></tr><tr><td>コーラの缶をどうやって拾いますか</td></tr><tr><td>コーラの缶をどうやってグリッパーに入れますか</td></tr><tr><td>コーラの缶をどうやって掴みますか</td></tr><tr><td>コーラの缶をどうやって保持しますか</td></tr><tr><td>コーラの缶をどうやって持ち上げて保持しますか</td></tr><tr><td>コーラの缶をどうやって置きますか</td></tr><tr><td>コーラの缶をどうやってテーブルに置きますか</td></tr><tr><td>コーラの缶をどうやって放しますか</td></tr><tr><td>コーラの缶をどうやって解放しますか</td></tr><tr><td>コーラの缶をどうやって置きますか</td></tr><tr><td>テーブルにどうやって移動しますか</td></tr><tr><td>テーブルにどうやって行きますか</td></tr><tr><td>テーブルにどうやって駐車しますか</td></tr><tr><td>テーブルにどうやって来ますか</td></tr><tr><td>テーブルへどうやってナビゲートしますか</td></tr></tbody></table>

(a) NL Single Primitive

(a) NL単一原始}

<table><tr><td>Instruction</td></tr><tr><td>How would you throw away the apple</td></tr><tr><td>How would you bring me a sponge?</td></tr><tr><td>How would you bring me a coke can</td></tr><tr><td>How would you grab me an apple</td></tr><tr><td>How would you grab me a 7up from the table</td></tr><tr><td>How would you deliver the red bull to the close counter</td></tr><tr><td>How would you throw away the jalapeno chips</td></tr><tr><td>How would you restock the rice chips on the far counter</td></tr><tr><td>How would you recycle the coke can</td></tr><tr><td>How would you throw away the water bottle</td></tr><tr><td>How would you bring me something hydrating</td></tr><tr><td>How would you put the apple back on the far counter</td></tr><tr><td>How would you recycle the 7up</td></tr><tr><td>How would you throw away jalapeno chips</td></tr><tr><td>How would you compost the apple</td></tr></table>

<table><tbody><tr><td>指示</td></tr><tr><td>リンゴをどうやって捨てますか</td></tr><tr><td>スポンジをどうやって持ってきますか</td></tr><tr><td>コーラの缶をどうやって持ってきますか</td></tr><tr><td>リンゴをどうやって取りますか</td></tr><tr><td>テーブルから7upをどうやって取りますか</td></tr><tr><td>レッドブルをどうやって近くのカウンターに届けますか</td></tr><tr><td>ハラペーニョチップスをどうやって捨てますか</td></tr><tr><td>遠いカウンターの米チップスをどうやって補充しますか</td></tr><tr><td>コーラの缶をどうやってリサイクルしますか</td></tr><tr><td>水のボトルをどうやって捨てますか</td></tr><tr><td>何か水分補給できるものをどうやって持ってきますか</td></tr><tr><td>遠いカウンターにリンゴをどうやって戻しますか</td></tr><tr><td>7upをどうやってリサイクルしますか</td></tr><tr><td>ハラペーニョチップスをどうやって捨てますか</td></tr><tr><td>リンゴをどうやって堆肥にしますか</td></tr></tbody></table>

<table><tr><td>Instruction</td></tr><tr><td>How would you bring me lime drink</td></tr><tr><td>How would you bring me something to clean the kitchen with</td></tr><tr><td>How would you bring me something to eat</td></tr><tr><td>How would you put the grapefruit drink on the close counter</td></tr><tr><td>How would you move the sugary drink to the far counter</td></tr><tr><td>How would you move something with caffine from the table to the close counter</td></tr><tr><td>How would you bring me an energy bar</td></tr><tr><td>How would you bring me something to quench my thirst</td></tr><tr><td>How would you bring me a fruit</td></tr><tr><td>How would you bring me a fruit from the close counter</td></tr><tr><td>How would you bring me something that is not a fruit from the close counter</td></tr><tr><td>How would you bring me a soda from the table</td></tr><tr><td>How would you bring me a soda</td></tr><tr><td>How would you bring me a bag of chips from close counter</td></tr><tr><td>How would you bring me a snack</td></tr></table>

<table><tbody><tr><td>指示</td></tr><tr><td>ライムドリンクを持ってきてくれますか</td></tr><tr><td>台所用の掃除用品を持ってきてくれますか</td></tr><tr><td>何か食べ物を持ってきてくれますか</td></tr><tr><td>グレープフルーツドリンクを近くのカウンターに置いてください</td></tr><tr><td>甘い飲み物を遠くのカウンターに移動してください</td></tr><tr><td>カフェイン入りのものをテーブルから近くのカウンターに移動してください</td></tr><tr><td>エネルギーバーを持ってきてくれますか</td></tr><tr><td>喉の渇きを癒すものを持ってきてくれますか</td></tr><tr><td>果物を持ってきてくれますか</td></tr><tr><td>近くのカウンターから果物を持ってきてくれますか</td></tr><tr><td>果物ではないものを近くのカウンターから持ってきてくれますか</td></tr><tr><td>テーブルからソーダを持ってきてくれますか</td></tr><tr><td>ソーダを持ってきてください</td></tr><tr><td>近くのカウンターからポテトチップスの袋を持ってきてください</td></tr><tr><td>おやつを持ってきてください</td></tr></tbody></table>

(c) NL Nouns

(c) NL名詞

<table><tr><td>Instruction</td></tr><tr><td>How would you pick up the apple and move it to the trash</td></tr><tr><td>How would you pick up the sponge and bring it to me</td></tr><tr><td>How would you pick up the coke can and bring it to me</td></tr><tr><td>How would you pick up the apple and bring it to me</td></tr><tr><td>How would you pick up the 7up and bring it to me</td></tr><tr><td>How would you pick up the redbull and move it to the close counter</td></tr><tr><td>How would you pick up the jalapeno chips and move it to the trash</td></tr><tr><td>How would you pick up the rice chips and move it to the far counter</td></tr><tr><td>How would you pick up the coke can and move it to the trash</td></tr><tr><td>How would you pick up the water bottle and move it to the trash</td></tr><tr><td>How would you pick up the grapefruit soda and bring it to me</td></tr><tr><td>How would you pick up the apple and move it to the far counter</td></tr><tr><td>How would you pick up the 7up and move it to the trash</td></tr><tr><td>How would you pick up the jalepeno chips and move it to the trash</td></tr><tr><td>How would you pick up the apple and move it to the trash</td></tr></table>

<table><tbody><tr><td>指示</td></tr><tr><td>リンゴを拾い上げてゴミ箱に移すにはどうしますか</td></tr><tr><td>スポンジを拾い上げて私のところに持ってくるにはどうしますか</td></tr><tr><td>コーラ缶を拾い上げて私のところに持ってくるにはどうしますか</td></tr><tr><td>リンゴを拾い上げて私のところに持ってくるにはどうしますか</td></tr><tr><td>7upを拾い上げて私のところに持ってくるにはどうしますか</td></tr><tr><td>レッドブルを拾い上げて近くのカウンターに移すにはどうしますか</td></tr><tr><td>ハラペーニョチップスを拾い上げてゴミ箱に移すにはどうしますか</td></tr><tr><td>米菓を拾い上げて遠くのカウンターに移すにはどうしますか</td></tr><tr><td>コーラ缶を拾い上げてゴミ箱に移すにはどうしますか</td></tr><tr><td>水のボトルを拾い上げてゴミ箱に移すにはどうしますか</td></tr><tr><td>グレープフルーツソーダを拾い上げて私のところに持ってくるにはどうしますか</td></tr><tr><td>リンゴを拾い上げて遠くのカウンターに移すにはどうしますか</td></tr><tr><td>7upを拾い上げてゴミ箱に移すにはどうしますか</td></tr><tr><td>ハラペーニョチップスを拾い上げてゴミ箱に移すにはどうしますか</td></tr><tr><td>リンゴを拾い上げてゴミ箱に移すにはどうしますか</td></tr></tbody></table>

(d) Structured Language

構造化言語

Instruction

指示

How would you put the coke can down on the far counter(with operator)

オペレーターが遠くのカウンターにコーラ缶を置くにはどうすればよいですか

How would you put the coke can down on the far counter(at table)

テーブルにコーラ缶を置くにはどうすればよいですか

How would you put the coke can down on the far counter(at table with coke can in hand)

手にコーラ缶を持ったまま遠くのカウンターにコーラ缶を置くにはどうすればよいですか

How would you put the coke can down on the far counter(at far counter with coke can in hand) How would you put the sponge on the close counter(with operator) How would you put the sponge on the close counter(at far counter) How would you put the sponge on the close counter(at far counter with sponge in hand) How would you put the sponge on the close counter(at close counter with coke can in hand) How would you pick up the drink from the far counter I left something on the table, can you throw it away? I left something on the table or the counter, can you bring it to me? (e) Embodiment Instruction I opened a pepsi earlier. How would you bring me an open can? I spilled my coke, can you bring me a replacement? I spilled my coke, can you bring me something to clean it up? I accidentally dropped that jalapeno chip bag after eating it. Would you mind throwing it away? I like fruits, can you bring me something I'd like? There is a close counter, far counter, and table. How would you visit all the locations? There is a close counter, trash can, and table. How would you visit all the locations?

手にコーラ缶を持ったまま遠くのカウンターにコーラ缶を置くにはどうすればよいですか。近くのカウンターにスポンジを置くにはどうすればよいですか。遠くのカウンターにスポンジを置くにはどうすればよいですか。スポンジを手に持ったまま遠くのカウンターにスポンジを置くにはどうすればよいですか。コーラ缶を手に持ったまま近くのカウンターにスポンジを置くにはどうすればよいですか。遠くのカウンターから飲み物を取るにはどうすればよいですか。何かをテーブルに置き忘れました。捨ててもらえますか？何かをテーブルまたはカウンターに置き忘れました。持ってきてもらえますか？(e)具体化指示 以前ペプシを開けました。開いた缶を持ってきてもらえますか？コーラをこぼしてしまいました。代わりを持ってきてもらえますか？コーラをこぼしてしまいました。掃除用のものを持ってきてもらえますか？食べた後に誤ってハラペーニョチップスの袋を落としてしまいました。捨ててもらえますか？果物が好きです。何かおすすめを持ってきてもらえますか？近くのカウンター、遠くのカウンター、テーブルがあります。すべての場所をどうやって訪れますか？近くのカウンター、ごみ箱、テーブルがあります。すべての場所をどうやって訪れますか？

Redbull is my favorite drink, can I have one please?

レッドブルは私のお気に入りの飲み物です。一つもらえますか？

Would you bring me a coke can? Please, move the pepsi to the close counter

コーラ缶を持ってきてもらえますか？ペプシを近くのカウンターに移動してください

Please, move the ppsi(intentional typo) to the close cuonter

ペプシ(意図的なタイプミス)を近くのカウンターに移動してください

Can you move the coke can to the far counter?

コーラ缶を遠くのカウンターに移動できますか？

Can you move coke can to far counter?

コーラ缶を遠くのカウンターに移動できますか？

Would you throw away the bag of chips for me?

チップスの袋を捨ててもらえますか？

Would you throw away the bag of chpis(intentional typo) for me? (f) Crowd-Sourced Instruction How would you put an energy bar and water bottle on the table How would you bring me a lime soda and a bag of chips Can you throw away the apple and bring me a coke How would you bring me a 7up can and a tea? How would throw away all the items on the table? How would you move an multigrain chips to the table and an apple to the far counter? How would you move the lime soda, the sponge, and the water bottle to the table? How would you bring me two sodas? How would you move three cokes to the trash can? How would you throw away two cokes? How would you bring me two different sodas? How would you bring me an apple, a coke, and water bottle? I spilled my coke on the table, how would you throw it away and then bring me something to help clean? I just worked out, can you bring me a drink and a snack to recover?

チップスの袋を捨ててもらえますか？(意図的なタイプミス)(f)クラウドソース指示 エナジーバーと水のボトルをテーブルに置くにはどうすればよいですか？ライムソーダとチップスの袋を持ってきてもらえますか？リンゴを捨ててコーラを持ってきてもらえますか？7upの缶とお茶を持ってきてもらえますか？テーブルのすべてのアイテムをどうやって捨てますか？マルチグレインチップスをテーブルに、リンゴを遠くのカウンターに移動させるにはどうすればよいですか？ライムソーダ、スポンジ、水のボトルをテーブルに移動させるにはどうすればよいですか？2つのソーダを持ってきてもらえますか？3つのコーラをゴミ箱に移動させるにはどうすればよいですか？2つのコーラを捨てるにはどうすればよいですか？異なる2つのソーダを持ってきてもらえますか？リンゴ、コーラ、水のボトルを持ってきてもらえますか？コーラをテーブルにこぼしてしまいました。捨てて、その後掃除に役立つものを持ってきてもらえますか？運動後です。飲み物とスナックを持ってきてもらえますか？

How would you bring me a fruit, a soda, and a bag of chips for lunch

昼食に果物、ソーダ、チップスの袋を持ってきてもらえますか？

(g) Long-Horizon

(g)長期展望

Table 5: List of all instructions We evaluate the algorithm on 101 instructions on 2 scenes. The metrics and success definitions can be found in Sec. 5.

表5:すべての指示のリスト。2つのシーンで101の指示を評価します。評価指標と成功の定義はセクション5に記載されています。

<table><tr><td>Family</td><td>\( \mathbf{{Num}} \)</td><td>PaLM 540B [9]</td><td>PaLM 62B</td><td>PaLM 8B</td><td>FLAN 137B [8]</td></tr><tr><td>NL Single</td><td>15</td><td>87%</td><td>73%</td><td>20%</td><td>40%</td></tr><tr><td>NL Nouns</td><td>15</td><td>53%</td><td>47%</td><td>20%</td><td>40%</td></tr><tr><td>NL Verbs</td><td>15</td><td>93%</td><td>100%</td><td>60%</td><td>87%</td></tr><tr><td>Structured</td><td>15</td><td>100%</td><td>100%</td><td>67%</td><td>73%</td></tr><tr><td>Embodiment</td><td>11</td><td>36%</td><td>27%</td><td>27%</td><td>0%</td></tr><tr><td>Crowd Sourced</td><td>15</td><td>80%</td><td>73%</td><td>47%</td><td>47%</td></tr><tr><td>Long-Horizon</td><td>15</td><td>60%</td><td>73%</td><td>20%</td><td>0%</td></tr><tr><td>Total</td><td>101</td><td>74%</td><td>72%</td><td>38%</td><td>43%</td></tr></table>

<table><tbody><tr><td>家族</td><td>\( \mathbf{{Num}} \)</td><td>PaLM 540B [9]</td><td>PaLM 62B</td><td>PaLM 8B</td><td>FLAN 137B [8]</td></tr><tr><td>NLシングル</td><td>15</td><td>87%</td><td>73%</td><td>20%</td><td>40%</td></tr><tr><td>NL名詞</td><td>15</td><td>53%</td><td>47%</td><td>20%</td><td>40%</td></tr><tr><td>NL動詞</td><td>15</td><td>93%</td><td>100%</td><td>60%</td><td>87%</td></tr><tr><td>構造化</td><td>15</td><td>100%</td><td>100%</td><td>67%</td><td>73%</td></tr><tr><td>具現化</td><td>11</td><td>36%</td><td>27%</td><td>27%</td><td>0%</td></tr><tr><td>クラウドソース</td><td>15</td><td>80%</td><td>73%</td><td>47%</td><td>47%</td></tr><tr><td>長期展望</td><td>15</td><td>60%</td><td>73%</td><td>20%</td><td>0%</td></tr><tr><td>合計</td><td>101</td><td>74%</td><td>72%</td><td>38%</td><td>43%</td></tr></tbody></table>

Table 6: Ablations over the size of the LLM. Compared only with the generative outputs (no value function) with USE embeddings [15].

表6:LLMのサイズに関するアブレーション。USE埋め込み[15]を用いた生成出力のみと比較。

Listing 2: Prompt for drawer tasks in SayCan. They can be used standalone, or appended to the main prompt

リスト2:SayCanの引き出しタスク用プロンプト。これらは単独で使用するか、メインプロンプトに付加できます

in Listing 1.

リスト1に。

---

Human: open the drawer

人間:引き出しを開けてください

Robot: 1. go to the drawers, 2. open the drawer, 3. done.

ロボット:1. 引き出しに行く、2. 引き出しを開ける、3. 完了。

Human: restock orange juice into the drawer

人間:オレンジジュースを引き出しに補充してください

Robot: 1. go to the drawers, 2. open the drawer, 3. put orange juice in the drawer, 4. close the drawer,

ロボット:1. 引き出しに行く、2. 引き出しを開ける、3. オレンジジュースを引き出しに入れる、4. 引き出しを閉める、

	5. done.

	 5. 完了。

Human: restock two bottles of orange juice into the drawer

人間:オレンジジュースのボトルを2本引き出しに補充してください

Robot: 1. go to the drawers, 2. open the drawer, 3. put orange juice in the drawer, 4. put orange juice in

ロボット:1. 引き出しに行く、2. 引き出しを開ける、3. オレンジジュースを引き出しに入れる、4. 引き出しにオレンジジュースを入れる

	the drawer, 5 . close the drawer, 6 . done.

	 5. 引き出しを閉める、6. 完了。

---

The results of the drawer tasks are shown in Table. 7. SayCan achieved an overall planning success rate of \( {100}\% \) and execution success rate of \( {33}\% \) . The main failure cases are manipulation failures, where the robot fails to open the drawer wide enough to put objects in it, or fails to completely close the drawer.

引き出しタスクの結果は表7に示されています。SayCanは全体の計画成功率\( {100}\% \)と実行成功率\( {33}\% \)を達成しました。主な失敗ケースは操作の失敗であり、ロボットが引き出しを十分に開けられず物を入れることができないか、完全に閉められない場合です。

<table><tr><td>Instruction</td><td>Plan rate</td><td>Execution rate</td></tr><tr><td>restock the coke and pepsi into the drawer</td><td>1.0</td><td>0.0</td></tr><tr><td>hide the 7up in the drawer</td><td>1.0</td><td>0.83</td></tr><tr><td>restock the coke into the drawer</td><td>1.0</td><td>0.17</td></tr></table>

<table><tbody><tr><td>指示</td><td>計画レート</td><td>実行レート</td></tr><tr><td>コークとペプシを引き出しに補充する</td><td>1.0</td><td>0.0</td></tr><tr><td>7upを引き出しに隠す</td><td>1.0</td><td>0.83</td></tr><tr><td>コークを引き出しに補充する</td><td>1.0</td><td>0.17</td></tr></tbody></table>

Table 7: Plan and execution success rate of drawer tasks

表7:引き出し作業の計画と実行成功率

### E.4 Chain of Thought Reasoning

### E.4 思考の連鎖推論

Here we show the chain of thought prompt that generates the rollout in Table 4. Listing 3: Chain-of-thought prompt in SayCan.

ここでは、表4の展開を生成する思考の連鎖プロンプトを示します。リスト3:SayCanにおける思考の連鎖プロンプト。

Robot: Hi there, I'm a robot operating in an office kitchen.

ロボット:こんにちは、私はオフィスのキッチンで働くロボットです。

You can ask me to do various tasks and I'll tell you the sequence of actions I would do to accomplish your

さまざまなタスクを依頼できます。私はそれを達成するための一連の動作をお伝えします。

The following objects are in the scene: 7up, apple, tea, multigrain chips, kettle chips, jalapeno chips, rice chips, coke, grapefruit soda, pepsi, redbull, energy bar, lime soda, sponge, and water bottle.

シーンには次の物体があります:7up、リンゴ、紅茶、全粒粉チップス、ケトルチップス、ハラペーニョチップス、米チップス、コーラ、グレープフルーツソーダ、ペプシ、レッドブル、エナジーバー、ライムソーダ、スポンジ、水のボトル。

The following locations are in the scene: close counter, far counter, table, you, trash, bowl. Human: Hold the sponge

シーンには次の場所があります:近くのカウンター、遠くのカウンター、テーブル、あなた、ごみ箱、ボウル。人間:スポンジを持ってください。

Explanation: The user has asked for a single skill, I will just pick up the sponge.

説明:ユーザーは単一のスキルを求めているので、私はスポンジを拾います。

Robot: 1. pick up the sponge, 2. done.

ロボット:1.スポンジを拾う、2.完了。

Human: Put the kettle chips here

人間:ケトルチップスをここに置いてください。

Explanation: The user has asked for a type of chips, I will bring those to them.

説明:ユーザーは特定の種類のチップスを求めているので、それを持ってきます。

Robot: 1. put down the kettle chips, 2. done.

ロボット:1.ケトルチップスを置く、2.完了。

Human: Move the grapefruit drink from the table to the close counter

人間:テーブルのグレープフルーツドリンクを近くのカウンターに移動してください。

Explanation: The user has asked me to move the grapefruit drink to the counter.

説明:ユーザーはグレープフルーツドリンクをカウンターに移動するように頼んでいます。

Robot: 1. find a grapefruit soda, 2. pick up the grapefruit soda, 3. go to the counter, 4. put down the grapefruit soda, 5. done.

ロボット:1.グレープフルーツソーダを見つける、2.それを拾う、3.カウンターに行く、4.グレープフルーツソーダを置く、5.完了。

Human: Bring me some snacks

人間:おやつをいくつか持ってきてください。

Explanation: The user has asked for snacks, I will bring jalapeno chips and an apple.

説明:ユーザーはスナックを求めているので、ハラペーニョチップスとリンゴを持ってきます。

Robot: 1. find a jalapeno chips, 2. pick up the jalapeno chips, 3. bring it to you, 4. put down the

ロボット:1. ハラペーニョチップスを見つける、2. ハラペーニョチップスを取る、3. それをあなたに持ってくる、4. 置く

jalapeno chips, 5. find an apple, 6. pick up the apple, 7. bring it to you, 8. put down the apple, 9. done.

ハラペーニョチップス、5. リンゴを見つける、6. リンゴを取る、7. それをあなたに持ってくる、8. 置くリンゴ、9. 完了。

Human: Bring me something that isn't a fruit

人間:果物ではないものを持ってきてください

Explanation: The user has asked for something food that isn't an fruit, I will bring an energy bar.

説明:ユーザーは果物ではない食べ物を求めているので、エネルギーバーを持ってきます。

Robot: 1. find an energy bar, 2. pick up the energy bar, 3. bring it to you, 4. put down the energy bar, 5. done.

ロボット:1. エネルギーバーを見つける、2. エネルギーバーを取る、3. それをあなたに持ってくる、4. 置くエネルギーバー、5. 完了。

Human: Put the rice chips in the bowl and then move the tea to the table

人間:米のチップスをボウルに入れて、その後お茶をテーブルに移動させてください

Explanation: The user has asked me to do two tasks, I will do one and then the other.

説明:ユーザーは二つのタスクを頼んでいるので、一つずつ行います。

Robot: 1. find the rice chips, 2. pick up the rice chips, 3. go to the bowl, 4. put down the rice chips, 5. pick up the tea, 6. go to the table, 7. put down the tea, 8. done. Human: Throw away a redbull Explanation: The user has asked me to throw away the redbull can, I will move it to the trash. Robot: 1. find a redbull, 2. pick up the redbull, 3. go to trash, 4. put down the redbull, 5. done.

ロボット:1. 米のチップスを見つける、2. 米のチップスを取る、3. ボウルに行く、4. 米のチップスを置く、5. お茶を取る、6. テーブルに行く、7. お茶を置く、8. 完了。人間:レッドブルを捨ててください説明:ユーザーはレッドブルの缶を捨てるように頼んでいるので、ゴミ箱に移動します。ロボット:1. レッドブルを見つける、2. レッドブルを取る、3. ゴミ箱に行く、4. レッドブルを置く、5. 完了。

### E.5 Multilingual Queries

### E.5 多言語クエリ

Since the underlying LM we used [9] has been trained on multilingual corpora, SayCan can handle multilingual queries out of the box. The results of SayCan on multilingual queries are summarized in Table. 8, and there is almost no performance drop on planning success rate when changing the queries from English to Chinese, French and Spanish.

使用している基盤のLM [9] は多言語コーパスで訓練されているため、SayCanは多言語クエリに標準で対応できます。多言語クエリに対するSayCanの結果は表8にまとめられており、英語から中国語、フランス語、スペイン語に変更しても計画成功率のパフォーマンス低下はほとんどありません。

<table><tr><td>Instruction</td><td>Plan rate</td></tr><tr><td>bring me a can of coke</td><td>1.0</td></tr><tr><td>throw away the coke can</td><td>1.0</td></tr><tr><td>I spilled my coke, can you bring me something to help clean</td><td>1.0</td></tr><tr><td>拿一罐可乐给我</td><td>1.0</td></tr><tr><td>扔掉可乐罐</td><td>1.0</td></tr><tr><td>我的可乐洒了,你能给我拿点东西来帮忙打扫吗</td><td>1.0</td></tr><tr><td>apporte moi une canette de coca</td><td>1.0</td></tr><tr><td>jeter la canette de coca</td><td>1.0</td></tr><tr><td>J'ai renversé mon coca, peux-tu m'apporter quelque chose pour m’aider à nettoyer</td><td>0.0</td></tr><tr><td>tráeme una lata de coca cola</td><td>1.0</td></tr><tr><td>tirar la lata de coca cola</td><td>1.0</td></tr><tr><td>Derramé mi coca cola, \( ; \) puedes traerme algo para ayu- dar a limpiar</td><td>1.0</td></tr></table>

<table><tbody><tr><td>指示</td><td>料金計画</td></tr><tr><td>コーラの缶を持ってきて</td><td>1.0</td></tr><tr><td>コーラの缶を捨てて</td><td>1.0</td></tr><tr><td>コーラをこぼしてしまった、掃除を手伝うものを持ってきてくれる？</td><td>1.0</td></tr><tr><td>一缶のコーラを持ってきて</td><td>1.0</td></tr><tr><td>コーラの缶を捨てて</td><td>1.0</td></tr><tr><td>コーラをこぼした、掃除を手伝うものを持ってきてくれる？</td><td>1.0</td></tr><tr><td>コーラの缶を持ってきてください</td><td>1.0</td></tr><tr><td>コーラの缶を捨てて</td><td>1.0</td></tr><tr><td>コーラをこぼしてしまった、掃除を手伝うものを持ってきてくれる？</td><td>0.0</td></tr><tr><td>コーラの缶を持ってきて</td><td>1.0</td></tr><tr><td>コーラの缶を捨てて</td><td>1.0</td></tr><tr><td>コーラをこぼした、\( ; \)掃除を手伝うものを持ってきてくれる？</td><td>1.0</td></tr></tbody></table>

Table 8: Multilingual queries plan success rate. instruction 4-12 are the Chinese, French and Spanish translation of first 3 queries.

表8:多言語クエリの成功率。指示4-12は最初の3つのクエリの中国語、フランス語、スペイン語の翻訳です。

### E.6 Additional Results

### E.6 追加結果

Additional results are shown in Figure 14 and Figure 17 and some failure cases in Figure 16. For videos of the rollouts, please visit the our website https://say-can.github.io

追加の結果は図14および図17に示されており、いくつかの失敗例は図16に示されています。ロールアウトのビデオについては、私たちのウェブサイトhttps://say-can.github.ioをご覧ください。

![bo_d3eb5nk601uc738ioai0_30_394_257_1010_1724_0.jpg](images/bo_d3eb5nk601uc738ioai0_30_394_257_1010_1724_0.jpg)

Figure 14: Visualization of the decision making process of SayCan shows its interpretability and successful temporally extended execution, where the top combined score chooses the correct skill.

図14:SayCanの意思決定過程の可視化は、その解釈性と成功した時間的に拡張された実行を示しており、上位の結合スコアが正しいスキルを選択します。

![bo_d3eb5nk601uc738ioai0_31_431_266_931_901_0.jpg](images/bo_d3eb5nk601uc738ioai0_31_431_266_931_901_0.jpg)

(a) In this long-horizon task, the language model gives high score to the two sodas. After the coke is delivered, the language model scores pepsi higher. The affordance rating overcomes potential early termination after the first can has been delivered.

(a) この長期的なタスクでは、言語モデルは2つのソーダに高いスコアを与えます。コーラが配達された後、言語モデルはペプシにより高いスコアを付けます。アフォーダンス評価は、最初の缶が配達された後の早期終了の可能性を克服します。

![bo_d3eb5nk601uc738ioai0_31_430_1247_940_745_0.jpg](images/bo_d3eb5nk601uc738ioai0_31_430_1247_940_745_0.jpg)

Figure 15: Long horizon sequences, see the video on our website say-can.github.io for more.

図15:長期シーケンスについては、私たちのウェブサイトsay-can.github.ioのビデオをご覧ください。

![bo_d3eb5nk601uc738ioai0_32_299_312_1183_1614_0.jpg](images/bo_d3eb5nk601uc738ioai0_32_299_312_1183_1614_0.jpg)

Figure 16: Failure cases. The planning success rate was \( {84}\% \) . Of the errors, \( {65}\% \) were a result of an LLM error and 35% were affordance errors.

図16:失敗例。計画成功率は\( {84}\% \)でした。エラーのうち、\( {65}\% \)はLLMの誤りによるもので、35％はアフォーダンスの誤りでした。

![bo_d3eb5nk601uc738ioai0_33_430_266_932_901_0.jpg](images/bo_d3eb5nk601uc738ioai0_33_430_266_932_901_0.jpg)

(a) In this long-horizon task, the language model gives high score to the two sodas. After the coke is delivered, the language model scores pepsi higher. The affordance rating overcomes potential early termination after the first can has been delivered.

(a) この長期的なタスクでは、言語モデルは2つのソーダに高いスコアを与えます。コーラが配達された後、言語モデルはペプシにより高いスコアを付けます。アフォーダンス評価は、最初の缶が配達された後の早期終了の可能性を克服します。

![bo_d3eb5nk601uc738ioai0_33_429_1249_941_741_0.jpg](images/bo_d3eb5nk601uc738ioai0_33_429_1249_941_741_0.jpg)

Figure 17: Long horizon sequences, see the video on our website say-can.github.io for more.

図17:長期シーケンスについては、私たちのウェブサイトsay-can.github.ioのビデオをご覧ください。

